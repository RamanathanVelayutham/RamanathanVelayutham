/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FS7G27G3A01CFB
#define BSP_ROM_SIZE_BYTES (3145728)
#define BSP_RAM_SIZE_BYTES (655360)
#define BSP_DATA_FLASH_SIZE_BYTES (65536)
#define BSP_PACKAGE_LQFP
#define BSP_PACKAGE_PINS (144)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
