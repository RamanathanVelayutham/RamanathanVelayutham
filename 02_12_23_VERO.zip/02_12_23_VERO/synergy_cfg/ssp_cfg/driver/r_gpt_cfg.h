/* generated configuration header file - do not edit */
#ifndef R_GPT_CFG_H_
#define R_GPT_CFG_H_
#define GPT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_GPT_CFG_H_ */
