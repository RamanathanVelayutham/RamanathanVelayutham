/*
 * ARRAY_DEF.h
 *
 *  Created on: 08-Feb-2023
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_ARRAY_DEF_H_
#define MAIN_HEADER_FILE_ARRAY_DEF_H_

#define milk_prmx           1
#define sugar_prmx          2
/***********RINSE MENU SETTINGS ID****************/

#define ch1_rns_set         1
#define ch2_rns_set         2
#define ch3_rns_set         3
#define ch4_rns_set         4
#define ch5_rns_set         5
#define ch6_rns_set         6
#define hw_rns_set          7
#define cw_rns_set          8
#define fb_rns_set          9
#define rplc_fltr_ppr       10
#define esp_rns_set         11
#define flus_es_set         12
#define es_cln_set          13
#define es_drnk_aftr_cln    14

/***********ch1-ch6, hw, cw*************/

#define total_wtr_time      1
#define no_of_pulz          2
#define pulz_pauz_time      3
#define rns_mxr_dly_time    4
#define rns_mxr_rpm         5
#define rns_mxr_run_time    6

/***********fresh brewer rinse settings*************/

#define fb_total_wtr_time   1
#define fb_no_of_pulz       2
#define fb_pulz_pauz_time   3
#define fb_pos_brwrstop     4
#define fb_brwrstop         5
#define fb_drip_time        6

/***********replace filter paper settings*************/

#define fb_fltr_ppr_pos_stp     1

/***********rinse espresso brewer-close position************/

#define cls_pos_rns_wtr     1
#define cls_pos_rns_pauz    2
#define cls_pos_cycl_cnt    3

/**********flush espresso brewer - open position*************/

#define fls_es_brwr_en           1
#define fls_es_brwr_run_time     2
#define fls_es_brwr_wtr          3
#define fls_es_brwr_pauz         4
#define fls_es_brwr_cycl_cnt     5

/**********espresso brewer cleaning cycle************/

#define cln_es_brwr_wtr              1
#define cln_es_brwr_soak_chmbr       2
#define cln_es_brwr_cycl_cnt         3
#define cln_es_brwr_pauz             4

/***********espresso drink after brewr cleaning**************/

#define es_drnk_aftr_cln_en         1

/************DRINK MAIN ARRAY******************/

#define drink_en_dis    1
#define drip_time       2
#define double_cup      3
#define mug_en          4
#define mug_adjst_fctr  5
#define multicup        6
#define min_num         7
#define pauz_time       8
#define default_number  9
#define max_number      10
#define main_prdt_ch    11
#define milk_en_dis     12
#define sugar_en_dis    13

/************DRINK SET ARRAY******************/
#define ch_delay1           1
#define wtr_time1           2
#define wtr_pulz_no1        3
#define wtr_pulz_time1      4
#define prmx_dly1           5
#define prmx_rpm1           6
#define prmx_time1          7
#define prmx_pulz_no1       8
#define prmx_pulz_time1     9
#define prmx_strngth_en     10
#define prmx_strngth_per    11
#define whpr_dly1           12
#define whpr_rpm1           13
#define whpr_time1          14

#define ch_delay2           15
#define wtr_time2           16
#define wtr_pulz_no2        17
#define wtr_pulz_time2      18
#define prmx_dly2           19
#define prmx_rpm2           20
#define prmx_time2          21
#define prmx_pulz_no2       22
#define prmx_pulz_time2     23
#define prmx_strngth_en2    24
#define prmx_strngth_per2   25
#define whpr_dly2           26
#define whpr_rpm2           27
#define whpr_time2          28



/************OTHER SET ARRAY FOR ESPRESSO******************/
#define gndr_dly_time                 1
#define grndr_run_time                2
#define grndr_strnth_en               3
#define grndr_strnth_perctg           4
#define pre_brw_wtr_time              5
#define pre_brw_wait_time             6
#define cof_wtr_pulz                  7
#define brwr_pauz_time                8
#define brwr_delay_time               9
#define ex_hot_wtr_no_byproduct      10


/************OTHER SET ARRAY FOR FRESH BREW & BEAN BREW******************/
#define premx_grndr_dly_time          1
#define premx_grndr_run_time          2
#define premx_grndr_strnth_en         3
#define premx_grndr_strnth_per        4
#define wtr_dly_time                  5
#define wtr_run_time                  6
#define brwr_dly_time                 7
#define pos_1_stp                     8
#define brwr_stp1                     9
#define pos_2_stp                     10
#define brwr_stp2                     11
#define pos_3_stp                     12
#define brwr_stp3                     13
#define pos_4_stp                     14
#define brwr_stp4                     15

//
///************OTHER SET ARRAY FOR FRESH BREW******************/
//
//#define grndr_dly_time          1
//#define grndr_run_time          2
//#define grndr_strnth_en         3
//#define grndr_strnth_per        4
//#define wtr_dly_time            5
//#define wtr_run_time            6
//#define brwr_dly_time           7
//#define pos_1_stp               8
//#define brwr_stp1               9
//#define pos_2_stp              10
//#define brwr_stp2              11
//#define pos_3_stp              12
//#define brwr_stp3              13
//#define pos_4_stp              14
//#define brwr_stp4              15

/**************SECONDARY OUTLET WTR ARR*****************/
#define hot_wtr         1
#define cold_wtr        2

#define scndary_wtr_dly         1
#define scndary_wtr_time        2


/***************GENERAL SETTINGS********************/
#define min_op_temp              1
#define op_set_temp              2
#define max_temp_vari            3
#define stnd_by_temp             4
#define temp_snsr_resistnce      6
#define temp_snsr_beta_val       5
#define htr_temp_temp_err_en     7
#define htr_temp_temp_sec        8
#define es_min_op_temp           9
#define es_op_set_temp           10
#define es_max_temp_var          11
#define es_stnd_by_temp          12
#define es_temp_snsr_resistnce   13
#define es_temp_snsr_beta_val    14
#define es_htr_temp_temp_err_en  15
#define es_temp_temp_sec         16
#define flw_mtr_puls_per_lit     17
#define flow_puls_puls_err_en    18
#define flow_puls_puls_sec       19
#define use_blr_perdc_reprsr     20
#define perdc_reprsr_intrval     21
#define repsrsr_pump_on_time     22
#define interrupt_multicup       23
#define set_cup_at_dr_strt       24
#define use_jug_functionality    25
#define use_buzzer               26
#define use_brwr_plced_sw        27
#define fan_cntinus              28
#define fan_run_time             29
#define drip_tray_prsnt_en       30
#define canister_sensor_en       31
#define allow_prdct_stp          32
#define scnd_prdct_cycle         33
#define direct_start             34
#define paymnt_mode_en           35
#define currency_en              36
#define air_break_rod_en         37
#define vlm_of_es_blr            38
#define bill_val                 39
#define coin_acc                 40
#define cash_ls_dvc              41
#define es_blr_deg_err_tol       42
#define opn_blr_deg_err_tol      43
#define open_blr_en              44



#endif /* MAIN_HEADER_FILE_ARRAY_DEF_H_ */
