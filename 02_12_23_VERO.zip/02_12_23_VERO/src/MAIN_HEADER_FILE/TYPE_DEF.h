/*
 * TYPE_DEF.h
 *
 *  Created on: 26-Dec-2022
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_TYPE_DEF_H_
#define MAIN_HEADER_FILE_TYPE_DEF_H_

typedef struct gui_data
{
    unsigned char app;
    unsigned char fun;
}GUI_DATA;

typedef struct ch_prcs
{
    unsigned int ch_dly;
    unsigned int wtr_time;
    unsigned int wtr_puls_no;
    unsigned int wtr_puls_time;
    unsigned char wtr_on_off_cnt;
    unsigned int prmx_dly;
    unsigned int prmx_rpm;
    unsigned int prmx_time;
    unsigned int prmx_puls_no;
    unsigned int prmx_puls_time;
    unsigned char prmx_on_of_cnt;
    unsigned int mxr_dly;
    unsigned int mxr_rpm;
    unsigned int mxr_time;
}DRNK_CH;
typedef struct prcs_tmr
{
    unsigned int prcs_ch_dly;
    unsigned int wtr_on_time;
    unsigned int wtr_off_time;
    unsigned int prcs_prmx_dly;
    unsigned int prmx_on_time;
    unsigned int prmx_off_time;
    unsigned int prcs_mxr_dly;
    unsigned int mxr_on_time;

}PRCS_TMR;
typedef struct wtr_prcs
{
    unsigned int scndry_wtr_dly;
    unsigned int scndry_wtr_time;
}WTR_PROCESS;

typedef struct channel_flags
{
    unsigned char one_time_sol_flag;
    unsigned char complete_flag;
    unsigned char solnd_prcs_cmplt;
    unsigned char one_time_prmx_flag;
    unsigned char prmx_prcs_cmplt;
    unsigned char one_time_mxr_flag;
    unsigned char whpr_prcs_cmplete;
    unsigned char ch_dly_complete;
}CHANNEL_FLG;

typedef struct back_up_ch_val
{
    unsigned int backup_wtr_on_time;
    unsigned int backup_wtr_off_time;
    unsigned int backup_prmx_on_time;
    unsigned int backup_prmx_off_time;
    unsigned int backup_mxr_on_time;
}BACK_UP_VAL;


#endif /* MAIN_HEADER_FILE_TYPE_DEF_H_ */
