/*
 * MACROS.h
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_MACROS_H_
#define MAIN_HEADER_FILE_MACROS_H_

/********************************ARITHMETIC LOGIC  ******/
#define AND                         &&
#define OR                          ||
#define EQUAL_TO                    ==
#define NOT_EQUAL_TO                !=
#define XOR                         ^
/********************************ARITHMETIC LOGIC END******/

/****************************I2C *****************************************************************/
#define SDA_LOW                            g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_01,IOPORT_LEVEL_LOW)
#define SDA_HIGH                           g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_01,IOPORT_LEVEL_HIGH)
#define SDA_INPUT                          g_ioport.p_api->pinDirectionSet(IOPORT_PORT_04_PIN_01,IOPORT_DIRECTION_INPUT)
#define SDA_OUTPUT                         g_ioport.p_api->pinDirectionSet(IOPORT_PORT_04_PIN_01,IOPORT_DIRECTION_OUTPUT)

#define SCL_LOW                            g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_00,IOPORT_LEVEL_LOW)
#define SCL_HIGH                           g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_00,IOPORT_LEVEL_HIGH)
/****************************I2C END*****************************************************************/
/********************************LOGICAL VALUE  *****/
#define SET                           1
#define CLEAR_1                       0

#define RD_MODE                      0
/****************RTC**************/

#define RTC_WRITE   0x64
#define RTC_READ    0x65

#define RTC_SECONDS     0x10
#define RTC_MINUTES     0x11
#define RTC_HOURS       0x12
#define RTC_DAY         0x13
#define RTC_DATE        0x14
#define RTC_MONTH       0x15
#define RTC_YEAR        0x16


#define SUNDAY      0x01        //0000 0001
#define MONDAY      0x02        //0000 0010
#define TUESDAY     0x04        //0000 0100
#define WEDNESDAY   0x08        //0000 1000
#define THURSDAY    0x10        //0001 0000
#define FRIDAY      0x20        //0010 0000
#define SATURDAY    0x40        //0100 0000

/*************RTC END*************/

/******************REFILLING*****************/

#define AIR_BRK_LVL_1_PWM_ON                           g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02,IOPORT_LEVEL_HIGH)
#define AIR_BRK_LVL_1_PWM_OFF                          g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_02,IOPORT_LEVEL_LOW)

#define AIR_BRK_LVL_2_PWM_ON                           g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_00,IOPORT_LEVEL_HIGH)
#define AIR_BRK_LVL_2_PWM_OFF                          g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_00,IOPORT_LEVEL_LOW)

#define AIR_BREAK_INLET_VALVE_ON                       g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_11,IOPORT_LEVEL_HIGH),ar_brk_inlt_vlv_flg=SET    //inlet valve 1
#define AIR_BREAK_INLET_VALVE_OFF                      g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_11,IOPORT_LEVEL_LOW),ar_brk_inlt_vlv_flg=CLEAR_1

#define THREE_WAY_VALVE_ON                             g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_12,IOPORT_LEVEL_HIGH),three_way_vlv_flg=SET
#define THREE_WAY_VALVE_OFF                            g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_12,IOPORT_LEVEL_LOW),three_way_vlv_flg=CLEAR_1

#define PRESSURE_PUMP_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_04,IOPORT_LEVEL_HIGH),presure_pump_flg=SET
#define PRESSURE_PUMP_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_04,IOPORT_LEVEL_LOW),presure_pump_flg=CLEAR_1

#define WAT_LVL_1_PWM_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01,IOPORT_LEVEL_HIGH)
#define WAT_LVL_1_PWM_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_01,IOPORT_LEVEL_LOW)

#define WAT_LVL_2_PWM_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00,IOPORT_LEVEL_HIGH)
#define WAT_LVL_2_PWM_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_06_PIN_00,IOPORT_LEVEL_LOW)

#define OPEN_AIR_BOILER_INLET_VALVE_ON                 g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_05,IOPORT_LEVEL_HIGH),open_air_blr_inlet_vlv_flg=SET //inlet valve 2
#define OPEN_AIR_BOILER_INLET_VALVE_OFF                g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_05,IOPORT_LEVEL_LOW),open_air_blr_inlet_vlv_flg=CLEAR_1

/*********************HEATING********************/
#define ESPRESSO_HEATER_ON                             g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_00,IOPORT_LEVEL_HIGH),espresso_heater_on_flg=SET
#define ESPRESSO_HEATER_OFF                            g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_00,IOPORT_LEVEL_LOW),espresso_heater_on_flg=CLEAR_1

#define OPEN_AIR_BLR_HTR_ON                            g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_06,IOPORT_LEVEL_HIGH),air_boiler_heater_on_flg=SET
#define OPEN_AIR_BLR_HTR_OFF                           g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_06,IOPORT_LEVEL_LOW),air_boiler_heater_on_flg=CLEAR_1

#define HEATER_3_ON                                    g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_05,IOPORT_LEVEL_HIGH)
#define HEATER_3_OFF                                   g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_05,IOPORT_LEVEL_LOW)

/*************SOLENOID*****************/
#define SOLENOID1_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_12,IOPORT_LEVEL_HIGH),sol_vlv1_on_flg=SET
#define SOLENOID1_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_12,IOPORT_LEVEL_LOW),sol_vlv1_on_flg=CLEAR_1

#define SOLENOID2_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_13,IOPORT_LEVEL_HIGH),sol_vlv2_on_flg=SET
#define SOLENOID2_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_13,IOPORT_LEVEL_LOW),sol_vlv2_on_flg=CLEAR_1

#define SOLENOID3_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_12,IOPORT_LEVEL_HIGH),sol_vlv3_on_flg=SET
#define SOLENOID3_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_12,IOPORT_LEVEL_LOW),sol_vlv3_on_flg=CLEAR_1

#define SOLENOID4_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_13,IOPORT_LEVEL_HIGH),sol_vlv4_on_flg=SET
#define SOLENOID4_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_13,IOPORT_LEVEL_LOW),sol_vlv4_on_flg=CLEAR_1

#define SOLENOID5_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_04,IOPORT_LEVEL_HIGH),sol_vlv5_on_flg=SET
#define SOLENOID5_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_04,IOPORT_LEVEL_LOW),sol_vlv5_on_flg=CLEAR_1

#define SOLENOID6_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_03,IOPORT_LEVEL_HIGH),sol_vlv6_on_flg=SET
#define SOLENOID6_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_03,IOPORT_LEVEL_LOW),sol_vlv6_on_flg=CLEAR_1

/**************SECONDARY OUTLET***************/
#define HOT_WATER_ON                                   g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_02,IOPORT_LEVEL_HIGH),hot_wtr_on_flg=SET
#define HOT_WATER_OFF                                  g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_02,IOPORT_LEVEL_LOW),hot_wtr_on_flg=CLEAR_1

#define COOLER_ON                                      g_ioport.p_api->pinWrite(IOPORT_PORT_05_PIN_00,IOPORT_LEVEL_HIGH),cold_wtr_on_flg=SET
#define COOLER_OFF                                     g_ioport.p_api->pinWrite(IOPORT_PORT_05_PIN_00,IOPORT_LEVEL_LOW),cold_wtr_on_flg=CLEAR_1

/**************PRIMIX MOTOR***************/
#define PRIMIX_MOTOR1_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_11,IOPORT_LEVEL_HIGH),prmx1_on_flg=SET
#define PRIMIX_MOTOR1_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_11,IOPORT_LEVEL_LOW),prmx1_on_flg=CLEAR_1

#define PRIMIX_MOTOR2_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_12,IOPORT_LEVEL_HIGH),prmx2_on_flg=SET
#define PRIMIX_MOTOR2_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_12,IOPORT_LEVEL_LOW),prmx2_on_flg=CLEAR_1

#define PRIMIX_MOTOR3_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_13,IOPORT_LEVEL_HIGH),prmx3_on_flg=SET
#define PRIMIX_MOTOR3_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_13,IOPORT_LEVEL_LOW),prmx3_on_flg=CLEAR_1

#define PRIMIX_MOTOR4_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_14,IOPORT_LEVEL_HIGH),prmx4_on_flg=SET
#define PRIMIX_MOTOR4_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_14,IOPORT_LEVEL_LOW),prmx4_on_flg=CLEAR_1

#define PRIMIX_MOTOR5_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_15,IOPORT_LEVEL_HIGH),prmx5_on_flg=SET
#define PRIMIX_MOTOR5_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_15,IOPORT_LEVEL_LOW),prmx5_on_flg=CLEAR_1

#define PRIMIX_MOTOR6_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_10,IOPORT_LEVEL_HIGH),prmx6_on_flg=SET
#define PRIMIX_MOTOR6_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_10,IOPORT_LEVEL_LOW),prmx6_on_flg=CLEAR_1

/*****************MIXER MOTOR*****************/
#define MIXER_MOTOR1_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_04,IOPORT_LEVEL_HIGH),mxr1_on_flg=SET
#define MIXER_MOTOR1_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_04,IOPORT_LEVEL_LOW),mxr1_on_flg=CLEAR_1

#define MIXER_MOTOR2_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_05,IOPORT_LEVEL_HIGH),mxr2_on_flg=SET
#define MIXER_MOTOR2_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_05,IOPORT_LEVEL_LOW),mxr2_on_flg=CLEAR_1

#define MIXER_MOTOR3_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_06,IOPORT_LEVEL_HIGH),mxr3_on_flg=SET
#define MIXER_MOTOR3_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_06,IOPORT_LEVEL_LOW),mxr3_on_flg=CLEAR_1

#define MIXER_MOTOR4_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_07,IOPORT_LEVEL_HIGH),mxr4_on_flg=SET
#define MIXER_MOTOR4_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_07,IOPORT_LEVEL_LOW),mxr4_on_flg=CLEAR_1

#define MIXER_MOTOR5_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_07,IOPORT_LEVEL_HIGH),mxr5_on_flg=SET
#define MIXER_MOTOR5_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_07,IOPORT_LEVEL_LOW),mxr5_on_flg=CLEAR_1

#define BEAN_GRINDER_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_03,IOPORT_LEVEL_HIGH),bean_grndr_on_flg=SET
#define BEAN_GRINDER_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_03,IOPORT_LEVEL_LOW),bean_grndr_on_flg=CLEAR_1

#define FRESH_BREWER_ON                                g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_02,IOPORT_LEVEL_HIGH),fresh_brewer_mtr_flg=SET
#define FRESH_BREWER_OFF                               g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_02,IOPORT_LEVEL_LOW),fresh_brewer_mtr_flg=CLEAR_1

#define FAN_ON                                         g_ioport.p_api->pinWrite(IOPORT_PORT_08_PIN_01,IOPORT_LEVEL_HIGH),fan_mtr_flg=SET
#define FAN_OFF                                        g_ioport.p_api->pinWrite(IOPORT_PORT_08_PIN_01,IOPORT_LEVEL_LOW),fan_mtr_flg=CLEAR_1

#define PERISTALTIC_PUMP_ON                            g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_01,IOPORT_LEVEL_HIGH),prstltc_pmp_flg=SET
#define PERISTALTIC_PUMP_OFF                           g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_01,IOPORT_LEVEL_LOW),prstltc_pmp_flg=CLEAR_1

#define TEA_BREW_MTR_ON                                 g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_10,IOPORT_LEVEL_HIGH)
#define TEA_BREW_MTR_OFF                                g_ioport.p_api->pinWrite(IOPORT_PORT_04_PIN_10,IOPORT_LEVEL_LOW)

#define BEEPER_ON                                      g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_15,IOPORT_LEVEL_HIGH),buzzer_on_flg=SET
#define BEEPER_OFF                                     g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_15,IOPORT_LEVEL_LOW),buzzer_on_flg=CLEAR_1

#define DRIP_LVL1_PWM_ON                               g_ioport.p_api->pinWrite(IOPORT_PORT_08_PIN_00,IOPORT_LEVEL_HIGH)
#define DRIP_LVL1_PWM_OFF                              g_ioport.p_api->pinWrite(IOPORT_PORT_08_PIN_00,IOPORT_LEVEL_LOW)

#define BREWER1_FWD_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_01,IOPORT_LEVEL_HIGH)
#define BREWER1_FWD_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_01,IOPORT_LEVEL_LOW)

#define BREWER1_REV_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_02,IOPORT_LEVEL_HIGH)
#define BREWER1_REV_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_02,IOPORT_LEVEL_LOW)

#define BREWER1_PWM_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_03,IOPORT_LEVEL_HIGH)
#define BREWER1_PWM_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_03,IOPORT_LEVEL_LOW)

#define BREWER2_FWD_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_05,IOPORT_LEVEL_HIGH)
#define BREWER2_FWD_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_05,IOPORT_LEVEL_LOW)

#define BREWER2_REV_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_04,IOPORT_LEVEL_HIGH)
#define BREWER2_REV_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_04,IOPORT_LEVEL_LOW)

#define BREWER2_PWM_HIGH                               g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_06,IOPORT_LEVEL_HIGH)
#define BREWER2_PWM_LOW                                g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_06,IOPORT_LEVEL_LOW)


#define ESPRESSO_BREWER_ON                             BREWER1_FWD_HIGH,BREWER1_REV_LOW,BREWER1_PWM_HIGH,es_brwr_mtr_flg=SET
#define ESPRESSO_BREWER_REV_ON                         BREWER1_REV_HIGH,BREWER1_FWD_LOW,BREWER1_PWM_HIGH
#define ESPRESSO_BREWER_OFF                            BREWER1_FWD_LOW,BREWER1_REV_LOW,BREWER1_PWM_LOW,es_brwr_mtr_flg=CLEAR_1

#define BREWER_2_ON                                    BREWER2_FWD_HIGH,BREWER2_REV_LOW,BREWER2_PWM_HIGH
#define BREWER_2_REVERSE_ON                            BREWER2_REV_HIGH,BREWER2_FWD_LOW,BREWER2_PWM_HIGH
#define BREWER_2_REVERSE_OFF                           BREWER2_FWD_LOW,BREWER2_REV_LOW,BREWER2_PWM_LOW

#define ALL_OUT_OFF                                     AIR_BREAK_INLET_VALVE_OFF,THREE_WAY_VALVE_OFF,PRESSURE_PUMP_OFF,OPEN_AIR_BOILER_INLET_VALVE_OFF,\
		                                                ESPRESSO_HEATER_OFF,OPEN_AIR_BLR_HTR_OFF,SOLENOID1_OFF,SOLENOID2_OFF,SOLENOID3_OFF,SOLENOID4_OFF,\
		                                                SOLENOID5_OFF,SOLENOID6_OFF,HOT_WATER_OFF,COOLER_OFF,PRIMIX_MOTOR1_OFF,PRIMIX_MOTOR2_OFF,\
		                                                PRIMIX_MOTOR3_OFF,PRIMIX_MOTOR4_OFF,PRIMIX_MOTOR5_OFF,PRIMIX_MOTOR6_OFF,\
		                                                MIXER_MOTOR1_OFF,MIXER_MOTOR2_OFF,MIXER_MOTOR3_OFF,MIXER_MOTOR4_OFF,MIXER_MOTOR5_OFF,\
		                                                BEAN_GRINDER_OFF,FRESH_BREWER_OFF,ESPRESSO_BREWER_OFF,FAN_OFF,PERISTALTIC_PUMP_OFF


#define CH_TIME_VAL_SKIP                              (ssid==43)OR(ssid==46)OR(ssid==48)OR(ssid==50)OR(ssid==51)OR(ssid==53)
#define ES_FB_BB_TIME_VAL_SKIP                        (ssid==57)OR(ssid==58)OR(ssid==61)OR(ssid==66)OR(ssid==67)OR(ssid==81)OR(ssid==82)OR(ssid==501)
#define GENERAL_SET_SECONDS                           (ssid==108)OR(ssid==116)OR(ssid==119)OR(ssid==122)
#define GENERAL_SET_ARRAY_STORE                       ((ssid==217)OR(ssid==218))?(ssid-180):((ssid>=179)AND(ssid<=181))?(ssid-140):(((ssid>=502)AND(ssid<=504))?(ssid-460):((ssid>=101)AND(ssid<=136))?(ssid-100):0)
#define GERERAL_SET_MINUTES                           (ssid==121)OR(ssid==129)
#define CH_RINSE_SET_EXPT_TIME                        (parmtr_ssid==192)OR(parmtr_ssid==195)
#define FRESH_BRWR_RINSE_EXPT_TIME                    (parmtr_ssid==198)
#define RINSE_ESPRS_BRWR_EXPT_TIME                    (parmtr_ssid==206)
#define FLUSH_ESPRS_BRWR_EXPT_TIME                    (parmtr_ssid==207)OR(parmtr_ssid==211)
#define ESPRS_BRWR_CLNG_CYCL                          (parmtr_ssid==214)
#define ESPRS_DRNK_AFTR_CLNG                          (parmtr_ssid==216)
#define RINSE_SET_MINUS_SSID                          ((rinse_set_id>=1)AND(rinse_set_id<=8))?(parmtr_ssid-190):(rinse_set_id==9?parmtr_ssid-196:(rinse_set_id==10?parmtr_ssid-202:(rinse_set_id==11?parmtr_ssid-203:(rinse_set_id==12?parmtr_ssid-206:(rinse_set_id==13?parmtr_ssid-211:(parmtr_ssid-215))))))

/***************DRINK PROCESS SEQUENCES*****************/
#define GET_STEPS_VALUES                     1
#define CHECK_CH_AVAILABLE_IN_STEPS          2
#define START_PROCESS                        3
#define DRIP_TIME                            4
#define PROCESS_END                          5

/*********SECONDARY DRINK SEQUENCES**********/
#define SCNDARY_DISPENSE                    1
#define SCNDARY_DRIP_TIME                   2
#define SCNDARY_PR_COMPLETE                 3

/************ESPRESSO PROCESS*************/
#define GRINDER                             1
#define MOVE_ES_BREWER_TO_BREW              2
#define PRE_SHOT                            3
#define PULSE_WATER                         4
#define DELAY_TIME                          5
#define MOVE_BRWER_TO_FILL_POS              6
#define END_PROCESS                         7

/***********FRESH BREWER SEQUENCES***********/
#define BREWER_START_DELAY                  1
#define BREWER_STOP_1                       2
#define BREWER_STOP_2                       3
#define BREWER_STOP_3                       4
#define BREWER_STOP_4                       5
#define FIND_HOME_POS                       6

#endif /* MAIN_HEADER_FILE_MACROS_H_ */
