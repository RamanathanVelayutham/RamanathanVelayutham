/*
 * VARIABLES.h
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_VARIABLES_H_
#define MAIN_HEADER_FILE_VARIABLES_H_

#include "STDBOOL.h"
#include "../MAIN_HEADER_FILE/TYPE_DEF.h"

/************machine config************/
bool
cooler_en,
Machine_err_flag,
machine_ready_flg,
ready_flag,
instant_machine_flag,
espresso_machine_flag,
freshbrew_machine_flag,
beanbrew_machine_flag;

unsigned char
//test_time_id,
test_start_time,
machine;

/**********individual rinse***********/
bool
cancel_initiate_flg,
sncdry_vlv_on_flg,
fb_rnse_drp_time_flg,
fb_rnse_wait_flg,
es_paus_tm_flg,
sndry_vlv_rns_prcs_complete_flg,
indvdl_rins_done_snd_flg,
brwr_pos_id_for_rins_snd_flg,
rinse_value_get_flg,
individual_rinse_start_flag;

unsigned char
brwr_pos_id_for_rins,
rinse_set_id,
scndr_vlv_on_off_cnt,
fb_rns_stp,
cycle_count,
close_pos_rins_stp,
rinse_id;

unsigned int
parmtr_ssid,
scndry_vlv_off_tmr,
scndry_vlv_on_tmr,
backup_scndry_wtr_off_time,
backup_scndry_wtr_on_time,
fb_rnse_drp_time,
fb_rns_wait_tmr,
fb_pos_move_tmr,
es_rns_pauz_tmr,
es_rns_wtr_tmr;

/*********Rinse all mixers*******/

bool
mixer_id_send_flg,
cancel_all_mixer_rins_flg,
all_mixer_rinse_done_snd_flg,
start_rinse_from_all_mxr_flg,
all_mixer_rinse_start_flag;

unsigned char
backup_rinse_id,
mixer_id;

/********Rinse All********/

bool
rinse_all_complete_snd_flg,
start_water_valve_flg,
all_mixer_complete_flg,
fb_brwr_rnse_cmplet_flg,
initiate_fb_brwr_rins_flg,
espresso_brwr_rnse_cmplet_flg,
initiate_espresso_brwr_rins_flg,
rinse_all_start_flag;

unsigned char
water_id,
rinse_all_seq;

/*********espresso cleaning*********/

bool
espress_drnk_clng_dspns_complt_flg,
espress_drnk_clng_dspns_strt_flg,
get_esprs_drnk_vlu_flg,
es_soak_tm_flg,
step3_completed_snd_flg,
step2_completed_snd_flg,
step1_completed_snd_flg,
es_cln_strt_flg;

unsigned char
cln_pill_rnse_stp,
opn_pos_rins_stp,
es_clean_stp_id;

unsigned int
es_drnk_brwr_dly_time,
es_drnk_brwr_pauz_time,
es_drnk_cof_wtr_pulz,
es_drnk_pre_brw_wait_time,
es_drnk_pre_brw_wtr_time,
es_drnk_grndr_run_time,
es_drnk_grndr_dly_time,
es_brwr_soak_tmr,
es_brwr_opn_pos_tmr;

/**********fresh brewer movement***********/
bool
frsh_brwr_mvng_done_snd_flg,
move_fb_flg;

unsigned char
fb_move_id;

/***********buzzer***********/

bool
beep_sound_flg,
buzzer_on_flg;

unsigned int
buzzer_on_time;
/*******************************************RTC & I2C**********************************************/
bool
sda_status_flag,
clock_low_flag,
ack_received_flag,
date_time_changed_flag,
date_time_send_flg,
time_update_flag;

unsigned char
date,month,year,hour,minute,week,
one_min_timer,
half_sec_timer,
disp_area[7],
SDA_WRITE,
received_data,
receive_bit_counter,
*ram_addr,
temp_pr[3],
SDA_STATUS,
date_time_arr[7],
temp_rtc_buf[30],
rtc_buf[30];
unsigned int
disp_addr,
ACC;

/*******************************************RTC END**********************************************/
/*********bean errors**********/

bool
grnd_err_get_flg,
no_cof_grnd_err_snd_flg,
grndr_sply_vltg_err_snd_flg,
grndr_mtr_ovr_load_err_snd_flg,
grndr_jmd_err_snd_flg,
grndr_mtr_drvn_lng_err_snd_flg,
grndr_on_at_strtup_err_snd_flg;

unsigned char
grndr_err_id_pulse,
grndr_opn_400_msec_tmr;

/*********canister calibration**********/
bool
calibrate_start_flg,
calibrate_cmplt_flg;

unsigned int
can_run_sec_tmr,
can_run_sec;

unsigned char
canister_id;

/********espresso boiler empty sequence**********/
bool
empt_seq_cmplt_snd_flg,
stop_done_send_flg,
stop_empt_blr_seq_flg,
send_tmp_empt_blr_seq,
emt_blr_seq_strt_flg;

unsigned char
emp_blr_seq;
/********drive output*********/
unsigned char
backup_output_id;

bool
output_off_timeout_flg,
output_off_normal_flg,
brewer_already_in_pos,
output_off_flag,
output_on_flag;

unsigned int
output_id;

/*********sensor status***********/
bool
sensr_sts_req_flg,
first_time_sensor_read_flg,
backup_opn_blr_min_levl,
backup_opn_blr_max_levl,
backup_esp_blr_min_levl,
backup_esp_blr_max_levl,
backup_opn_blr_htr_status,
backup_esp_blr_htr_status,
backup_wst_bin_status,
backup_wst_bin_lvl_status,
backup_fan_status,
backup_drip_lvl_status,
backup_fb_paper_status,
send_sensor_status_flag;

/**************fan****************/
bool
fan_on_during_dispns_flg,
fan_mtr_flg;

unsigned int
fan_on_tmr;

/***********repressurize pump**********/
unsigned char
represr_pump_on_time;

unsigned int
reprsr_intrvl_time_count;
/***********peristaltic pump***********/
bool
prstltc_pmp_flg;

unsigned int
prstltc_pmp_on_time;

/***********Initialization and door**************/
bool
ms_init_start_snd_flg,
entered_maintenance_screen,
block_maintain_scrn_snd_flg,
allow_maintain_scrn_snd_flg,
maintain_screen_init_flag,
door_opened_flg;


/**********refilling************/

/**********Air break refilling************/
unsigned char
ar_brk_min_cnfrm_dly,
es_brwr_flw_err_cnt,
ar_brk_emt_cnfrm_dly,
ar_brk_fl_cnfm_dly,
ar_brk_min_cnt,
ar_brk_max_cnt;;

bool
READ_AIR_BRK_ROD_LVL2_PWM,
READ_AIR_BRK_ROD_LVL1_PWM,
AIR_BRK_ROD_LVL1,
AIR_BRK_ROD_LVL2,
air_break_rod_lvl_1_flg,
air_break_rod_lvl_2_flg,
AIR_BREAK_MIN,
AIR_BREAK_MAX,
AIR_BREAK_INLET_VALVE,
ES_BREWER_PLACED_SW,
container_plcd_flg,
one_tm_cntr_plc_err_snd_flg,
plc_container_undr_outlet_snd_flg,
es_brwr_in_brw_pos_flg,
init_air_break_only_flg,
es_blr_cmplt_flg,
one_tm_blr_fl_snd_flg,
ar_brk_fil_strt_flg,
es_sys_err_snd_flg,
start_es_boilr_fill_flg,
es_boiler_fill_strt_flg,
eprs_blr_flng_snd_flg,
esp_blr_flng_cmplt_snd_flg,
esp_blr_stp_flng_er_snd_flg,
ar_brk_min_cnt_flg,
ar_brk_max_cnt_flg,
stop_at_current_cup_for_ar_brk_flg,
need_clr_aftr_ar_fl_flg,
proceed_refill_ar_brk_flg;

unsigned int
es_flow_count_sec,
dly_pmp_3vlv,
backup_flow_cnt,
es_flw_cnt;

float
bckup_es_flw_cnt;

/************Brewer Init*************/
bool
ESPRESSO_BREWER,
ES_BREW_POS,
ES_FILL_POS,
wait_for_continue_flg,
need_to_get_reinit_cnfrm_flg,
restart_id_2_send_flg,
brwr_stpd_flg,
one_time_brwr_abrt_snd_flg,
brwr_abort_infmation_snd_flg,
init_brwr_alrdy_in_pos_flag,
brewr_en_or_dis,
block_esprs_prdct_till_cln_brwr_flg,
block_esprs_prdct_flg,
plced_es_brwr_err_snd,
pos_cnfrm_flg,
one_tme_brw_plc_err_snd,
es_brwr_err_cnt_flg,
backup_fil_2_brw_cnt_start_flg,
backup_brw_2_fil_cnt_start_flg,
one_tme_brw_plc_err_snd,
plc_es_brwr_err_snd,
brwr_init_send_flg,
brwr_init_done_flg,
for_rnd_2_cycle,
es_brwr_full_rotat_er_snd_flg;
//run_time_pos_chck_flg;

unsigned char
pos_id,
restart_init_with_brwr_fail,
brwr_plced_cnfrm,
brwr_not_plced_cnfrm,
es_brwr_fl_pos_cnfrm_dly,
es_brwr_intr_pos_cnfrm,
es_brwr_brw_pos_cnfrm,
es_brwr_err_cnt;

/*********fb init*********/
bool
init_fb_pos_err_snd_flg,
fb_brwr_err_cnt_flg;

unsigned char
fb_dly_timer,
fb_brwr_err_cnt;
/*************Open air boiler filling***************/

bool
OPEN_AIR_BOILER_WTR_LVL1,
OPEN_AIR_BOILER_WTR_LVL2,
OPEN_AIR_BOILER_INLET_VALVE,
one_tm_open_blr_fl_snd_flg,
opn_blr_fil_strt_flg,
opn_blr_max_cnt_flg,
opn_blr_min_cnt_flg,
opn_blr_flng_snd_flg,
air_blr_sys_err_snd_flg,
opn_blr_flng_done_snd_flg,
air_blr_stp_flng_er_snd_flg,
stop_at_current_cup_for_opn_blr_flg,
need_clr_aftr_opn_blr_fl_flg,
proceed_refill_opn_blr_flg,
blr_lvl1_wtr_flg,
blr_lvl2_wtr_flg;

unsigned char
opn_blr_min_cnfrm_dly,
opn_blr_max_cnt,
opn_blr_fl_cnfm_dly,
open_blr_empt_cnfrm_dly;

unsigned int

opn_blr_min_cnt;

/************espresso boiler temp**************/
bool
read_flg_es_boiler;

unsigned char
es_m;

//float
unsigned char
back_up_es_temp,
es_ctemp;

unsigned short
es_ad_result;

unsigned short
es_acc_temp[20];

//espresso boiler heater
bool
snd_err_aftr_dispns_es_blr,
snd_err_end_of_cup_es_blr,
init_es_htr_strt_flg,
es_ctemp_value_get,
es_htr_snsr_err_snd_flg,
es_blr_rch_tm_err_snd_flg,
one_tm_blr_htng_snd_flg,
one_tm_es_blr_htng_cmplt_snd_flg,
espresso_heater_on_flg,
es_blr_heat_cmplt_flg,
es_blr_htng_snd_flg,
es_htr_err_cnt_flg,
first_es_blr_temp_flag;

unsigned char
es_sensr_err_confm,
es_htr_tmp_chng_cnfrm,
es_reach_set_temp_cnfrm,
below_hystr_temp_cnfrm,
es_htr_snsr_err_cnfrm_dly,
es_htr_err_cnt;

unsigned int
count_es_temp_to_temp;

/************open air boiler temp**************/
bool
read_flg_open_air_boiler;

unsigned char
ar_m;

//float
unsigned char
back_up_ar_ctemp,
ar_ctemp;

unsigned short
open_ar_ad_result;

unsigned short
open_ar_acc_temp[20];

//open boiler heater
bool
snd_err_aftr_dispns_opn_blr,
snd_err_end_of_cup_opn_blr,
init_opn_brl_htr_start_flg,
ar_ctemp_value_get,
air_boiler_heater_on_flg,
opn_blr_heat_cmplt_flg,
one_tm_opn_blr_htng_snd_flg,
one_tm_open_blr_htng_cmplt_snd_flg,
//opn_blr_heat_cmplt_flg,
open_blr_htr_snsr_err_snd_flg,
open_blr_rch_tm_err_snd_flg,
open_blr_htng_snd_flg,
open_blr_htr_err_cnt_flg,
first_ar_blr_temp_flag;

unsigned char
opn_blr_snsr_err_confrm,
ar_htr_tmp_chng_cnfrm,
opn_below_hystr_temp_cnfrm,
opn_reach_set_temp_cnfrm,
opn_htr_snsr_err_cnfrm_dly,
open_blr_htr_err_cnt;

unsigned int
count_ar_temp_to_temp;

/************io read***********/
bool

ar_brk_min_flg,
ar_brk_max_flg,
ar_brk_inlt_vlv_flg,
es_fill_pos_sw_flg,
es_brw_pos_sw_flg,
es_brwr_plc_sw_flg,
es_brwr_mtr_flg,
three_way_vlv_flg,
presure_pump_flg,
open_air_blr_lvl_1_flg,
open_air_blr_lvl_2_flg,
open_air_blr_inlet_vlv_flg,
esprso_heater_flg;

/***********drink process**************/
DRNK_CH ch_process[7];
WTR_PROCESS water_prcs[3];
PRCS_TMR ch_tmr[7];
CHANNEL_FLG ch_flags[7];
BACK_UP_VAL back_up[7];

float
mug_float;

bool
need_stop_drink_due_to_err_flg,
need_to_minus_wtr_vl_frm_byprdct_flg,
need_to_get_wtr_mxr_vl_flg,
getting_prvs_ch_wtr_mix_flg,
stop_scndry_prdct_prcess,
stop_prmry_prdct_prcess,
drip_time_start_flag,
cycle_2_flag,
skip_wtr_mixer_flg,
process_initiated_flag,
double_cup_flag,
multicup_flag,
mug_flag;

unsigned char
main_prdct_wtr_id,
by_prodcut_no,
stages,
wtr_whpr_channels,
drnk_steps,
ch_steps,
step_ch[8],
drnk_split,
drink_id,
drink_id1,
scnd_drink_id,
FOR_CH[7],
drink_id_array[5];

char
str_cmp_rtn;

unsigned int
main_prdct_temp_wtr,
process_drip_time;

/************solenoid*************/
bool
sol_vlv1_on_flg,
sol_vlv2_on_flg,
sol_vlv3_on_flg,
sol_vlv4_on_flg,
sol_vlv5_on_flg,
sol_vlv6_on_flg;

unsigned int
last_sol_on_time;

/************primix pwm***********/
bool
start_prmx1_pwm_flag,
start_prmx2_pwm_flag,
start_prmx3_pwm_flag,
start_prmx4_pwm_flag,
start_prmx5_pwm_flag,
start_prmx6_pwm_flag,
prmx1_on_flg,
prmx2_on_flg,
prmx3_on_flg,
prmx4_on_flg,
prmx5_on_flg,
prmx6_on_flg;

unsigned char
prmx1_pwm_on,
prmx2_pwm_on,
prmx3_pwm_on,
prmx4_pwm_on,
prmx5_pwm_on,
prmx6_pwm_on,
prmx1_pwm_off,
prmx2_pwm_off,
prmx3_pwm_off,
prmx4_pwm_off,
prmx5_pwm_off,
prmx6_pwm_off;


/************mixer pwm***********/
bool
start_mxr1_pwm_flag,
start_mxr2_pwm_flag,
start_mxr3_pwm_flag,
start_mxr4_pwm_flag,
start_mxr5_pwm_flag,
mxr1_on_flg,
mxr2_on_flg,
mxr3_on_flg,
mxr4_on_flg,
mxr5_on_flg;

unsigned char
mxr1_pwm_on,
mxr2_pwm_on,
mxr3_pwm_on,
mxr4_pwm_on,
mxr5_pwm_on,
mxr1_pwm_off,
mxr2_pwm_off,
mxr3_pwm_off,
mxr4_pwm_off,
mxr5_pwm_off;

/************espresso drink**********/
unsigned int
bean_grinder_delay,
bean_grinder_run_time,
dly_time_pre_brew,
pre_brew_time,
delay_time_coffe_watr,
es_brewer_delay_time;

unsigned char
brw_to_fil_cnt,
fill_to_brew_err_cnt,
espresso_sequence;

bool
bean_grndr_on_flg,
from_the_warning_stat_flg,
machine_at_warning,
es_brwr_brew_pos_er_snd_flg,
es_brwr_fil_pos_er_snd_flg,
espresso_procs_cmplete_flag,
brw_2_fil_err_cnt_start_flg,
pre_shot_dly_time_flg,
pre_shot_strt_flg,
dly_time_cof_wtr_pulz_flg,
wtr_flw_cnt_flg,
delay_time_aftr_brw_flg,
fil_2_brw_err_cnt_start_flg,
grinder_run_time_flag,
bean_delay_start_flag;
/***********fresh brew or bean brew**************/
bool
fresh_brew_brewer_flag,
fresh_brew_canister_flg,
bean_brew_grinder_flag,
can_wtr_dly_flg,
can_brwr_wtr_time_flg,
fb_prmx_or_grndr_dly_flg,
fb_prmx_or_grndr_time_flg,
fb_wtr_complete_flg,
fb_prmx_or_grndr_complete_flg;

unsigned int
can_wtr_dly,
can_wtr_run_time,
fb_prmx_or_grndr_dly,
fb_prmx_or_grndr_run_time;

/**********fresh brewer***********/
unsigned char
//fresh_brwr_home_pos_cnfrm_dly,
fb_brewer_stops;

unsigned int
fb_brwr_strtng_dly,
fb_brwr_frst_run,
fb_brwr_frst_stp,
fb_brwr_scnd_run,
fb_brwr_scnd_stp,
fb_brwr_thrd_run,
fb_brwr_thrd_stp,
fb_brwr_frth_run,
fb_brwr_frth_stp;

bool
fresh_brewer_mtr_flg,
//fresh_brwr_home_pos_flag,
fresh_brew_brewer_complete_flg,
fb_brwr_dly_strt_flg,
fb_brwr_frst_run_flg,
fb_brwr_frst_stp_flg,
fb_brwr_scnd_run_flg,
fb_brwr_scnd_stp_flg,
fb_brwr_thrd_run_flg,
fb_brwr_thrd_stp_flg,
fb_brwr_frth_run_flg,
fb_brwr_frth_stp_flg;

/*************switches************/
bool
waste_bin_placed_flg,
one_time_wst_bin_pop_snd_flg,
waste_bin_pop_snd_flg,
wst_bin_prsnt_snd_flg,
wst_bin_not_prsnt_snd_flg,
one_time_wst_bin_not_prsnt_err_snd_flg,
wst_bin_full_err_clr_snd_flg,
wst_bin_full_err_snd_flg,
one_time_wst_bin_ful_err_snd_flg,
fb_brwr_run_time_err_snd_clr_flg,
fb_brwr_run_time_err_snd_flg,
one_time_fb_brwr_err_snd_flg,
out_of_fltr_ppr_err_clr_snd_flg,
out_of_fltr_ppr_err_snd_flg,
one_time_fltr_ppr_err_snd_flg,
JUG_TRAY_SW1,
JUG_TRAY_SW2,
COFFEE_DOSER_SW,
FILTER_PAPER_SW,
TRASH_BIN_FULL_SW,
WASTE_BIN_PRSNT_SW,
FB_BRWR_REST_SW,
DRIP_LVL1,
filter_paper_present,
waste_bin_full,
fb_home_pos_flg,
wast_bin_prsnt_sw;

unsigned char
confrm_no_paper_dly,
ppr_prsnt_cnfrm_dly,
confrm_brwr_not_in_pos_dly,
confrm_brwr_in_pos_dly,
cnfrm_wst_bin_ful_dly,
cnfrm_wst_bin_empt_dly,
cnfrm_wst_bin_not_prsnt_dly,
cnfrm_wst_bin_prsnt_dly;
/***********PRODUCT ADJUSTMENT SCREEN****************/
unsigned char
skip_only_prmx,
scndry_send_cup,
send_cup,
no_of_multicup,
from_adjustment_scr[7];

float
strength[10],
channel_strength[7],
rama_test_float,
es_bean_strength,
frsh_brw_can_strength,
bean_brw_strength;

unsigned int
mltcup_pauz_time;

bool
by_product_selected[7],
//from_adjust_scrn_flg,
//same_step_fb_flag,
double_cup_2nd_cycle_flag,
//fb_diffrent_step_ch1_cmplt_flag,
//fb_diffrent_step_ch2_cmplt_flag,
multicup_start_flag,
mltcup_pauz_strt_flg;

/********SECONDARY DRINK***********/
bool
hot_wtr_on_flg,
cold_wtr_on_flg,
drnk_prmry,
secondary_process_complete,
scondary_drip_time_start_flag,
secondary_drnk_start_flag,
secondary_outlet_process_init_flag,
from_secondary_drink,
hot_or_cold_run_time_flg,
hot_or_cold_wtr_dly_flg;

unsigned char
scndary_no_of_multicup,
scnd_outlet_stages;

unsigned int
scondary_process_drip_time,
hot_or_cold_run_time,
hot_or_cold_wtr_dly_tmr;

/**********drink uart*********/
bool
last_cup_snd_flg,
demo_drink_flg,
scnd_drnk_last_cup_snd_flg,
scndry_multicup_completed_send_flag,
multicup_completed_send_flag,
stop_done_snd_flg,
scndry_stop_done_snd_flg,
drink_compelet_flag,
es_flow_warning_send_flag,
es_flow_war_clr_snd_flg,
es_flow_err_send_flag,
drink_start_send_flag;
/**********timer***********/

unsigned int
fifty_msec_timer;

unsigned char
initial_delay_time,
ten_msec_timer,
ten_sec_tmr,
two_hndrd_msec_tmr,
hndr_msec_timer,
one_msec_timer,
one_sec_timer;

/*********drip tray**********/
unsigned char
drip_lvl1_open_counter,
drip_lvl1_close_counter;

bool
have_drip_tray_place_err_snd_flg,
one_time_drip_try_plc_snd_flg,
drip_tray_placed_flg,
drip_lvl_chk_flag,
drip_tray_empty_send_flg,
drip_tray_full_snd_flg;

/*********factory test***********/
//factory test
bool
ft_from_set_flg,
entered_fctry_tst_flg;

//beeper
bool
beeper_ft_on_flg;

//canister tests
bool
canister_test_done,
canister_initated_flg;

unsigned char
canister_test_id;

//water output tests
bool
enter_for_fb_movement,
wtr_op_test_done,
wtr_op_initated_flg;

unsigned char
fb_ft_test_id,
wtr_op_test_id;

//espresso systems test
bool
reset_fb_tmr_snd_flg,
es_htr_ft_tmp_snd_flg,
es_blr_ht_tst_initiate_flg,
es_fil_tst_initiate_snd_flg,
ft_es_boiler_fill_strt_flg,
dur_es_blr_refl_flg,
air_break_test_fill_start_flg,
es_blr_fil_tst_cmnd_snd_flg,
es_blr_fl_tst_exit_flg,
es_htr_tst_id_snd_flg,
es_htr_ft_strt_flg,
es_blr_heat_ft_exit_flg,
ar_test_popup_flg,
ar_tst_initiate_snd_flg,
ar_brk_tst_stp_cmplt_snd_flg,
exit_ar_brk_tst_flg,
es_brwr_tst_fail_snd_flg,
es_brwr_test_complete_snd_flg,
espso_sys_test_initated_flg;

unsigned char
es_htr_tst_id,
es_blr_fil_tst_id,
ar_brk_tst_case_id,
es_brwr_tst_stp,
es_sys_test_id;

//open air boiler test
bool
block_for_opn_blr_tst,
opn_blr_htr_ft_tmp_snd_flg,
opn_blr_htr_tst_id_snd_flg,
opn_blr_htr_ft_strt_flg,
opn_blr_heat_ft_exit_flg,
opn_blr_ft_fil_strt_flg,
opn_blr_ht_initiate_snd_flg,
opn_blr_fil_tst_cmnd_snd_flg,
opn_blr_fl_tst_exit_flg,
opn_blr_sys_test_initated_flg;

unsigned char
opn_blr_htr_tst_id,
opn_blr_fil_tst_id,
opn_blr_sys_test_id;

//sensor and switch
bool
snsr_sw_popup_flg,
snsr_sw_rdy_flg,
sensr_sw_ft_tst_done_flg,
sensr_sw_ft_stp_complt_flg,
exit_snsr_sw_tst_flg,
snsr_sw_ft_initiate_flg;

unsigned char
snsr_sw_id,
sensr_sw_ft_case_id,
sensr_sw_ft_id;

//demo water runtime
unsigned char
demo_wtr_brwr_pos,
water_ch_id;

unsigned int
demo_wtr_run_time;

bool
wtr_run_time_initiate_flg,
wtr_run_time_done_snd_flg;

#endif /* MAIN_HEADER_FILE_VARIABLES_H_ */
