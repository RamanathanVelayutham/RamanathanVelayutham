/*
 * MDB_VARIABLES.h
 *
 *  Created on: 03-Aug-2023
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_VARIABLES_H_
#define MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_VARIABLES_H_



#include "..\MAIN_HEADER_FILE\MDB_HEADER_FILE\MDB_TYPEDEF.h"
#include "STDBOOL.h"

struct _M_D_B mdb;

bool
payment_st_flg,
//note_coin_credit_amt_flg,
cc_err_flg,
bill_val_err_flg,
vend_success_flg,
ack_to_rdr_res_flg,
session_com_flg,
vend_req_flg,
reader_enable_flg,
setup_price_flg,
expansion_res_flg,
expansion_req_flg,
setup_config_flg2,
setup_config_flg1,
coin_poll_flg,
coin_changer_reset_flg,
coin_type_send_flg,
coin_status_flg,
mdb_uart_send_flg;

unsigned char
mdb_uart_err_clr_cnt,
mdb_uart_send_dly,
mdb_no_of_bytes,
mdb_buff;

unsigned char
mdb_uart_send_buff[70];

unsigned short
mdb_rcvd_buff[50];

unsigned int
mdb_rcve_intrpt_buff[50];

#endif /* MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_VARIABLES_H_ */
