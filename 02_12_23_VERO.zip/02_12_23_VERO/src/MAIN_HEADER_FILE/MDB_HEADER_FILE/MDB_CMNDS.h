/*
 * MDB_CMNDS.h
 *
 *  Created on: 03-Aug-2023
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_CMNDS_H_
#define MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_CMNDS_H_

#define CASHLESS_RESET_CMD      mdb_uart_send_buff[mdb_no_of_bytes++]=0x10,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
								mdb_uart_send_buff[mdb_no_of_bytes++]=0x10,\
								mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CASHLESS_SETUP_CMD      mdb_uart_send_buff[mdb_no_of_bytes++]=0x11,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x01,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x12,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CASLESS_MAX_MIN_PRICE_CMD   mdb_uart_send_buff[mdb_no_of_bytes++]=0x11,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x01,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x12,\
                                    mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define READER_EN_CMD           mdb_uart_send_buff[mdb_no_of_bytes++]=0x14,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x01,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x15,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CASHLESS_POLL_CMD       mdb_uart_send_buff[mdb_no_of_bytes++]=0x12,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x12,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define ACK_CMD             mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                            mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define VEND_REQ_CMD            mdb_uart_send_buff[mdb_no_of_bytes++]=0x13,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x01,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x14,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define VEND_SUCESS_CMD         mdb_uart_send_buff[mdb_no_of_bytes++]=0x13,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x02,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x15,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define SESSION_COM_CMD         mdb_uart_send_buff[mdb_no_of_bytes++]=0x13,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x04,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x17,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_RESET_CMD           mdb_uart_send_buff[mdb_no_of_bytes++]=0X30,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X30,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_SETUP_CMD           mdb_uart_send_buff[mdb_no_of_bytes++]=0X31,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X31,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0


#define BIV_TYPE_CMD            mdb_uart_send_buff[mdb_no_of_bytes++]=0X34,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X30,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_TYP_DIS_CMD         mdb_uart_send_buff[mdb_no_of_bytes++]=0X34,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X34,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_ESCROW_BILL_OUT     mdb_uart_send_buff[mdb_no_of_bytes++]=0X35,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X01,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X36,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0


#define BIV_ESCROW_BILL_IN      mdb_uart_send_buff[mdb_no_of_bytes++]=0X35,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X35,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_STACKER             mdb_uart_send_buff[mdb_no_of_bytes++]=0X36,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X36,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0



#define BIV_POLL_CMD            mdb_uart_send_buff[mdb_no_of_bytes++]=0X33,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X33,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define BIV_0C_5E_CMD           mdb_uart_send_buff[mdb_no_of_bytes++]=0X0C,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X5E,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0XC0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X2A,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0




#define CC_RESET_CMD            mdb_uart_send_buff[mdb_no_of_bytes++]=0x08,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x08,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CC_SETP_CMD             mdb_uart_send_buff[mdb_no_of_bytes++]=0x09,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x09,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CC_TYPE_ENABLE_CMD      mdb_uart_send_buff[mdb_no_of_bytes++]=0X0C,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0xff,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x00,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0X0A,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#define CC_POLL_CMD             mdb_uart_send_buff[mdb_no_of_bytes++]=0x0B,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x0B,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0



#define CC_TUBE_STATUS_CMD      mdb_uart_send_buff[mdb_no_of_bytes++]=0x0A,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=1,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0x0A,\
                                mdb_uart_send_buff[mdb_no_of_bytes++]=0

#endif /* MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_CMNDS_H_ */
