/*
 * MDB_TYPEDEF.h
 *
 *  Created on: 03-Aug-2023
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_TYPEDEF_H_
#define MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_TYPEDEF_H_

typedef enum
{
    START_MDB,          /* 0 */     //0
    MD_NXT_STEP,            /* 1 */
    MDB_END,            /* 2 */
    CASHLESS_RESET,         /* 3 */
    CASHLESS_SETUP,         /* 4 */
    CASHLESS_MAX_MIN_PRICE,     /* 5 */
    CASHLESS_EXP_REQ_ID,        /* 6 */
    CASHLESS_READER_EN,     /* 7 */
    CASHLESS_READER_DS,     /* 8 */
    CASHLESS_POLL,          /* 9 */
    CASHLESS_VEND_REQ,      /* 10 */
    CASHLESS_VEND_SS,       /* 11 */
    CASHLESS_SESSION_COM,       /* 12 */
    BV_RESET,           /* 13 */    //1
    BV_POLL,            /* 14 */    //4
    BV_TYPE,            /* 15 */    //3
    BV_ESCROW_BILL_IN,      /* 16 */
    BV_ESCROW_BILL_OUT,     /* 17 */
    BV_SETUP,           /* 18 */    //2
    BV_STACKER,         /* 19 */
    BV_TYPE_DISABLE,        /* 20 */
    CC_RESET,           /* 21 */
    CC_SETUP,           /* 22 */
    CC_COIN_TYPE,           /* 23 */
    CC_POLL             /* 24 */

}M_D_B;

typedef enum {
FAIL_BVV,
START_BVV,
BVV_ESCROW_IN,
BVV_ESCROW_OUT,
BVV_STACKER,
BVV_END,
}BIV__;

struct _M_D_B
{
    unsigned char
    //escrew_flg:1,
    bill_val_en_flag:1,
    bv_err_flg:1,
    cc_err_flg:1,
    one_time_send_flg:1,
    data_rcvd_flg:1,
    chk_device_flg:1,
    resend_flg:1;
    unsigned char
    mode_bit:1;
    M_D_B step;
    BIV__ b_status;
    unsigned char
    cc_type_value[16],
    bill_type_value[16],
    BV_pol_timer,
    que,
    curent_step,
    retry_cnt;
    unsigned char
    cc_scale_factor,
    queue[20];
    unsigned short
    cc_interval_timer,
    cc_dec_point,
    card_dec_point,
    note_dec_point,
    bill_scale_factor,
    resend_timer,
    card_avl_amt,
    decimal_pont;
    float
    drink_price,
    credit_amount;
    float
    cc_total_amount,
    total_note_amount;

};


#endif /* MAIN_HEADER_FILE_MDB_HEADER_FILE_MDB_TYPEDEF_H_ */
