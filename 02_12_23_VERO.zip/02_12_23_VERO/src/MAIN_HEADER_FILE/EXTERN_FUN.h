/*
 * EXTERN_FUN.h
 *
 *  Created on: 27-Dec-2022
 *      Author: afila
 */

#ifndef MAIN_HEADER_FILE_EXTERN_FUN_H_
#define MAIN_HEADER_FILE_EXTERN_FUN_H_

extern void rinse_process();
extern void all_mixer_rinse();
extern void rinse_all();
extern void espresso_brewer_cleaning();
extern void fresh_brewer_movement();
extern void beep_fun();
extern void time_date_update();
extern void store_date_time();
extern unsigned char eeprom_write_iic(unsigned char , unsigned char );
extern unsigned char eeprom_read_iic(unsigned char , unsigned char );
extern void bean_err();
extern void canister_calibration();
extern void fan_operation();
extern void empty_boiler_sequence();
extern void settings();
extern void air_break_refilling();
extern void clear_init_things();
extern void espresso_brewer_initialization();
extern void fresh_brew_brewer_initialization();
extern void espresso_boiler_fill();
extern void repressurise_pump();
extern void ios_read();
extern void water_lvl2_pwm();
extern void water_lvl1_pwm();
extern void open_air_boiler_filling();
extern void check_temperature();
extern void espresso_boiler_heating();
extern void air_boiler_check_temperature();
extern void open_air_boiler_heating();
extern void ios_flag();
extern void steps();
extern void solenoid_fun(unsigned char );
extern void powder_motor_fun(unsigned char );
extern void prmx1_rpm();
extern void prmx2_rpm();
extern void prmx3_rpm();
extern void prmx4_rpm();
extern void prmx5_rpm();
extern void prmx6_rpm();
extern void mixer_motor_fun(unsigned char );
extern void mxr1_rpm();
extern void mxr2_rpm();
extern void mxr3_rpm();
extern void mxr4_rpm();
extern void mxr5_rpm();
extern void espresso_dispens_process();
extern void fb_pwdr_fun();
extern void fresh_brewer();
extern void sensors();
extern void remove_ssid_value(unsigned char,unsigned int,unsigned char []);
extern float check_strength(unsigned char );
extern float mug_fn(unsigned char);
extern void drip_tray_level_pulse();
extern void drip_tray_confirm();
extern void brewer_drive_ouput();
extern void drive_outputs();
extern void air_break_lvl1_pwm();
extern void air_break_lvl2_pwm();
extern void fatory_test();
extern void snsr_status_chck();
extern void test_switches();
extern void mdb_reader_timer();
extern void mdb_queue();
extern void mdb_protocol();
extern unsigned char number_len(unsigned long int );
extern void drip_tray_confirm();
extern void water_run_time();

#endif /* MAIN_HEADER_FILE_EXTERN_FUN_H_ */
