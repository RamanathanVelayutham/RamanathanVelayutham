#include "ANDROID_UART.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_VARIABLES.h"


int remove_stuff_byte(int );
int received_check_sum(int );
void received_fine_buf(int );
void uart_receive_process();
void check_app_fun_id();
extern void remove_ssid_data();
extern void gui_msg_send_fun();
extern void receive_data_process_fun();
extern void drink_settings();
extern void channel_settings();

unsigned char fing_check_sum;

/* android_uart entry function */
void ANDROID_UART_entry(void)
{
   // unsigned char final_data_send_buff[20]="HANDSHAKE",transmit_no_of_bytes=9;


    /* TODO: add your own code here */
    android_uart.p_api->open(android_uart.p_ctrl,android_uart.p_cfg);
    android_uart.p_api->read(android_uart.p_ctrl,android_uart_rx_buffer,1);
    while (1)
    {
        gui_msg_send_fun();
        receive_data_process_fun();
        /********************If any error occurs in the uart call back need to restart the Uart Module by using the below steps********/
         if(uart_restart_flag)
         {
             android_uart.p_api->close(android_uart.p_ctrl);
             tx_thread_sleep (2);
             android_uart.p_api->open(android_uart.p_ctrl,android_uart.p_cfg);
             android_uart.p_api->read(android_uart.p_ctrl,android_uart_rx_buffer,1);
             uart_restart_flag=CLEAR_1;
         }
         /********************If any error occurs in the uart call back need to restart the Uart Module by using the above steps********/
         if(receive_complete_flag)
         {
             uart_receive_process();
             receive_complete_flag=CLEAR_1;
         }

        tx_thread_sleep (1);
    }
}

void ANDROID_UART_CALLBACK(uart_callback_args_t *p_args)
{
//    ssp_err_t status;

    switch(p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
                                            tx_complete_flag=SET;
                                            break;
       case UART_EVENT_RX_COMPLETE:
                                           uart_error_clear_count=20;
                                           uart_main_buf[rx_data]=android_uart_rx_buffer[0];
                                           if(rx_data<MAX_SIZE_RX_BUF)
                                           rx_data++;
                                           android_uart.p_api->read(android_uart.p_ctrl,android_uart_rx_buffer,1);
                                           if(uart_main_buf[0]==START_BYTE)
                                           {
                                               if(uart_main_buf[rx_data-1]==END_BYTE)
                                               {
                                                   buf_length=rx_data;
                                                   rx_data=0;
                                                   receive_complete_flag=SET;
                                               }
                                           }
                                           else
                                           rx_data=0;
                                           break;
       case UART_EVENT_ERR_PARITY:
       case UART_EVENT_ERR_FRAMING:
       case UART_EVENT_BREAK_DETECT:
       case UART_EVENT_ERR_OVERFLOW:
       case UART_EVENT_ERR_RXBUF_OVERFLOW:
                                           rx_data=0;
                                           uart_restart_flag=SET;
                                            break;
        default:
                                            break;
    }
}

void uart_receive_process()
{
    uart_error_clear_count=0,rx_data=0;
    total_length=(unsigned int)(remove_stuff_byte(buf_length));
    total_data_bytes=uart_backup_buf[2]<<8;
    total_data_bytes=total_data_bytes|uart_backup_buf[3];
    if(total_data_bytes>MAX_SIZE_RX_BUF)
    dlc_err_flag=SET;
    if(!dlc_err_flag)
    {
       chk_sum_err_flag=received_check_sum(total_length);
       check_app_fun_id();
       if((!chk_sum_err_flag)AND(!appid_err_flag)AND(!funid_err_flag)AND(!dlc_err_flag))//AND(uart_backup_buf[6]!='B')
       received_fine_buf(total_length);
    }
}

int remove_stuff_byte(int len)
{
    unsigned int i=0,j=0;
    for(i=0,j=0;i<len;i++,j++)
    {
        if(uart_main_buf[i]==STUFF_BYTE)
        uart_backup_buf[j]=(~uart_main_buf[++i]);
        else
        {
            uart_backup_buf[j]=uart_main_buf[i];
            if(uart_main_buf[i]==END_BYTE)
            break;
        }
    }
    memset(uart_main_buf,0,sizeof(uart_main_buf));
    return j+1;                     //here +1 for include endbyte
}

int received_check_sum(int total_len)
{
    unsigned char temp_check_sum=0;
    unsigned int count,byte_1;
    for(byte_1=START_FROM,count=0;byte_1<total_len-2;byte_1++,count++)
    temp_check_sum=(temp_check_sum+(count^(uart_backup_buf[byte_1])));
    temp_check_sum=~(temp_check_sum+uart_backup_buf[HEADER_BYTE]);
    fing_check_sum=temp_check_sum;
    if(temp_check_sum==uart_backup_buf[total_len-2])
    return 0;
    else
    return 1;
}

void received_fine_buf(int total_len)
{
    unsigned int i,byte;
    memset(process_data_buf,0,sizeof(process_data_buf));

    if(((app_id==0X02)AND((fun_id>=CHANNEL_CONFIGURATION)AND(fun_id<=RINSE_MENU_SETTINGS)))OR((app_id==0X07)AND(fun_id==0X02)))
    {
        for(byte=DATA_START,i=0;byte<total_len-2;byte++,i++)
        string_process_data_buf[i]=uart_backup_buf[byte];
        settings();
        memset(string_process_data_buf,0,sizeof(string_process_data_buf));
    }
    else
    {
        for(byte=DATA_START,i=0;byte<total_len-2;byte++,i++)
        process_data_buf[i]=uart_backup_buf[byte];
    }
    memset(uart_backup_buf,0,sizeof(uart_backup_buf));
    process_data_rcvd_success_flag=SET;
}

void check_app_fun_id()
{
    unsigned char i,j,app_fun_id[TOTAL_APP_ID][MAX_FUN_ID+1]={
                                    {0X01,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0x09,0x0A},    //here this has all appid and fun id
                                                {0X02,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E,0X0F,0X10,0X11,0X12,0X13,0X14,0X15,0X16,0X17,0X18,},
                                                            {0X03,0X01,0X02,},
                                        {0X04,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,},
                                        {0X05,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,},
                                    {0X06,0X01,0X02,0X03,},
                                        {0X07,0X01,0X02,},
                                    {0X08,0X01,},
                                    {0X09,0X01,},
                                    {0X0A,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,},
                                    {0X0B,0X01,0X02,0X03,0X04,0X05,},
                                    {0X0C,0X01,},
                                    {0X0D,0X01,0X02,},
                                    {0X0E,0X01,0X02,},
                                    {0X0F,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,0X0B,0X0C,0X0D,0X0E,0X0F,0X10,0X11,0X12,0X13,0X14,0X15,0X16,0X17,0X18,0X19,0X1A,0X1B,0X1C,0X1D,0X1E,0X1F,0X20,0X21,0X22,0X23,0X24,},
                                    {0X11,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09,0X0A,},
                                  };

    if(((app_id=uart_backup_buf[4])>0)AND((fun_id=uart_backup_buf[5])>0))
    {
        appid_err_flag=funid_err_flag=1;
        for(i=0;i<TOTAL_APP_ID;i++)
        {
            if(app_fun_id[i][0]==app_id)
            {
                    appid_err_flag=0;
                    for(j=0;j<(MAX_FUN_ID+1);j++)
                    {
                        if((j>0)AND(app_fun_id[i][j]==fun_id))
                        {
                            funid_err_flag=0;
                            break;
                        }
                    }
                break;
            }

        }
    }
    else
    {
        if(app_id==0)
        appid_err_flag=1;
        if(fun_id==0)
        funid_err_flag=1;
    }
}





