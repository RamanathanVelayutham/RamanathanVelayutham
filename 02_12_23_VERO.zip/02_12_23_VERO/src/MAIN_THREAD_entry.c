#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/MDB_HEADER_FILE/MDB_VARIABLES.h"
/* main thread entry function */

extern void ios_read();
extern void drink_process();
extern void secondary_outlet_drink();
void MAIN_THREAD_entry(void)
{
    /* TODO: add your own code here */

    //Initialize the Timer
    g_Timer_Interept.p_api->open(g_Timer_Interept.p_ctrl,g_Timer_Interept.p_cfg);
    g_Timer_Interept.p_api->start(g_Timer_Interept.p_ctrl);
    //Initialize the REFILLING FLOW METER EXTERNAL INTERRUPT
    espresso_flow_intrpt.p_api->open(espresso_flow_intrpt.p_ctrl,espresso_flow_intrpt.p_cfg);
    espresso_flow_intrpt.p_api->enable(espresso_flow_intrpt.p_ctrl);
    //Initialize the GRINDER ERROR FEEDBACK INTERRUPT
    grinder_err_feedback.p_api->open(grinder_err_feedback.p_ctrl,grinder_err_feedback.p_cfg);
    grinder_err_feedback.p_api->enable(grinder_err_feedback.p_ctrl);

    ADC_INTERRUPT.p_api->open(ADC_INTERRUPT.p_ctrl,ADC_INTERRUPT.p_cfg);
    ADC_INTERRUPT.p_api->scanCfg(ADC_INTERRUPT.p_ctrl,ADC_INTERRUPT.p_channel_cfg);
    ADC_INTERRUPT.p_api->scanStart(ADC_INTERRUPT.p_ctrl);


    mdb_com.p_api->open(mdb_com.p_ctrl,mdb_com.p_cfg);
    mdb_com.p_api->read(mdb_com.p_ctrl,mdb_rcve_intrpt_buff,2);

    drnk_genral_set[open_blr_en]=1;
    test_start_time= 100;
//    mdb_queue();
    while (1)
    {

        if(RD_MODE)
        {
//            mdb_protocol();
            ios_read();
            ios_flag();
            check_temperature();
            air_boiler_check_temperature();

//            if(sensr_sts_req_flg)
//                snsr_status_chck();
//            drip_tray_confirm();
//            sensors();
            fatory_test();
//            ESPRESSO_BREWER_ON;
//            ESPRESSO_BREWER_OFF;
//            ESPRESSO_BREWER_REV_ON;
//            ESPRESSO_BREWER_OFF;
//            BREWER_2_ON;
//            BREWER_2_REVERSE_OFF;
//            BREWER_2_REVERSE_ON;
//            BREWER_2_REVERSE_OFF;

/*
            BEEPER_ON;
            BEEPER_OFF;
*/

       /*     if(test_start_time<=0)
            {
            ESPRESSO_BREWER_ON;
            ESPRESSO_BREWER_OFF;
            ESPRESSO_BREWER_REV_ON;
            ESPRESSO_BREWER_OFF;
//
            BREWER_2_ON;
            BREWER_2_REVERSE_OFF;
            BREWER_2_REVERSE_ON;
            BREWER_2_REVERSE_OFF;

//            test_switches();

            //DC OUTPUT 1
            MIXER_MOTOR1_ON;
//            MIXER_MOTOR1_OFF;
            //DC OUTPUT 2
            MIXER_MOTOR2_ON;
//            MIXER_MOTOR2_OFF;
            //DC OUTPUT 3
            MIXER_MOTOR3_ON;
//            MIXER_MOTOR3_OFF;
            //DC OUTPUT 4
            MIXER_MOTOR4_ON;
//            MIXER_MOTOR4_OFF;
            //DC OUTPUT 5
            MIXER_MOTOR5_ON;
//            MIXER_MOTOR5_OFF;
            //DC OUTPUT 6
            TEA_BREW_MTR_ON;
//            TEA_BREW_MTR_OFF;
            //DC OUTPUT 7
            PRIMIX_MOTOR1_ON;
//            PRIMIX_MOTOR1_OFF;
            //DC OUTPUT 8
            PRIMIX_MOTOR2_ON;
//            PRIMIX_MOTOR2_OFF;
            //DC OUTPUT 9
            PRIMIX_MOTOR3_ON;
//            PRIMIX_MOTOR3_OFF;
            //DC OUTPUT 10
            PRIMIX_MOTOR4_ON;
//            PRIMIX_MOTOR4_OFF;
            //DC OUTPUT 11
            PRIMIX_MOTOR5_ON;
//            PRIMIX_MOTOR5_OFF;
            //DC OUTPUT 12
            PRIMIX_MOTOR6_ON;
//            PRIMIX_MOTOR6_OFF;
            //DC OUTPUT 13
            AIR_BREAK_INLET_VALVE_ON;
//            AIR_BREAK_INLET_VALVE_OFF;
            //DC OUTPUT 14
            SOLENOID1_ON;
//            SOLENOID1_OFF;
            //DC OUTPUT 15
            SOLENOID2_ON;
//            SOLENOID2_OFF;
            //DC OUTPUT 16
            SOLENOID3_ON;
//            SOLENOID3_OFF;
            //DC OUTPUT 17
            SOLENOID4_ON;
//            SOLENOID4_OFF;
            //DC OUTPUT 18
            OPEN_AIR_BOILER_INLET_VALVE_ON;
//            OPEN_AIR_BOILER_INLET_VALVE_OFF;
            //DC OUTPUT 19
            SOLENOID5_ON;
//            SOLENOID5_OFF;
            //DC OUTPUT 20
            SOLENOID6_ON;
//            SOLENOID6_OFF;
            //DC OUTPUT 21
            HOT_WATER_ON;
//            HOT_WATER_OFF;
            //DC OUTPUT 22
            PERISTALTIC_PUMP_ON;
//            PERISTALTIC_PUMP_OFF;
            //DC OUTPUT 23
            ESPRESSO_HEATER_ON;
//            ESPRESSO_HEATER_OFF;
            //DC OUTPUT 24
            OPEN_AIR_BLR_HTR_ON;
//            OPEN_AIR_BLR_HTR_OFF;
            //DC OUTPUT 25
            HEATER_3_ON;
//            HEATER_3_OFF;
            //DC OUTPUT 26
            PRESSURE_PUMP_ON;
//            PRESSURE_PUMP_OFF;
            //DC OUTPUT 27
            BEAN_GRINDER_ON;
//            BEAN_GRINDER_OFF;
            //DC OUTPUT 28
            FRESH_BREWER_ON;
//            FRESH_BREWER_OFF;
            //DC OUTPUT 29
            COOLER_ON;
//            COOLER_OFF;
            //DC OUTPUT 30
            FAN_ON;
//            FAN_OFF;
            }*/

        }

        else if((!need_to_get_reinit_cnfrm_flg)AND(initial_delay_time==0))
        {
            if(espresso_machine_flag)
                check_temperature();
            if(espresso_machine_flag?drnk_genral_set[open_blr_en]:1)
                air_boiler_check_temperature();
//            time_date_update();
            if((beep_sound_flg)AND(drnk_genral_set[use_buzzer])AND(!entered_fctry_tst_flg))
                beep_fun();
            if(!Machine_err_flag)
            {
                if((setng_rcved_flg)AND(espresso_machine_flag?es_ctemp_value_get:1)AND(ar_ctemp_value_get))
                {
                    if((entered_fctry_tst_flg)AND(!Machine_err_flag)AND(!ft_from_set_flg))
                    {
                        fatory_test();
                        if(beep_sound_flg)
                        beep_fun();
                        open_air_boiler_filling();
                        open_air_boiler_heating();
                    }
                    else if((factory_test_done_flag)AND(!Machine_err_flag)AND(!initial_delay_flg))
                    {
                        fan_operation();
                        drip_tray_confirm();
                        sensors();
                        if(espresso_machine_flag)
                        {
                            repressurise_pump();
                            if((init_flag)?((!init_brwr_alrdy_in_pos_flag)AND(!need_to_get_reinit_cnfrm_flg)):0)
                            espresso_brewer_initialization();
                            if(((init_flag?((!init_es_htr_strt_flg)AND(init_brwr_alrdy_in_pos_flag)):1))AND(!Machine_err_flag))
                            {
                                    if(!block_esprs_prdct_flg)
                                    {
                                        air_break_refilling();
                                        espresso_boiler_fill();
                                    }
                            }
                            if(((init_flag?((init_es_htr_strt_flg)AND(!one_tm_es_blr_htng_cmplt_snd_flg)):1))AND(!Machine_err_flag))
                            {
                                if(!block_esprs_prdct_flg)
                                espresso_boiler_heating();
                            }
                            empty_boiler_sequence();
                        }
                        else if(((freshbrew_machine_flag)OR(beanbrew_machine_flag))AND(!need_to_get_reinit_cnfrm_flg))
                        {
                            if(init_flag?(!init_brwr_alrdy_in_pos_flag):0)
                            fresh_brew_brewer_initialization();
                        }
                        if(espresso_machine_flag?drnk_genral_set[open_blr_en]:1)
                        {
                            if((((init_flag?((!init_opn_brl_htr_start_flg)AND(!instant_machine_flag?init_brwr_alrdy_in_pos_flag:1)):1)AND(!need_to_get_reinit_cnfrm_flg)))AND(!Machine_err_flag))
                                open_air_boiler_filling();

                            if(((init_flag?((init_opn_brl_htr_start_flg)AND(!one_tm_open_blr_htng_cmplt_snd_flg)):1))AND(!Machine_err_flag))
                            open_air_boiler_heating();
                        }
                        if((init_flag)AND(espresso_machine_flag?one_tm_blr_fl_snd_flg:1)AND(espresso_machine_flag?(drnk_genral_set[open_blr_en]?one_tm_open_blr_fl_snd_flg:1):one_tm_open_blr_fl_snd_flg)AND(espresso_machine_flag?one_tm_es_blr_htng_cmplt_snd_flg:1)AND(espresso_machine_flag?(drnk_genral_set[open_blr_en]?one_tm_open_blr_htng_cmplt_snd_flg:1):one_tm_open_blr_htng_cmplt_snd_flg))
                        {
                            machine_ready_flg=ready_flag=SET;
                            allow_maintain_scrn_snd_flg=SET;
                            init_flag=one_tm_blr_fl_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=CLEAR_1;
                            one_tm_open_blr_fl_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=CLEAR_1;
                        }
                        if(ready_flag)
                        {
                            if(process_initiated_flag)
                                drink_process();
                            if(secondary_outlet_process_init_flag)
                                secondary_outlet_drink();
                            drive_outputs();
                            brewer_drive_ouput();
                            canister_calibration();
                            bean_err();
                            rinse_all();
//                            if(date_time_changed_flag)
//                            store_date_time();
                        }
                        if(entered_maintenance_screen)
                        {
                            rinse_process();
                            all_mixer_rinse();
                            espresso_brewer_cleaning();
                            fresh_brewer_movement();
                            if(sensr_sts_req_flg)
                                snsr_status_chck();
                        }
                        if(ft_from_set_flg)
                        ft_from_set_flg=CLEAR_1;
                    }
                }
            }
            else
                ALL_OUT_OFF;
        }
        tx_thread_sleep (1);
    }
}

void FIFTY_MCR_SEC(timer_callback_args_t *p_args)
{
    switch(p_args->event)
    {
            case TIMER_EVENT_EXPIRED:

                ios_read();
                ios_flag();
                drip_tray_level_pulse();
                water_lvl2_pwm();
                water_lvl1_pwm();


                if(drnk_genral_set[air_break_rod_en])
                {
                    air_break_lvl1_pwm();
                    air_break_lvl2_pwm();
                }
                if(start_prmx1_pwm_flag)
                {
                    if(prmx1_pwm_on>0)
                        prmx1_pwm_on--;
                    else if(prmx1_pwm_off>0)
                        prmx1_pwm_off--;
                    prmx1_rpm();
                }
                else if((process_initiated_flag)AND(!start_prmx1_pwm_flag))
                {
                    prmx1_pwm_on=prmx1_pwm_off=0;
                    if((liquid_choco_ch==1)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx1_on_flg)
                        PRIMIX_MOTOR1_OFF;
                }

                if(start_prmx2_pwm_flag)
                {
                    prmx2_rpm();
                    if(prmx2_pwm_on>0)
                        prmx2_pwm_on--;
                    else if(prmx2_pwm_off>0)
                        prmx2_pwm_off--;
                }
                else if((process_initiated_flag)AND(!start_prmx2_pwm_flag))
                {
                    prmx2_pwm_on=prmx2_pwm_off=0;
                    if((liquid_choco_ch==2)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx2_on_flg)
                        PRIMIX_MOTOR2_OFF;
                }
                if(start_prmx3_pwm_flag)
                {
                    prmx3_rpm();
                    if(prmx3_pwm_on>0)
                        prmx3_pwm_on--;
                    else if(prmx3_pwm_off>0)
                        prmx3_pwm_off--;
                }
                else if((process_initiated_flag)AND(!start_prmx3_pwm_flag))
                {
                    prmx3_pwm_on=prmx3_pwm_off=0;
                    if((liquid_choco_ch==3)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx3_on_flg)
                        PRIMIX_MOTOR3_OFF;
                }
                if(start_prmx4_pwm_flag)
                {
                    prmx4_rpm();
                    if(prmx4_pwm_on>0)
                        prmx4_pwm_on--;
                    else if(prmx4_pwm_off>0)
                        prmx4_pwm_off--;
                }
                else if((process_initiated_flag)AND(!start_prmx4_pwm_flag))
                {
                    prmx4_pwm_on=prmx4_pwm_off=0;
                    if((liquid_choco_ch==4)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx4_on_flg)
                        PRIMIX_MOTOR4_OFF;
                }
                if(start_prmx5_pwm_flag)
                {
                    prmx5_rpm();
                    if(prmx5_pwm_on>0)
                        prmx5_pwm_on--;
                    else if(prmx5_pwm_off>0)
                        prmx5_pwm_off--;
                }
                else if((process_initiated_flag)AND(!start_prmx5_pwm_flag))
                {
                    prmx5_pwm_on=prmx5_pwm_off=0;
                    if((liquid_choco_ch==5)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx5_on_flg)
                        PRIMIX_MOTOR5_OFF;
                }
                if(start_prmx6_pwm_flag)
                {
                    prmx6_rpm();
                    if(prmx6_pwm_on>0)
                        prmx6_pwm_on--;
                    else if(prmx6_pwm_off>0)
                        prmx6_pwm_off--;
                }
                else if((process_initiated_flag)AND(!start_prmx6_pwm_flag))
                {
                    prmx6_pwm_on=prmx6_pwm_off=0;
                    if((liquid_choco_ch==6)AND(prstltc_pmp_flg))
                        PERISTALTIC_PUMP_OFF;
                    else if(prmx6_on_flg)
                        PRIMIX_MOTOR6_OFF;
                }
                if(++fifty_msec_timer>=1000)
                {
                    fifty_msec_timer=0;
                    if(test_start_time>0)
                        test_start_time--;

                    if(grndr_err_id_pulse>0)
                    {
                        if(++grndr_opn_400_msec_tmr>7)
                        {
                            grndr_opn_400_msec_tmr=0;
                            grnd_err_get_flg=SET;
                        }
                    }
                    if((back_up_es_temp!=es_ctemp)AND((espresso_heater_on_flg)OR(emt_blr_seq_strt_flg)))
                    {
                        if(es_htr_tmp_chng_cnfrm<200)
                        es_htr_tmp_chng_cnfrm++;
                    }
                    else
                        es_htr_tmp_chng_cnfrm=0;
                    if((back_up_ar_ctemp!=ar_ctemp)AND(air_boiler_heater_on_flg))
                    {
                        if(ar_htr_tmp_chng_cnfrm<200)
                        ar_htr_tmp_chng_cnfrm++;
                    }
                    else
                        ar_htr_tmp_chng_cnfrm=0;

                    if(drip_lvl1_open_counter<200)
                    drip_lvl1_open_counter++;
                    if(drip_lvl1_close_counter<200)
                    drip_lvl1_close_counter++;
                    if(es_brwr_plc_sw_flg)
                    {
                        if(brwr_not_plced_cnfrm<200)
                            brwr_not_plced_cnfrm++,brwr_plced_cnfrm=0;
                    }
                    else if(!es_brwr_plc_sw_flg)
                    {
                        if(brwr_plced_cnfrm<200)
                            brwr_plced_cnfrm++,brwr_not_plced_cnfrm=0;
                    }
                    if(filter_paper_present)
                    {
                        if(confrm_no_paper_dly<200)
                            confrm_no_paper_dly++,ppr_prsnt_cnfrm_dly=0;
                    }
                    else if(!filter_paper_present)
                    {
                        if(ppr_prsnt_cnfrm_dly<200)
                            ppr_prsnt_cnfrm_dly++,confrm_no_paper_dly=0;
                    }
                    if(fb_home_pos_flg)
                    {
                        if(confrm_brwr_not_in_pos_dly<200)
                            confrm_brwr_not_in_pos_dly++,confrm_brwr_in_pos_dly=0;
                    }
                    else if(!fb_home_pos_flg)
                    {
                        if(confrm_brwr_in_pos_dly<200)
                            confrm_brwr_in_pos_dly++,confrm_brwr_not_in_pos_dly=0;
                    }
                    if(!waste_bin_full)
                    {
                        if(cnfrm_wst_bin_ful_dly<200)
                            cnfrm_wst_bin_ful_dly++,cnfrm_wst_bin_empt_dly=0;
                    }
                    else if(waste_bin_full)
                    {
                        if(cnfrm_wst_bin_empt_dly<200)
                            cnfrm_wst_bin_empt_dly++,cnfrm_wst_bin_ful_dly=0;
                    }
                    if(wast_bin_prsnt_sw)
                    {
                        if(cnfrm_wst_bin_not_prsnt_dly<200)
                            cnfrm_wst_bin_not_prsnt_dly++,cnfrm_wst_bin_prsnt_dly=0;
                    }
                    else if(!wast_bin_prsnt_sw)
                    {
                        if(cnfrm_wst_bin_prsnt_dly<200)
                            cnfrm_wst_bin_prsnt_dly++,cnfrm_wst_bin_not_prsnt_dly=0;
                    }
                    if((ar_brk_min_flg)AND(ar_brk_max_flg))
                    {
                        if(ar_brk_emt_cnfrm_dly<200)
                        ar_brk_emt_cnfrm_dly++;
                        ar_brk_fl_cnfm_dly=ar_brk_min_cnfrm_dly=0;
                    }
                    else if((!ar_brk_min_flg)AND(ar_brk_max_flg))
                    {
                        if(ar_brk_min_cnfrm_dly<200)
                            ar_brk_min_cnfrm_dly++;
                        ar_brk_fl_cnfm_dly=ar_brk_emt_cnfrm_dly=0;
                    }
                    else if((!ar_brk_min_flg)AND(!ar_brk_max_flg))
                    {
                        if(ar_brk_fl_cnfm_dly<200)
                        ar_brk_fl_cnfm_dly++;
                        ar_brk_emt_cnfrm_dly=ar_brk_min_cnfrm_dly=0;
                    }
                    else
                    ar_brk_fl_cnfm_dly=ar_brk_emt_cnfrm_dly=ar_brk_min_cnfrm_dly=0;

                    if((blr_lvl1_wtr_flg)AND(blr_lvl2_wtr_flg))
                    {
                        if(open_blr_empt_cnfrm_dly<200)
                            open_blr_empt_cnfrm_dly++;
                        opn_blr_fl_cnfm_dly=opn_blr_min_cnfrm_dly=0;
                    }
                    else if((!blr_lvl1_wtr_flg)AND(blr_lvl2_wtr_flg))
                    {
                        if(opn_blr_min_cnfrm_dly<200)
                            opn_blr_min_cnfrm_dly++;
                        opn_blr_fl_cnfm_dly=open_blr_empt_cnfrm_dly=0;
                    }
                    else if((!blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg))
                    {
                        if(opn_blr_fl_cnfm_dly<200)
                            opn_blr_fl_cnfm_dly++;
                        open_blr_empt_cnfrm_dly=opn_blr_min_cnfrm_dly=0;
                    }

                    if(++hndr_msec_timer>1)
                    {
                        if(fb_dly_timer>0)
                            fb_dly_timer--;
                        hndr_msec_timer=0;
                        if(es_ad_result>1000)
                            es_sensr_err_confm++;
                        else
                            es_sensr_err_confm=0;
                        if(open_ar_ad_result>1000)
                            opn_blr_snsr_err_confrm++;
                        else
                            opn_blr_snsr_err_confrm=0;
                        if(!brwr_stpd_flg)
                        {
                            if(es_brwr_err_cnt_flg)
                            es_brwr_err_cnt++;
                            else if(fb_brwr_err_cnt_flg)
                                fb_brwr_err_cnt++;
                        }
                        if((fil_2_brw_err_cnt_start_flg)AND(!es_fill_pos_sw_flg))      //fil-to-brew count run when not in fill position
                            fill_to_brew_err_cnt++,brw_to_fil_cnt=0;
                        else if((brw_2_fil_err_cnt_start_flg)AND(es_brw_pos_sw_flg))  // brew-to-fill count run when moved from brew pos
                            brw_to_fil_cnt++,fill_to_brew_err_cnt=0;
                        else
                            fill_to_brew_err_cnt=brw_to_fil_cnt=0;
                        if(!read_flg_es_boiler)
                            read_flg_es_boiler=SET;
                        if(es_ctemp>=125)
                        {
                            es_reach_set_temp_cnfrm=es_reach_set_temp_cnfrm=0;
                            if(es_htr_snsr_err_cnfrm_dly<200)
                            es_htr_snsr_err_cnfrm_dly++;
                        }
                        else if(init_flag?es_ctemp<drnk_genral_set[es_op_set_temp]:es_ctemp<drnk_genral_set[es_op_set_temp]-drnk_genral_set[es_max_temp_var])
                        {
                            es_reach_set_temp_cnfrm=es_htr_snsr_err_cnfrm_dly=0;
                            if(below_hystr_temp_cnfrm<200)
                                below_hystr_temp_cnfrm++;
                        }
                        else if(es_ctemp>=drnk_genral_set[es_op_set_temp])
                        {
                            below_hystr_temp_cnfrm=es_htr_snsr_err_cnfrm_dly=0;
                            if(es_reach_set_temp_cnfrm<200)
                            es_reach_set_temp_cnfrm++;
                        }
                        if(ar_ctemp>=108)
                        {
                            opn_reach_set_temp_cnfrm=opn_below_hystr_temp_cnfrm=0;
                            if(opn_htr_snsr_err_cnfrm_dly<200)
                                opn_htr_snsr_err_cnfrm_dly++;
                        }
                        else if(init_flag?ar_ctemp<drnk_genral_set[op_set_temp]:ar_ctemp<(drnk_genral_set[op_set_temp]-drnk_genral_set[max_temp_vari]))
                        {
                            opn_htr_snsr_err_cnfrm_dly=opn_reach_set_temp_cnfrm=0;
                            if(opn_below_hystr_temp_cnfrm<200)
                                opn_below_hystr_temp_cnfrm++;
                        }
                        else if(ar_ctemp>=drnk_genral_set[op_set_temp])
                        {
                            opn_htr_snsr_err_cnfrm_dly=opn_below_hystr_temp_cnfrm=0;
                            if(opn_reach_set_temp_cnfrm<200)
                                opn_reach_set_temp_cnfrm++;
                        }
                    }
                    if(++two_hndrd_msec_tmr>3)
                    {
                        two_hndrd_msec_tmr=0;

                        if(!read_flg_open_air_boiler)
                            read_flg_open_air_boiler=SET;
                    }
                    if(++half_sec_timer>=10)
                    {
                        half_sec_timer=0;
                        if(!time_update_flag)
                        time_update_flag=SET;
                    }
                    if(++one_sec_timer>=20)
                    {
                        one_sec_timer=0;
                        if(initial_delay_flg)
                            initial_delay_flg=CLEAR_1;
                        if(++one_min_timer>=60)
                        {
                            one_min_timer=0;
//                                date_time_send_flg=SET;
                        }
                        if(fan_on_tmr>0)
                            fan_on_tmr--;
                        if(es_boiler_fill_strt_flg)
                        es_brwr_flw_err_cnt++;
                        if(wtr_flw_cnt_flg)
                            es_brwr_flw_err_cnt++;
                        if(ar_brk_inlt_vlv_flg)
                        {
                            if(ar_brk_min_cnt_flg)
                            ar_brk_min_cnt++;
                            else if(ar_brk_max_cnt_flg)
                            ar_brk_max_cnt++;
                        }
                        if(open_air_blr_inlet_vlv_flg)
                        {
                            if(opn_blr_min_cnt_flg)
                                opn_blr_min_cnt++;
                            else if(opn_blr_max_cnt_flg)
                                opn_blr_max_cnt++;
                        }
                        if(drnk_genral_set[use_blr_perdc_reprsr])
                        {
//                                reprsr_intrvl_time_count=!presure_pump_flg?(reprsr_intrvl_time_count+1):0;
                            if(!presure_pump_flg)
                                reprsr_intrvl_time_count++;
                        }
                    }
                    if(++ten_sec_tmr>=200)
                    {
                        ten_sec_tmr=0;
                        if(es_htr_err_cnt_flg)
                        es_htr_err_cnt++;
                        if(open_blr_htr_err_cnt_flg)
                            open_blr_htr_err_cnt++;
                    }

                }
                if(++one_msec_timer>=20)
                {
                    one_msec_timer=0;
                    if(initial_delay_time>0)
                        initial_delay_time--;
                    if(buzzer_on_time>0)
                        buzzer_on_time--;
                    if(trasmit_dly>0)
                    trasmit_dly--;
                    if(++ten_msec_timer>=10)
                    {
                        ten_msec_timer=0;

                        if(es_fill_pos_sw_flg)
                        {
                            es_brwr_brw_pos_cnfrm=es_brwr_intr_pos_cnfrm=0;
                            if(es_brwr_fl_pos_cnfrm_dly<100)
                            es_brwr_fl_pos_cnfrm_dly++;
                        }
                        else if(!es_brw_pos_sw_flg)
                        {
                            es_brwr_intr_pos_cnfrm=es_brwr_fl_pos_cnfrm_dly=0;
                            if(es_brwr_brw_pos_cnfrm<100)
                            es_brwr_brw_pos_cnfrm++;
                        }
                        else
                        {
                            es_brwr_brw_pos_cnfrm=es_brwr_fl_pos_cnfrm_dly=0;
                            if(es_brwr_intr_pos_cnfrm<100)
                            es_brwr_intr_pos_cnfrm++;
                        }
                        if(scndry_vlv_off_tmr>0)
                            scndry_vlv_off_tmr--;
                        else if(scndry_vlv_on_tmr>0)
                            scndry_vlv_on_tmr--;

                        if(es_rns_wtr_tmr>0)
                            es_rns_wtr_tmr--;
                        else if(es_brwr_opn_pos_tmr>0)
                            es_brwr_opn_pos_tmr--;
                        else if(es_rns_pauz_tmr>0)
                            es_rns_pauz_tmr--;
                        else if(es_brwr_soak_tmr>0)
                            es_brwr_soak_tmr--;

                        if(fb_pos_move_tmr>0)
                            fb_pos_move_tmr--;
                        else if(fb_rns_wait_tmr>0)
                            fb_rns_wait_tmr--;
                        else if(fb_rnse_drp_time>0)
                            fb_rnse_drp_time--;

                        if(can_run_sec_tmr>0)
                            can_run_sec_tmr--;
                        if((back_up_es_temp==es_ctemp)AND(espresso_heater_on_flg))
                        {
                            if(drnk_genral_set[es_htr_temp_temp_err_en])
                               count_es_temp_to_temp++;
                        }
                        else
                            count_es_temp_to_temp=0;

                        if((back_up_ar_ctemp==ar_ctemp)AND(air_boiler_heater_on_flg))
                        {
                            if(drnk_genral_set[htr_temp_temp_err_en])
                                count_ar_temp_to_temp++;
                        }
                        else
                            count_ar_temp_to_temp=0;

                        if((backup_flow_cnt==es_flw_cnt)AND((three_way_vlv_flg)AND(presure_pump_flg)))
                        {
                            if(drnk_genral_set[flow_puls_puls_err_en])
                                es_flow_count_sec++;
                        }
                        else
                            es_flow_count_sec=0;
                        if(represr_pump_on_time>0)
                            represr_pump_on_time--;

                        if(ch_tmr[1].prcs_ch_dly>0)
                            ch_tmr[1].prcs_ch_dly--;
                        if(ch_tmr[2].prcs_ch_dly>0)
                            ch_tmr[2].prcs_ch_dly--;
                        if(ch_tmr[3].prcs_ch_dly>0)
                            ch_tmr[3].prcs_ch_dly--;
                        if(ch_tmr[4].prcs_ch_dly>0)
                            ch_tmr[4].prcs_ch_dly--;
                        if(ch_tmr[5].prcs_ch_dly>0)
                            ch_tmr[5].prcs_ch_dly--;
                        if(ch_tmr[6].prcs_ch_dly>0)
                            ch_tmr[6].prcs_ch_dly--;

                        if(ch_tmr[1].wtr_on_time>0)
                            ch_tmr[1].wtr_on_time--;
                        if(ch_tmr[2].wtr_on_time>0)
                            ch_tmr[2].wtr_on_time--;
                        if(ch_tmr[3].wtr_on_time>0)
                            ch_tmr[3].wtr_on_time--;
                        if(ch_tmr[4].wtr_on_time>0)
                            ch_tmr[4].wtr_on_time--;
                        if(ch_tmr[5].wtr_on_time>0)
                            ch_tmr[5].wtr_on_time--;
                        if(ch_tmr[6].wtr_on_time>0)
                            ch_tmr[6].wtr_on_time--;

                        if(ch_tmr[1].wtr_off_time>0)
                            ch_tmr[1].wtr_off_time--;
                        if(ch_tmr[2].wtr_off_time>0)
                            ch_tmr[2].wtr_off_time--;
                        if(ch_tmr[3].wtr_off_time>0)
                            ch_tmr[3].wtr_off_time--;
                        if(ch_tmr[4].wtr_off_time>0)
                            ch_tmr[4].wtr_off_time--;
                        if(ch_tmr[5].wtr_off_time>0)
                            ch_tmr[5].wtr_off_time--;
                        if(ch_tmr[6].wtr_off_time>0)
                            ch_tmr[6].wtr_off_time--;

                        if(ch_tmr[1].prcs_prmx_dly>0)
                            ch_tmr[1].prcs_prmx_dly--;
                        if(ch_tmr[2].prcs_prmx_dly>0)
                            ch_tmr[2].prcs_prmx_dly--;
                        if(ch_tmr[3].prcs_prmx_dly>0)
                            ch_tmr[3].prcs_prmx_dly--;
                        if(ch_tmr[4].prcs_prmx_dly>0)
                            ch_tmr[4].prcs_prmx_dly--;
                        if(ch_tmr[5].prcs_prmx_dly>0)
                            ch_tmr[5].prcs_prmx_dly--;
                        if(ch_tmr[6].prcs_prmx_dly>0)
                            ch_tmr[6].prcs_prmx_dly--;

                        if(ch_tmr[1].prmx_on_time>0)
                            ch_tmr[1].prmx_on_time--;
                        if(ch_tmr[2].prmx_on_time>0)
                            ch_tmr[2].prmx_on_time--;
                        if(ch_tmr[3].prmx_on_time>0)
                            ch_tmr[3].prmx_on_time--;
                        if(ch_tmr[4].prmx_on_time>0)
                            ch_tmr[4].prmx_on_time--;
                        if(ch_tmr[5].prmx_on_time>0)
                            ch_tmr[5].prmx_on_time--;
                        if(ch_tmr[6].prmx_on_time>0)
                            ch_tmr[6].prmx_on_time--;

                        if(ch_tmr[1].prmx_off_time>0)
                            ch_tmr[1].prmx_off_time--;
                        if(ch_tmr[2].prmx_off_time>0)
                            ch_tmr[2].prmx_off_time--;
                        if(ch_tmr[3].prmx_off_time>0)
                            ch_tmr[3].prmx_off_time--;
                        if(ch_tmr[4].prmx_off_time>0)
                            ch_tmr[4].prmx_off_time--;
                        if(ch_tmr[5].prmx_off_time>0)
                            ch_tmr[5].prmx_off_time--;
                        if(ch_tmr[6].prmx_off_time>0)
                            ch_tmr[6].prmx_off_time--;

                        if(ch_tmr[1].prcs_mxr_dly>0)
                            ch_tmr[1].prcs_mxr_dly--;
                        if(ch_tmr[2].prcs_mxr_dly>0)
                            ch_tmr[2].prcs_mxr_dly--;
                        if(ch_tmr[3].prcs_mxr_dly>0)
                            ch_tmr[3].prcs_mxr_dly--;
                        if(ch_tmr[4].prcs_mxr_dly>0)
                            ch_tmr[4].prcs_mxr_dly--;
                        if(ch_tmr[5].prcs_mxr_dly>0)
                            ch_tmr[5].prcs_mxr_dly--;

                        if(ch_tmr[1].mxr_on_time>0)
                            ch_tmr[1].mxr_on_time--;
                        if(ch_tmr[2].mxr_on_time>0)
                            ch_tmr[2].mxr_on_time--;
                        if(ch_tmr[3].mxr_on_time>0)
                            ch_tmr[3].mxr_on_time--;
                        if(ch_tmr[4].mxr_on_time>0)
                            ch_tmr[4].mxr_on_time--;
                        if(ch_tmr[5].mxr_on_time>0)
                            ch_tmr[5].mxr_on_time--;

                        if(fb_prmx_or_grndr_dly>0)
                            fb_prmx_or_grndr_dly--;
                        if(fb_prmx_or_grndr_run_time>0)
                            fb_prmx_or_grndr_run_time--;
                        if(can_wtr_dly>0)
                            can_wtr_dly--;
                        if(can_wtr_run_time>0)
                            can_wtr_run_time--;

                        if(process_drip_time>0)
                            process_drip_time--;
                        else if(mltcup_pauz_time>0)
                            mltcup_pauz_time--;

                        if(bean_grinder_delay>0)
                            bean_grinder_delay--;
                        else if(bean_grinder_run_time>0)
                            bean_grinder_run_time--;
                        else if(dly_time_pre_brew>0)
                            dly_time_pre_brew--;
                        else if(pre_brew_time>0)
                            pre_brew_time--;
                        else if(delay_time_coffe_watr>0)
                            delay_time_coffe_watr--;
                        else if(dly_pmp_3vlv>0)
                            dly_pmp_3vlv--;
                        else if(es_brewer_delay_time>0)
                            es_brewer_delay_time--;

                        if(fb_brwr_strtng_dly>0)
                            fb_brwr_strtng_dly--;
                        else if(fb_brwr_frst_run>0)
                            fb_brwr_frst_run--;
                        else if(fb_brwr_frst_stp>0)
                            fb_brwr_frst_stp--;
                        else if(fb_brwr_scnd_run>0)
                            fb_brwr_scnd_run--;
                        else if(fb_brwr_scnd_stp>0)
                            fb_brwr_scnd_stp--;
                        else if(fb_brwr_thrd_run>0)
                            fb_brwr_thrd_run--;
                        else if(fb_brwr_thrd_stp>0)
                            fb_brwr_thrd_stp--;
                        else if(fb_brwr_frth_run>0)
                            fb_brwr_frth_run--;
                        else if(fb_brwr_frth_stp>0)
                            fb_brwr_frth_stp--;

                        if(hot_or_cold_wtr_dly_tmr>0)
                            hot_or_cold_wtr_dly_tmr--;
                        else if(hot_or_cold_run_time>0)
                            hot_or_cold_run_time--;
                        else if(scondary_process_drip_time>0)
                            scondary_process_drip_time--;
                    }
                }
                if(start_mxr1_pwm_flag)
                {
                    if(mxr1_pwm_on>0)
                        mxr1_pwm_on--;
                    else if(mxr1_pwm_off>0)
                        mxr1_pwm_off--;
                    mxr1_rpm();
                }
                else if((process_initiated_flag)AND(!start_mxr1_pwm_flag))
                {
                    mxr1_pwm_on=mxr1_pwm_off=0;
                    MIXER_MOTOR1_OFF;
                }
                if(start_mxr2_pwm_flag)
                {
                    if(mxr2_pwm_on>0)
                        mxr2_pwm_on--;
                    else if(mxr2_pwm_off>0)
                        mxr2_pwm_off--;
                    mxr2_rpm();
                }
                else if((process_initiated_flag)AND(!start_mxr2_pwm_flag))
                {
                    mxr2_pwm_on=mxr2_pwm_off=0;
                    MIXER_MOTOR2_OFF;
                }
                if(start_mxr3_pwm_flag)
                {
                    if(mxr3_pwm_on>0)
                        mxr3_pwm_on--;
                    else if(mxr3_pwm_off>0)
                        mxr3_pwm_off--;
                    mxr3_rpm();
                }
                else if((process_initiated_flag)AND(!start_mxr3_pwm_flag))
                {
                    mxr3_pwm_on=mxr3_pwm_off=0;
                    MIXER_MOTOR3_OFF;
                }
                if(start_mxr4_pwm_flag)
                {
                    if(mxr4_pwm_on>0)
                        mxr4_pwm_on--;
                    else if(mxr4_pwm_off>0)
                        mxr4_pwm_off--;
                    mxr4_rpm();
                }
                else if((process_initiated_flag)AND(!start_mxr4_pwm_flag))
                {
                    mxr4_pwm_on=mxr4_pwm_off=0;
                    MIXER_MOTOR4_OFF;
                }
                if(start_mxr5_pwm_flag)
                {
                    if(mxr5_pwm_on>0)
                       mxr5_pwm_on--;
                   else if(mxr5_pwm_off>0)
                       mxr5_pwm_off--;
                   mxr5_rpm();
                }
                else if((process_initiated_flag)AND(!start_mxr5_pwm_flag))
                {
                    mxr5_pwm_on=mxr5_pwm_off=0;
                    MIXER_MOTOR5_OFF;
                }
                break;
            default:
                break;

    }
}
void ESPRESSO_WATER_FLOW_CALLBACK(external_irq_callback_args_t *p_args)
{
    switch(p_args->channel)
    {
        case 14:
                if(es_flw_cnt>0)
                    es_flw_cnt--;
                break;
        default:
            break;
    }
}
void GRINDER_ERROR_FEEDBACK(external_irq_callback_args_t *p_args)
{
    switch(p_args->channel)
    {
        case 9:
//            if(bean_grndr_on_flg)
//            {
                if(grndr_err_id_pulse<7)
                {
                    grndr_err_id_pulse++;
                    grndr_opn_400_msec_tmr=0;
                }
//            }
            break;
        default:
            break;
    }
}

void MDB_INTERRUPT(uart_callback_args_t *p_args)
{
    switch(p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
                                            break;
       case UART_EVENT_RX_COMPLETE:
           mdb_rcvd_buff[mdb_buff++]=mdb_rcve_intrpt_buff[0];
           mdb_com.p_api->read(mdb_com.p_ctrl,mdb_rcve_intrpt_buff,2);
           mdb_uart_err_clr_cnt=10;
           if((mdb_rcvd_buff[mdb_buff-1]&0x0100)==(0x100))
           {
               if((mdb_rcvd_buff[0]&0x0100)==(0x100))
               mdb.mode_bit=1;
               else
               mdb.mode_bit=0;
               mdb_buff=0;
               mdb.data_rcvd_flg=SET;
           }
           break;
       case UART_EVENT_ERR_PARITY:
       case UART_EVENT_ERR_FRAMING:
       case UART_EVENT_BREAK_DETECT:
       case UART_EVENT_ERR_OVERFLOW:
       case UART_EVENT_ERR_RXBUF_OVERFLOW:
                                            break;
        default:
                                            break;
    }
}
