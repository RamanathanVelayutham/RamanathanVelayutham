/*
 * ANDRD_MACROS.h
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */

#ifndef UART_HEADER_FILE_ANDRD_MACROS_H_
#define UART_HEADER_FILE_ANDRD_MACROS_H_



#define NO_OF_TX_BUFFER      400
#define MAX_SIZE_RX_BUF      2000
#define START_FROM           2
#define DATA_START           6


#define START_BYTE              0x2A
#define HEADER_DATA             0X80
#define STUFF_BYTE              0x1C
#define END_BYTE                0x23


#define TOTAL_APP_ID        20
#define MAX_FUN_ID          40

/***************APP ID&FUN ID**************/
#define MACHINE_INFO                 0X01
#define SETTINGS_DATA                0x02
#define BLOCKING_ERR                 0X03
#define RINSE_MENU                   0X04
#define DRINK_PROCESS                0X05
#define SENSOR_STATUS                0X06
#define RTC_APP_ID                   0X07
#define CRITICAL_ER                  0X09
#define ON_OFF_OUTPUTS               0X0A
#define ESPRESSO_BLR_EMP_SEQ         0X0B
#define WARNING                      0X0D
#define REINIT_POPUP                 0X0E
#define FACTORY_TEST                 0X0F
#define DEMO_DRINK_PROCESS           0X11
#define WATER_RUN_TIME_TEST          0X12

//0X01
#define HANDSHAKE                   0X01
#define VERSION_DETAILS             0X02
#define MACHINE_TYPE                0X03
#define ENTER_MAINTANENCE_SCREEN    0X04
#define EXIT_MAINTANENCE_SCREEN     0X05
#define DOOR_OPENED                 0X06
#define DOOR_CLOSED                 0X07
#define MS_INIT_START               0X08
#define ALLOW_OR_DONT_ALLOW         0X09
#define MACHINE_READY               0X0A

//0x02
#define CHANNEL_CONFIGURATION       0X01
#define DRINK_SETT1                 0X02
#define DRINK_SETT20                0X15
#define GEN_SETT                    0X16
#define MILK_SUGAR_CAN              0X17
#define RINSE_MENU_SETTINGS         0X18

//0X03
#define BLCKING_ERR_SEND            0X01
#define BLCKING_ERR_CLEARED         0x02

//0X04
#define INITIATE_CH_RINSE           0X01
#define CH_RINSE_DONE               0X02
#define RINSE_ALL_MIXER             0X03
#define ALL_MIXER_DONE              0X04
#define RINSE_ALL                   0X05
#define RINSE_ALL_DONE              0X06
#define INITIATE_ESPRS_CLNG         0X07
#define ESPRS_CLNG_STEP_DONE        0X08
#define FRESH_BRWR_MOVING           0X09
#define BRWR_POS_SEND               0X0A
#define CANCEL_RINSE                0X0B
#define RINSE_MIXER_ID              0X0C
#define FB_MVNG_DONE                0X0D
#define ES_DRNK_STRT                0X0E
#define ES_DRNK_DONE                0X0F

//0X05
#define DIRECT_START_INITIATE       0X01
#define DISPENSE_AFTR_ADJUST        0x02
#define SECONDARY_DRINK_INITIATE    0x03
#define DRINK_START                 0x04
#define DRINK_COMPLETED             0x05
#define DRINK_STOP                  0x06
#define STOP_DONE                   0x07
#define MULTICUP_COMPLETED          0X08
#define DEMO_ON                     0X09
#define DEMO_COMPLETED              0X0A

//0X06
#define SENSOR_STATUS_REQ           0X01
#define SENSOR_STATUS_SEND          0X02
#define EXIT_MONITOR_SENSOR         0X03

//0X07
#define RTC_SEND                    0X01
#define CHANGE_RTC                  0X02

//0x09
#define CRTCL_ER_SEND               0X01

//0x0A
#define NORMAL_OUTPUT_ON            0X01
#define NORMAL_OUTPUT_OFF           0X02
#define BREWER_OUTPUT_ON            0X03
#define BREWER_OUTPUT_OFF           0X04
#define BUZZER_ON                   0X05
#define CANISTER_CAL_ON             0X06
#define CANISTER_CAL_OFF            0X07

//0X0b
#define START_EMPTY_SEQ             0X01
#define SEND_TMP                    0X02
#define STOP_EMPTY_SEQ              0X03
#define STOP_DONE_SEQ               0X04
#define COMPLETED_EMPTY_SEQ         0X05


//0x0d
#define ES_FLOW_WARNING             0X01
#define WAR_CLEARED                 0X02

//0x0e
#define INITIATE_THE_REINIT_POPUP   0X01
#define CONTINUE                    0X02

//0x0f
#define FACTORY_TEST_DONE           0X01
#define FACTORY_TST_ENTR            0X02
#define FACTORY_TST_EXIT            0X03
#define BEEPER_INIATE               0X04
#define CANISTER_MTR_INITIATE       0X05
#define CANISTER_MTR_DONE           0X06
#define WTR_MXR_INITIATE            0X07
#define WTR_MXR_DONE                0X08
#define ESP_BRWR_INITIATE           0X09
#define ESP_BRWR_FAIL               0X0A
#define ESP_BRWR_DONE               0X0B
#define AR_BRK_POPUP                0X23
#define AIR_BRK_INITIATE            0X0C
#define AR_BRK_TEST_ID              0X0D
#define AR_BRK_TEST_EXIT            0X0E
#define ES_BLR_FILL_INITATE         0X0F
#define ES_LVL_STS_DONE             0X10
#define ES_BLR_TST_EXIT             0X11
#define ES_BLR_HEAT_INITIATE        0X12
#define ES_BLR_CRNT_TEMP            0X13
#define ES_BLR_HEAT_TST_ID          0X14
#define ES_BLR_HEAT_EXIT            0X15
#define OPN_BLR_FILL_INITIATE       0X16
#define OPN_BLR_LVL_STS_DONE        0X17
#define OPN_BLR_TST_EXIT            0X18
#define OPN_BLR_HEAT_INITIATE       0X19
#define OPN_BLR_CRNT_TEMP           0X1A
#define OPN_BLR_HEAT_TST_ID         0X1B
#define OPN_BLR_HEAT_EXIT           0X1C
#define SNSR_SW_TEST_INITIATE       0X1D
#define SNSR_SW_TEST_ID             0X1E
#define SNSR_SW_TEST_EXIT           0X1F
#define SNSR_SW_TEST_COMP           0X20
#define SNSR_SW_READY_FOR_TEST      0X21
#define SNSR_SW_POPUP               0X22
#define FB_TMR_RESET                0X24

//0X12
#define WTR_RUN_START               0X01
#define WTR_RUN_COMPLETE            0X02


#define STR_COMMMON             1
#define STR_ERR_SEND            2
#define STR_ERR_RMV             3
#define STRNG_OPEN_BLR_TEMP     4
#define STRNG_OPEN_BLR_TEMP_CLR 5
#define STRNG_ES_BLR_TEMP       6
#define STRNG_ES_BLR_TEMP_CLR   7
#define STR_ADD_DRINK_ID        8
#define ADD_DRINK_CUP_AND_ID    9
#define STR_SENSOR_STATUS       10
#define SEND_TMP_FOR_EMPT_BLR   11
#define STR_RTC                 12
#define ESP_CLN_STEP_STR        13
#define STR_TST_OP_ID           14
#define SEND_TMP_FOR_FT_ES_BLR  15
#define SEND_TMP_FOR_FT_OPN_BLR 16
#define STR_BRWR_POS_SEND       17
#define STR_MXR_ID_SND          18


#define HEADER_BYTE     1
#endif /* UART_HEADER_FILE_ANDRD_MACROS_H_ */
