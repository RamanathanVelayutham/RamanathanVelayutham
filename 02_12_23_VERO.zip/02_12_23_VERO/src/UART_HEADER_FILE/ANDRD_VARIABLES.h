/*
 * ANDRD_VARIABLES.h
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */

#ifndef UART_HEADER_FILE_ANDRD_VARIABLES_H_
#define UART_HEADER_FILE_ANDRD_VARIABLES_H_

#include "STDBOOL.h"
#include "../MAIN_HEADER_FILE/TYPE_DEF.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"

/*********Receive*********/
unsigned char
app_id,
fun_id,
uart_error_clear_count,
uart_main_buf[MAX_SIZE_RX_BUF],
uart_backup_buf[MAX_SIZE_RX_BUF],
process_data_buf[MAX_SIZE_RX_BUF],
string_process_data_buf[MAX_SIZE_RX_BUF],
android_uart_rx_buffer[MAX_SIZE_RX_BUF];

unsigned int
total_data_bytes,
total_length,
buf_length,
rx_data;

bool
process_data_rcvd_success_flag,
dlc_err_flag,
chk_sum_err_flag,
appid_err_flag,
funid_err_flag,
receive_complete_flag,
uart_restart_flag,
tx_complete_flag;

/****************Send***************/
GUI_DATA array;

unsigned char
error_id[5],
a_val,
heart_beat_timer,
block_id,
resend_cnt,
trasmit_dly,
header_val,
tx_buff,
transmit_no_of_bytes,
backup_tx_bytes,
backup_tx_store_bytes,
final_data_send_buff[NO_OF_TX_BUFFER],
tx_backup_store_buff[NO_OF_TX_BUFFER],
tx_backup_buff[NO_OF_TX_BUFFER],
temp_send_buf[NO_OF_TX_BUFFER],
gui_tx_buff[NO_OF_TX_BUFFER];

bool
initial_delay_flg,
factory_test_done_flag,
resend_backup_flag,
resend_no_flg,
data_ack_flag,
resend_flag,
gui_send_flg;

/***********send end***********/

/*************receive process*************/
bool
init_flag,
setng_rcved_flg,
version_send_flag,
handshake_rcv_flag;


/************settings********/
unsigned int
drnk_set_len,
ssid,
rnse_menu_set[15][7],               //rinse id, settings value
drnk_genral_set[150],
other_than_instant[4][21][16],      //machine type, drink id, settings
drk_sett[21][7][29],            //drink id,channel,channel settings like delay
drk_main_sett[21][14],          // drink id,settings
scondary_outlet_wtr_set[21][3][3];      //drink id,hot water/cold water, settings

unsigned char
milk_canister,sugar_canister,
val_store_array[20],
step_array[7],
channel[7],
liquid_choco_ch,
payment_mode,discount,currency,
//min_op_temp,temperature,hysteresis,stnd_by_temp,
//es_min_op_temp,es_temperature,es_hysteresis,es_stnd_by_temp,es_blr_prdc_rprssr,
use_beeper,allow_stop,use_multicup,intrpt_multicup,conti_fan_on,scnd_prdct_cycl,
bill_validator,coin_exchanger,cooler,drip_tray_prsnt,can_sens,init_rins,
drnk_ch_hw_cw[21],
process_step[21][5][5];

unsigned long int
ssid_value;
bool
dot_flag,
step_flag;

#endif /* UART_HEADER_FILE_ANDRD_VARIABLES_H_ */
