/*
 * DATA_ARRAY.h
 *
 *  Created on: 26-Dec-2022
 *      Author: afila
 */

#ifndef UART_HEADER_FILE_DATA_ARRAY_H_
#define UART_HEADER_FILE_DATA_ARRAY_H_

char *data[]=
{
     "ACK",             //0
     "1.1|1.0|1.0",     //1
     "MACHINE READY",                       //2
     "PLEASE PLACE CONTAINER AND CONFIRM RINSING",                  //3
     "START",                               //4
     "DRINK COMPLETED",    //5
     "DONE",            //6
     "COMPLETED",       //7
     "START",           //8
     "1",               //9
     "0",               //10
     "ALL DONE",        //11
     "2",               //12
     "3",               //13
     "ERROR",           //14
     "POPUP",           //15
     "READY",           //16
};


#endif /* UART_HEADER_FILE_DATA_ARRAY_H_ */
