/*
 * ANDROID_RECEIVE_PROCESS.c
 *
 *  Created on: 26-Dec-2022
 *      Author: afila
 */

#include "ANDROID_UART.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "stdlib.h"
#include "string.h"

const char* check_string_fun(const char *X, const char *Y);
int compare(const char *X, const char *Y);
void receive_data_process_fun();
bool isIntegerInRange(unsigned char *str, int min, int max);
int containsDot(const char dot_array[], int size);

const char* check_string_fun(const char *X, const char *Y)
{
    while (*X != '#')
    {
        if ((*X == *Y) && compare(X, Y))
        return X;
        X++;
    }
    return NULL;
}

int compare(const char *X, const char *Y)
{
    while (*X && *Y)
    {
        if (*X != *Y)
        return 0;
        X++;
        Y++;
    }
    return (*Y == '\0');
}

bool isIntegerInRange(unsigned char *str, int min, int max)
{
    int length = strlen(str);

    // Check for an empty string or a string too long to be a valid integer
    if ((length == 0) OR (length > number_len(max)))
        return false;

    for (int i = 0; i < length; i++) {
        if ((str[i] < '0') OR (str[i] > '9')) {
            // Character is not a digit
            return false;
        }
    }

    int value = atoi(str);  // Convert the string to an integer

    return ((value >= min) AND (value <= max));
}

void receive_data_process_fun()
{
    unsigned char back_up_arr[20],re_init_id_or_okey=0;
    char *data,*backup_buff;
    memset(back_up_arr,0,sizeof(back_up_arr));
    drink_id1=0;
    if(process_data_rcvd_success_flag)
    {
        switch(app_id)
        {
            case MACHINE_INFO:

                switch(fun_id)
                {
                    case HANDSHAKE:
                        data = check_string_fun(process_data_buf,"HANDSHAKE");
                        if(*data=='H')
                        {
                            data_ack_flag=SET;
                            handshake_rcv_flag=SET;
                            version_send_flag=SET;
                        }
                        break;

                    case VERSION_DETAILS:
                        data = check_string_fun(process_data_buf,"ACK");
                        if(*data=='A')
                        {
                            resend_cnt=0;
                            resend_flag=CLEAR_1;
                        }
                        break;

                    case MACHINE_TYPE:
                        machine=atoi(&process_data_buf[0]);
                        cooler_en=atoi(&process_data_buf[2]);
                        if((machine>=1)AND(machine<=4))
                        {
                            data_ack_flag=SET;
                            instant_machine_flag=(machine==1)?espresso_machine_flag=SET,0:((machine==2)?freshbrew_machine_flag=SET,0:((machine==3)?beanbrew_machine_flag=SET,0:SET));
                        }
                        break;

                    case ENTER_MAINTANENCE_SCREEN:
                        data = check_string_fun(process_data_buf,"ENTER");
                        if(*data=='E')
                        {
                            data_ack_flag=SET;
                            entered_maintenance_screen=SET;
                        }
                        break;
                    case EXIT_MAINTANENCE_SCREEN:
                        data = check_string_fun(process_data_buf,"EXIT");
                        if(*data=='E')
                        {
                            data_ack_flag=SET;
                            entered_maintenance_screen=block_esprs_prdct_flg=CLEAR_1;
                            ms_init_start_snd_flg=SET;
                            block_maintain_scrn_snd_flg=SET;
                            init_flag=SET;
                            ready_flag=CLEAR_1;
                            clear_init_things();
                        }
                        break;
                    case DOOR_OPENED:
                        data = check_string_fun(process_data_buf,"OPEN");
                        if(*data=='O')
                        {
                            data_ack_flag=SET;
                            door_opened_flg=SET;
                        }
                        break;
                    case DOOR_CLOSED:
                        data = check_string_fun(process_data_buf,"CLOSED");
                        if(*data=='C')
                        {
                            data_ack_flag=SET;
                            door_opened_flg=CLEAR_1;
                            if(one_time_brwr_abrt_snd_flg)
                                brwr_stpd_flg=one_time_brwr_abrt_snd_flg=CLEAR_1;
                        }
                        break;
                    case MS_INIT_START:
                        data = check_string_fun(process_data_buf,"ACK");
                        if(*data=='A')
                        {
                            resend_cnt=0;
                            resend_flag=CLEAR_1;
                        }
                        break;
                    case ALLOW_OR_DONT_ALLOW:
                        data = check_string_fun(process_data_buf,"ACK");
                        if(*data=='A')
                        {
                            resend_cnt=0;
                            resend_flag=CLEAR_1;
                        }
                        break;
                    case MACHINE_READY:
                        data = check_string_fun(process_data_buf,"ACK");
                        if(*data=='A')
                        {
                            resend_cnt=0;
                            resend_flag=CLEAR_1;
                        }
                        break;

                }
                break;

                case SETTINGS_DATA:
                    if((fun_id>=0X01)AND(fun_id<=0X18))
                    {
                        data_ack_flag=SET;
                        setng_rcved_flg=SET;
                    }
                    break;
                case BLOCKING_ERR:
                    switch(fun_id)
                    {
                        case BLCKING_ERR_SEND:
                        case BLCKING_ERR_CLEARED:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                            break;
                    }
                    break;
                case RINSE_MENU:
                    switch(fun_id)
                    {
                        case INITIATE_CH_RINSE:

                            if(isIntegerInRange(process_data_buf,1,10))
                            {
                                rinse_id=atoi(process_data_buf);
                                if((rinse_id>=1)AND(rinse_id<=10))
                                {
                                    data_ack_flag=SET;
                                    individual_rinse_start_flag=SET;
                                }
                            }
                            break;
                        case CH_RINSE_DONE:
                        case ALL_MIXER_DONE:
                        case RINSE_ALL_DONE:
                        case ESPRS_CLNG_STEP_DONE:
                        case BRWR_POS_SEND:
                        case RINSE_MIXER_ID:
                        case FB_MVNG_DONE:
                        case ES_DRNK_STRT:
                        case ES_DRNK_DONE:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                            break;
                        case RINSE_ALL_MIXER:
                            data = check_string_fun(process_data_buf,"ALL MIXERS");
                            if(*data=='A')
                            {
                                data_ack_flag=SET;
                                all_mixer_rinse_start_flag=SET;
                            }
                            break;
                        case RINSE_ALL:
                            data = check_string_fun(process_data_buf,"RINSE ALL");
                            if(*data=='R')
                            {
                                data_ack_flag=SET;
                                rinse_all_start_flag=SET;
                                rinse_all_seq=espresso_machine_flag?1:(instant_machine_flag?3:2);
                            }
                            break;
                        case INITIATE_ESPRS_CLNG:

                            if(isIntegerInRange(&process_data_buf[6],1,2))
                            {
                                es_clean_stp_id=atoi(&process_data_buf[6]);
                                if((es_clean_stp_id==1)OR(es_clean_stp_id==2))
                                {
                                    data_ack_flag=SET;
                                    if(es_clean_stp_id==2)//OR(es_clean_stp_id==3))
                                    {
                                        es_clean_stp_id++;
//                                        if(es_clean_stp_id==3)
                                            cln_pill_rnse_stp=1;
                                    }
                                    block_esprs_prdct_till_cln_brwr_flg=CLEAR_1;
                                    es_cln_strt_flg=SET;
                                }
                            }
                            break;
                        case FRESH_BRWR_MOVING:
                            if(isIntegerInRange(process_data_buf,1,2))
                            {
                                fb_move_id=atoi(process_data_buf);
                                if((fb_move_id==1)OR(fb_move_id==2))
                                {
                                    data_ack_flag=SET;
                                    move_fb_flg=SET;
                                }
                            }
                            break;
                        case CANCEL_RINSE:
                            data = check_string_fun(process_data_buf,"CANCEL");
                            if(*data=='C')
                            {
                                data_ack_flag=SET;
                                if(individual_rinse_start_flag)
                                {
                                    if((rinse_id>=6)AND(rinse_id<=8))
                                        cancel_initiate_flg=SET;
                                }
                                else if(all_mixer_rinse_start_flag)
                                    cancel_all_mixer_rins_flg=SET;
                            }
                            break;
                    }
                    break;
                case DRINK_PROCESS:
                case DEMO_DRINK_PROCESS:
                    switch(fun_id)
                    {
                        case DIRECT_START_INITIATE:
                            if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                            {
                                back_up_arr[0]=process_data_buf[0];
                                back_up_arr[1]=(process_data_buf[1]!='|')?process_data_buf[1]:0;
                                drink_id1=atoi(back_up_arr);
                                if((drink_id1>0)AND(drink_id1<=20))
                                {
                                    demo_drink_flg=(app_id==DEMO_DRINK_PROCESS)?SET:CLEAR_1;
                                    double_cup_flag=drk_main_sett[drink_id1][double_cup];
                                    mug_flag=drk_main_sett[drink_id1][mug_en];
                                    multicup_flag=drk_main_sett[drink_id1][multicup];

                                    if((multicup_flag)AND(!double_cup_flag)AND(!mug_flag))
                                    {
                                        multicup_start_flag=SET;
                                        if(drnk_genral_set[set_cup_at_dr_strt])
                                        {
                                            remove_ssid_value((drink_id1>9)?3:2,312,process_data_buf);
                                            if(drnk_ch_hw_cw[drink_id1]==1)
                                                no_of_multicup=val_store_array[0];
                                            else
                                                scndary_no_of_multicup=val_store_array[0];
                                        }
                                        else
                                        {
                                            if(drnk_ch_hw_cw[drink_id1]==1)
                                                no_of_multicup=(unsigned char)drk_main_sett[drink_id1][default_number];
                                            else
                                                scndary_no_of_multicup=(unsigned char)drk_main_sett[drink_id1][default_number];
                                        }
                                    }
                                    if(drnk_ch_hw_cw[drink_id1]==1)
                                    {
                                        drink_id=drink_id1;
                                        drnk_steps=stages=1;
                                        process_initiated_flag=SET;
                                        drink_start_send_flag=SET;
                                        data_ack_flag=SET;
                                    }
                                    else
                                    {
                                        scnd_drink_id=drink_id1;
                                        scnd_outlet_stages=1;
                                        secondary_outlet_process_init_flag=SET;
                                        secondary_drnk_start_flag=SET;
                                        data_ack_flag=SET;
                                    }
                                    drink_id1=0;
                                }
                            }
                            break;
                        case DISPENSE_AFTR_ADJUST:
                            if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                            {
                                demo_drink_flg=(app_id==DEMO_DRINK_PROCESS)?SET:CLEAR_1;
                                by_prodcut_no=0;
                                memset(strength,0,sizeof(strength));
                                memset(by_product_selected,0,sizeof(by_product_selected));
                                back_up_arr[0]=process_data_buf[0];
                                back_up_arr[1]=(process_data_buf[1]!='|')?process_data_buf[1]:0;
                                drink_id1=atoi(back_up_arr);
                                if((drink_id1>0)AND(drink_id1<=20))
                                {
                                    remove_ssid_value((drink_id1>9)?3:2,310,process_data_buf);
                                    if(val_store_array[1]>0)        // single/double/mug
                                        double_cup_flag=(val_store_array[1]==2)?SET:((val_store_array[1]==3)?mug_flag=SET,0:0);

                                    else if(val_store_array[2]>0)   //multicup
                                    {
                                        multicup_start_flag=SET;
                                        if(drnk_ch_hw_cw[drink_id1]==1)
                                            no_of_multicup=val_store_array[2];
                                        else
                                            scndary_no_of_multicup=val_store_array[2];
                                    }
                                    if(drk_main_sett[drink_id1][main_prdt_ch])       //check that drink, which is have main prdt or not
                                    {
                                        strength[drk_main_sett[drink_id1][main_prdt_ch]]=val_store_array[3];
                                        strength[drk_main_sett[drink_id1][main_prdt_ch]]/=100;
                                    }
                                    by_product_selected[milk_canister]=drk_main_sett[drink_id1][milk_en_dis]?val_store_array[4]:0;      //by product is enabled for drink, means they can run based on user input
                                    if(by_product_selected[milk_canister])
                                    {
                                        strength[milk_canister]=val_store_array[5];
                                        strength[milk_canister]/=100;
                                    }
                                    by_product_selected[sugar_canister]=drk_main_sett[drink_id1][sugar_en_dis]?val_store_array[6]:0;
                                    if(by_product_selected[sugar_canister])
                                    {
                                        strength[sugar_canister]=val_store_array[7];
                                        strength[sugar_canister]/=100;
                                    }
                                    if((by_product_selected[milk_canister])AND(by_product_selected[sugar_canister]))
                                        by_prodcut_no=1;
                                    else if(by_product_selected[sugar_canister])
                                        by_prodcut_no=2;
                                    else if(by_product_selected[milk_canister])
                                        by_prodcut_no=3;
                                    need_to_minus_wtr_vl_frm_byprdct_flg=(by_prodcut_no>0)?SET:CLEAR_1;
                                 //When this flag set, we need to do(main product water time-byproduct water time) and block main product powder motor is stop. we need to stop the water motor.
                                    data_ack_flag=SET;
                                    if(drnk_ch_hw_cw[drink_id1]==1)
                                    {
                                        drink_id=drink_id1;
                                        drnk_steps=stages=1;
                                        process_initiated_flag=SET;
                                        drink_start_send_flag=SET;
                                        data_ack_flag=SET;
                                    }
                                    else
                                    {
                                        scnd_drink_id=drink_id1;
                                        scnd_outlet_stages=1;
                                        secondary_outlet_process_init_flag=SET;
                                        secondary_drnk_start_flag=SET;
                                        data_ack_flag=SET;
                                    }
                                    drink_id1=0;
                                }
                            }
                            break;
                        case SECONDARY_DRINK_INITIATE:
                            if((process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                            {
                                back_up_arr[0]=process_data_buf[0];
                                back_up_arr[1]=process_data_buf[1];
                                drink_id1=atoi(back_up_arr);
                                if(drnk_ch_hw_cw[drink_id1]!=1)
                                {
                                    scnd_drink_id=drink_id1;
                                    scnd_outlet_stages=1;
                                    from_secondary_drink=SET;
                                    secondary_outlet_process_init_flag=SET;
                                    secondary_drnk_start_flag=SET;
                                    data_ack_flag=SET;
                                }
                                drink_id1=0;
                            }
                            break;
                        case DRINK_START:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
//                                if(drnk_ch_hw_cw[drink_id1]==1)
//                                    process_initiated_flag=SET;
//                                else
//                                    secondary_outlet_process_init_flag=SET;
//                                drink_id1=0;
                            }
                            break;
                        case DRINK_COMPLETED:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                snd_err_aftr_dispns_opn_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                            break;
                        case DRINK_STOP:
                            str_cmp_rtn = strncmp(process_data_buf,"STOP",4);
                            if(str_cmp_rtn==0)
                            {
                                back_up_arr[0]=process_data_buf[5];
                                back_up_arr[1]=process_data_buf[6];
                                drink_id1=atoi(back_up_arr);
//                                remove_ssid_value(5,0,process_data_buf);        //need drink id, no ssid, process array
//                                drink_id1=atoi(val_store_array);
                                if((drink_id==drink_id1)OR(scnd_drink_id==drink_id1))       //CHECK THE DRINK IS CURRENTLY RUN OR NOT
                                {
                                    if(drnk_ch_hw_cw[drink_id1]!=1)     // that drink must be hot water or cold water or jug dispense
                                    {
                                        stop_scndry_prdct_prcess=SET;
                                        data_ack_flag=SET;
                                    }
                                    else if((no_of_multicup>0)OR(scndary_no_of_multicup>0))
                                    {
                                        stop_prmry_prdct_prcess=SET;
                                        data_ack_flag=SET;
                                    }

                                }
                            }
                            break;
                        case STOP_DONE:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                snd_err_aftr_dispns_opn_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                            break;
                        case MULTICUP_COMPLETED:
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                            break;
                    }
                        break;
                    case SENSOR_STATUS:
                        switch(fun_id)
                        {
                            case SENSOR_STATUS_REQ:
                                data = check_string_fun(process_data_buf,"REQ");
                                if(*data=='R')
                                {
                                    data_ack_flag=SET;
                                    send_sensor_status_flag=SET;
                                    sensr_sts_req_flg=SET;
                                    first_time_sensor_read_flg=SET;
                                }
                                break;

                            case SENSOR_STATUS_SEND:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case EXIT_MONITOR_SENSOR:
                                data = check_string_fun(process_data_buf,"EXIT");
                                if(*data=='E')
                                {
                                    data_ack_flag=SET;
                                    sensr_sts_req_flg=CLEAR_1;
                                }
                                break;
                        }
                        break;
                    case RTC_APP_ID:
                        switch(fun_id)
                        {
                            case RTC_SEND:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case CHANGE_RTC:
                                data_ack_flag=SET;
                                date_time_changed_flag=SET;
                                break;
                        }
                        break;
                    case CRITICAL_ER:
                        switch(fun_id)
                        {
                            case CRTCL_ER_SEND:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                        }
                        break;
                    case ON_OFF_OUTPUTS:
                        switch(fun_id)
                        {
                            case NORMAL_OUTPUT_ON:
                                output_id=atoi(process_data_buf);
                                output_id-=400;
                                if(((output_id>=1)AND(output_id<=25))OR(output_id==27)OR(output_id==28))
                                {
                                    backup_output_id=output_id;
                                    data_ack_flag=SET;
                                    output_on_flag=SET;
                                }
                                break;
                            case NORMAL_OUTPUT_OFF:
                                output_id=atoi(process_data_buf);
                                output_id-=400;
                                if(backup_output_id==output_id)
                                {
                                    if(((output_id>=1)AND(output_id<=25))OR(output_id==27)OR(output_id==28))
                                    {
                                        backup_output_id=0;
                                        data_ack_flag=SET;
                                        output_off_flag=SET;
                                    }
                                }
                                break;
                            case BREWER_OUTPUT_ON:
                                output_id=atoi(process_data_buf);
                                output_id-=400;
                                if((output_id==26)OR(output_id==29))
                                {
                                    data_ack_flag=SET;
                                    output_on_flag=SET;
                                }
                                break;
                            case BREWER_OUTPUT_OFF:
                            case CANISTER_CAL_OFF:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case CANISTER_CAL_ON:
                                back_up_arr[0]=process_data_buf[0];
                                canister_id=atoi(back_up_arr);
                                if((canister_id>=1)AND(canister_id<8))
                                {
                                    can_run_sec=atoi(&process_data_buf[2]);
                                    can_run_sec*=100;
                                    data_ack_flag=SET;
                                    calibrate_start_flg=SET;
                                }
                                break;
                            case BUZZER_ON:
                                data = check_string_fun(process_data_buf,"1");
                                if(*data=='1')
                                {
                                    data_ack_flag=SET;
                                    beep_sound_flg=SET;
                                }
                                break;
                        }
                        break;
                    case ESPRESSO_BLR_EMP_SEQ:
                        switch(fun_id)
                        {
                            case START_EMPTY_SEQ:
                                data = check_string_fun(process_data_buf,"START");
                                if(*data=='S')
                                {
                                    emp_blr_seq=1;
                                    data_ack_flag=SET;
                                    emt_blr_seq_strt_flg=SET;
                                }
                                break;
                            case STOP_DONE_SEQ:
                            case SEND_TMP:
                            case COMPLETED_EMPTY_SEQ:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case STOP_EMPTY_SEQ:
                                data = check_string_fun(process_data_buf,"STOP");
                                if(*data=='S')
                                {
                                    data_ack_flag=SET;
                                    stop_empt_blr_seq_flg=SET;
                                }
                                break;
                        }
                        break;
                    case WARNING:
                        if((fun_id==0X01)OR(fun_id==0X02))
                        {
                            data = check_string_fun(process_data_buf,"ACK");
                            if(*data=='A')
                            {
                                resend_cnt=0;
                                resend_flag=CLEAR_1;
                            }
                        }
                        break;
                    case REINIT_POPUP:
                        switch(fun_id)
                        {
                            case INITIATE_THE_REINIT_POPUP:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case CONTINUE:
                                re_init_id_or_okey=atoi(process_data_buf);
                                if((re_init_id_or_okey>=1)AND(re_init_id_or_okey<=5))
                                {
                                    data_ack_flag=SET;
                                    if((re_init_id_or_okey==2)OR(re_init_id_or_okey==3))
                                    {
                                        if(re_init_id_or_okey==3)
                                        {
                                            if(init_flag)
                                            {
                                                need_to_get_reinit_cnfrm_flg=CLEAR_1;
                                                initial_delay_time=1000;
                                            }
                                            drip_tray_placed_flg=SET;
                                        }
                                        else if(re_init_id_or_okey==2)
                                        {
                                            need_to_get_reinit_cnfrm_flg=CLEAR_1;
                                            initial_delay_time=1000;
                                        }
//                                        if((init_flag)OR(run_time_init_flg))
//                                            re_init_flg=SET;                //when this flag set need to clear the initalization flag and stop and again start from first
                                    }
                                    else if(re_init_id_or_okey==4)
                                    {
                                        if(one_time_brwr_abrt_snd_flg)
                                        brwr_stpd_flg=CLEAR_1;
                                    }
                                    else if(re_init_id_or_okey==1)
                                        container_plcd_flg=SET;
                                    else if(re_init_id_or_okey==5)
                                        waste_bin_placed_flg=SET;
                                }
                                break;
                        }
                        break;
                    case FACTORY_TEST:
                        switch(fun_id)
                        {
                            case FACTORY_TEST_DONE:
                                data = check_string_fun(process_data_buf,"DONE");
                                if(*data=='D')
                                {
                                    entered_fctry_tst_flg=CLEAR_1;
                                    data_ack_flag=SET;
                                    init_flag=SET;
                                    block_maintain_scrn_snd_flg=SET;    //WHEN THIS SET, THAT CASE WE DON'T ALLOW TO MAINTENANCE SCREEN
                                    factory_test_done_flag=SET;
                                    initial_delay_flg=SET,one_sec_timer=0;      //after factory test done we need some delay, then only initial data display on initilization screen
                                }
                                break;

                            case FACTORY_TST_ENTR:
                                data = check_string_fun(process_data_buf,"ENTER");
                                if(*data=='E')
                                {
                                    clear_init_things();
                                    data_ack_flag=SET;
                                    entered_fctry_tst_flg=SET;
                                }
                                break;
                            case FACTORY_TST_EXIT:
                                data = check_string_fun(process_data_buf,"EXIT");
                                if(*data=='E')
                                {
                                    data_ack_flag=SET;
                                    entered_fctry_tst_flg=CLEAR_1;
                                    ft_from_set_flg=SET;
                                }
                                break;
                            case BEEPER_INIATE:
                                if((process_data_buf[0]=='1')OR(process_data_buf[0]=='0'))
                                {
                                    data_ack_flag=SET;
                                    beeper_ft_on_flg=atoi(process_data_buf);
                                }
                                break;
                            case CANISTER_MTR_INITIATE:
                                if(!canister_initated_flg)
                                {
                                    canister_test_id=atoi(process_data_buf);
                                    if((canister_test_id>=1)AND(canister_test_id<=8))
                                    {
                                        data_ack_flag=SET;
                                        canister_initated_flg=SET;
                                    }
                                    else
                                        canister_test_id=0;
                                }
                                break;
                            case CANISTER_MTR_DONE:
                            case WTR_MXR_DONE:
                            case ESP_BRWR_FAIL:
                            case ESP_BRWR_DONE:
                            case AR_BRK_POPUP:
                            case AIR_BRK_INITIATE:
                            case AR_BRK_TEST_ID:
                            case ES_BLR_FILL_INITATE:
                            case ES_LVL_STS_DONE:
                            case ES_BLR_HEAT_INITIATE:
                            case ES_BLR_CRNT_TEMP:
                            case ES_BLR_HEAT_TST_ID:
                            case OPN_BLR_LVL_STS_DONE:
                            case OPN_BLR_HEAT_INITIATE:
                            case OPN_BLR_CRNT_TEMP:
                            case OPN_BLR_HEAT_TST_ID:
                            case SNSR_SW_POPUP:
                            case SNSR_SW_READY_FOR_TEST:
                            case SNSR_SW_TEST_ID:
                            case SNSR_SW_TEST_COMP:
                            case FB_TMR_RESET:
                                data = check_string_fun(process_data_buf,"ACK");
                                if(*data=='A')
                                {
                                    resend_cnt=0;
                                    resend_flag=CLEAR_1;
                                }
                                break;
                            case WTR_MXR_INITIATE:
                                if(!wtr_op_initated_flg)
                                {
                                    wtr_op_test_id=atoi(process_data_buf);
                                    if(wtr_op_test_id==1)
                                        fb_ft_test_id=1;
                                    if((wtr_op_test_id>=1)OR(wtr_op_test_id<=10))
                                    {
                                        data_ack_flag=SET;
                                        wtr_op_initated_flg=SET;
                                    }
                                    else
                                        wtr_op_test_id=0;
                                }
                                break;
                            case ESP_BRWR_INITIATE:
                                espso_sys_test_initated_flg=atoi(process_data_buf);
                                if(espso_sys_test_initated_flg)
                                {
                                    data_ack_flag=SET;
                                    es_sys_test_id=es_brwr_tst_stp=1;
                                }
                                break;
                            case AR_BRK_TEST_EXIT:
                                exit_ar_brk_tst_flg=(process_data_buf[0]=='0')?SET:CLEAR_1;
                                if((espso_sys_test_initated_flg)AND(exit_ar_brk_tst_flg))
                                    data_ack_flag=SET;
                                else
                                    exit_ar_brk_tst_flg=CLEAR_1;
                                break;
                            case OPN_BLR_FILL_INITIATE:
                                opn_blr_sys_test_initated_flg=atoi(process_data_buf);
                                if(opn_blr_sys_test_initated_flg)
                                {
                                    data_ack_flag=SET;
                                    opn_blr_sys_test_id=1;
                                }
                                break;
                            case SNSR_SW_TEST_INITIATE:
                                sensr_sw_ft_id=atoi(process_data_buf);
                                if((sensr_sw_ft_id>=1)AND(sensr_sw_ft_id<=4))
                                {
                                    data_ack_flag=SET;
                                    snsr_sw_ft_initiate_flg=SET;
                                    snsr_sw_id=(sensr_sw_ft_id==1)?1:(sensr_sw_ft_id==2)?4:(sensr_sw_ft_id==3)?7:10;
                                    sensr_sw_ft_case_id=1;
                                }
                                break;
                            case SNSR_SW_TEST_EXIT:
                                exit_snsr_sw_tst_flg=(process_data_buf[0]=='0')?SET:CLEAR_1;
                                if((snsr_sw_ft_initiate_flg)AND(exit_snsr_sw_tst_flg))
                                    data_ack_flag=SET;
                                else
                                    exit_snsr_sw_tst_flg=CLEAR_1;
                                break;
                        }
                        break;
                        case WATER_RUN_TIME_TEST:
                            switch(fun_id)
                            {
                                case WTR_RUN_START:
                                    back_up_arr[0]=process_data_buf[0];
                                    back_up_arr[1]=(process_data_buf[1]!='|')?process_data_buf[1]:0;

                                    water_ch_id=atoi(back_up_arr);
                                    if((water_ch_id>=1)AND(water_ch_id<=11))
                                    {
                                        data_ack_flag=SET;
                                        wtr_run_time_initiate_flg=SET;
                                        demo_wtr_run_time=containsDot((water_ch_id<10?(&process_data_buf[2]):(&process_data_buf[3])),(water_ch_id<10?(strlen(&process_data_buf[2])):(strlen(&process_data_buf[3]))));
                                        demo_wtr_run_time=wtr_run_time?(atof((water_ch_id<10?(&process_data_buf[2]):(&process_data_buf[3])))*100):(atoi((water_ch_id<10?(&process_data_buf[2]):(&process_data_buf[3])))*((water_ch_id==7)?1:100));
                                        if(water_ch_id<7)
                                            water_ch_id=channel[water_ch_id];
                                        else if(water_ch_id==7)
                                            demo_wtr_brwr_pos=1;
                                        else if((water_ch_id==8)OR(water_ch_id==9))
                                            wtr_op_test_id=1,fb_ft_test_id=1;

                                    }
                                    break;
                                case WTR_RUN_COMPLETE:
                                    data = check_string_fun(process_data_buf,"ACK");
                                    if(*data=='A')
                                    {
                                        resend_cnt=0;
                                        resend_flag=CLEAR_1;
                                    }
                                    break;
                            }
                            break;
        }
        process_data_rcvd_success_flag=CLEAR_1;
    }
}
int containsDot(const char dot_array[], int size)
{
    for (int i = 0; i < size; i++) {
        if (dot_array[i] == '.') {
            return 1; // Return 1 if '.' is found
        }
    }
    return 0; // Return 0 if '.' is not found
}
