/*
 * ANDROID_UART_SEND.c
 *
 *  Created on: 26-Dec-2022
 *      Author: afila
 */

#include "ANDROID_UART.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../UART_HEADER_FILE/DATA_ARRAY.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

unsigned char check_sum_fun(unsigned char );
int add_stuff_bytes(unsigned char );
void data_appid_funid_get_fun();
void gui_msg_send_fun();
void date_time_fun(unsigned char,bool );
unsigned char hex_to_dec_converter(unsigned char );


unsigned char check_sum_fun(unsigned char tx_byte)
{
    unsigned char i,k,temp_check_sum_val;
    for(k=0,i=2,temp_check_sum_val=0;i<tx_byte;k++)
    {
        temp_check_sum_val =(char)(temp_check_sum_val + (k XOR gui_tx_buff[i++]));
    }
    temp_check_sum_val=(char)(temp_check_sum_val+gui_tx_buff[1]);
    temp_check_sum_val=(char)~temp_check_sum_val;
    return temp_check_sum_val;
}
int add_stuff_bytes(unsigned char len)
{
    unsigned char byte,i,stuff_byte;

    for(byte=1,i=1,stuff_byte=0;byte<(len+stuff_byte);i++,byte++)
    {
        if((temp_send_buf[i]==0X1C)OR(temp_send_buf[i]==0X2A)OR(temp_send_buf[i]==0X23))
        {
            gui_tx_buff[byte++]=STUFF_BYTE;
            gui_tx_buff[byte]=~temp_send_buf[i];
            stuff_byte++;
        }
        else
        gui_tx_buff[byte]=temp_send_buf[i];
    }
    return byte;
}

void gui_msg_send_fun()
{
    unsigned char int_to_string_buf[20],i=0,backup_temp_buff[10];
    unsigned char last_buff=0,send_chech_sum=0,string_buff=0;
    memset(int_to_string_buf,0,sizeof(int_to_string_buf));
    memset(backup_temp_buff,0,sizeof(backup_temp_buff));
    if(!gui_send_flg)
    data_appid_funid_get_fun();

    if(((gui_send_flg)OR(resend_flag))AND(trasmit_dly<=0))
    {
        if((!resend_flag) OR (data_ack_flag))
        {
            gui_send_flg=CLEAR_1;
            if((resend_no_flg) OR (data_ack_flag))
            {
                if(resend_flag)
                {
                    memcpy(tx_backup_store_buff,tx_backup_buff,sizeof(tx_backup_buff));
                    backup_tx_store_bytes = backup_tx_bytes;
                    resend_backup_flag = SET;
                }
                resend_no_flg=CLEAR_1;
                data_ack_flag = CLEAR_1;
            }
            else
            resend_flag=SET;

            string_buff=0;
            tx_buff=0;

            memset(gui_tx_buff,0,sizeof(gui_tx_buff));

            gui_tx_buff[tx_buff++]=START_BYTE;
            gui_tx_buff[tx_buff++]=header_val;;
            gui_tx_buff[tx_buff++]=0;
            gui_tx_buff[tx_buff++]=strlen(data[a_val]);
            gui_tx_buff[tx_buff++]=array.app;
            gui_tx_buff[tx_buff++]=array.fun;

            if(block_id==STR_COMMMON)
                strcpy(&gui_tx_buff[tx_buff],data[a_val]);
            else if((block_id==STR_ADD_DRINK_ID)OR(block_id==ADD_DRINK_CUP_AND_ID))
            {
                strcpy(&gui_tx_buff[tx_buff],data[a_val]);
                string_buff=(char)strlen(data[a_val]);
                tx_buff=string_buff+tx_buff;
                gui_tx_buff[tx_buff++]='|';
                if(block_id==STR_ADD_DRINK_ID)
                sprintf(int_to_string_buf,"%hu",(drnk_prmry?drink_id:scnd_drink_id)),drnk_prmry=CLEAR_1;
                else if(block_id==ADD_DRINK_CUP_AND_ID)
                {
                    sprintf(int_to_string_buf,"%hu",(drnk_prmry?drink_id:scnd_drink_id));
                    int_to_string_buf[strlen(int_to_string_buf)]='|';
                    sprintf(&int_to_string_buf[strlen(int_to_string_buf)],"%hu",(drnk_prmry?send_cup:scndry_send_cup));
                    drnk_prmry=CLEAR_1;
                }

                for(i=0;i<strlen(int_to_string_buf);i++)
                gui_tx_buff[tx_buff++]=int_to_string_buf[i];
            }

            else if((block_id==STRNG_OPEN_BLR_TEMP)OR(block_id==STRNG_ES_BLR_TEMP)OR(block_id==STR_ERR_RMV)OR(block_id==STR_ERR_SEND)OR(block_id==STRNG_ES_BLR_TEMP_CLR)OR(block_id==STRNG_OPEN_BLR_TEMP_CLR)OR(block_id==STR_TST_OP_ID)OR(block_id==STR_MXR_ID_SND)OR(block_id==STR_BRWR_POS_SEND))
            {
                for(i=0;i<strlen(error_id);i++)
                gui_tx_buff[tx_buff++]=error_id[i];
                if((block_id==STRNG_OPEN_BLR_TEMP)OR(block_id==STRNG_ES_BLR_TEMP))
                {
                    if(block_id==STRNG_OPEN_BLR_TEMP)
                        sprintf(backup_temp_buff,"%hu",ar_ctemp);
                    else if(block_id==STRNG_ES_BLR_TEMP)
                        sprintf(backup_temp_buff,"%hu",es_ctemp);
                    gui_tx_buff[tx_buff++]='|';
                    for(i=0;i<strlen(backup_temp_buff);i++)
                        gui_tx_buff[tx_buff++]=backup_temp_buff[i];
                }
            }
            else if((block_id==SEND_TMP_FOR_EMPT_BLR)OR(block_id==SEND_TMP_FOR_FT_ES_BLR)OR(block_id==SEND_TMP_FOR_FT_OPN_BLR))
            {
                if(block_id==SEND_TMP_FOR_FT_OPN_BLR)
                    sprintf(backup_temp_buff,"%hu",ar_ctemp);
                else
                    sprintf(backup_temp_buff,"%hu",es_ctemp);
                for(i=0;i<strlen(backup_temp_buff);i++)
                    gui_tx_buff[tx_buff++]=backup_temp_buff[i];
            }
            else if(block_id==STR_SENSOR_STATUS)
            {
                //open air boiler temperature and heater status
                strcpy(&gui_tx_buff[tx_buff],"331");
                tx_buff+=3;
                gui_tx_buff[tx_buff++]=':';
                sprintf(backup_temp_buff,"%hu",ar_ctemp);
                strcpy(&gui_tx_buff[tx_buff],backup_temp_buff);
                tx_buff+=(strlen(backup_temp_buff));
                memset(backup_temp_buff,0,sizeof(backup_temp_buff));

                gui_tx_buff[tx_buff++]='|';
                gui_tx_buff[tx_buff++]=air_boiler_heater_on_flg?'1':'0';
                gui_tx_buff[tx_buff++]='$';

                //open air boiler min level
                strcpy(&gui_tx_buff[tx_buff],"332");
                tx_buff+=3;
                gui_tx_buff[tx_buff++]=':';
                gui_tx_buff[tx_buff++]=blr_lvl1_wtr_flg?'0':'1';
                gui_tx_buff[tx_buff++]='$';

                //open air boiler max level
                strcpy(&gui_tx_buff[tx_buff],"333");
                tx_buff+=3;
                gui_tx_buff[tx_buff++]=':';
                gui_tx_buff[tx_buff++]=blr_lvl2_wtr_flg?'0':'1';
                gui_tx_buff[tx_buff++]='$';

                if(espresso_machine_flag)
                {
                    //espresso boiler temperature and heater status
                    strcpy(&gui_tx_buff[tx_buff],"334");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    sprintf(backup_temp_buff,"%hu",es_ctemp);
                    strcpy(&gui_tx_buff[tx_buff],backup_temp_buff);
                    tx_buff+=(strlen(backup_temp_buff));
                    gui_tx_buff[tx_buff++]='|';
                    gui_tx_buff[tx_buff++]=espresso_heater_on_flg?'1':'0';
                    gui_tx_buff[tx_buff++]='$';


                    //air break min level
                    strcpy(&gui_tx_buff[tx_buff],"335");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=ar_brk_min_flg?'0':'1';
                    gui_tx_buff[tx_buff++]='$';

                    //air break max level
                    strcpy(&gui_tx_buff[tx_buff],"336");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=ar_brk_max_flg?'0':'1';
                    gui_tx_buff[tx_buff++]='$';


                    //espresso brewer position
                    strcpy(&gui_tx_buff[tx_buff],"337");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=block_esprs_prdct_flg?'3':(es_fill_pos_sw_flg?'1':'2');
                    gui_tx_buff[tx_buff++]='$';
                }
                else if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
                {
                    //fresh brewer position
                    strcpy(&gui_tx_buff[tx_buff],"338");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=fb_home_pos_flg?'0':'1';
                    gui_tx_buff[tx_buff++]='$';

                    //filter paper status
                    strcpy(&gui_tx_buff[tx_buff],"339");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=filter_paper_present?'0':'1';
                    gui_tx_buff[tx_buff++]='$';

                    //waste bin full status
                    strcpy(&gui_tx_buff[tx_buff],"348");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=waste_bin_full?'0':'1';
                    gui_tx_buff[tx_buff++]='$';
                }

                //Drip tray level
                strcpy(&gui_tx_buff[tx_buff],"343");
                tx_buff+=3;
                gui_tx_buff[tx_buff++]=':';
                gui_tx_buff[tx_buff++]=drip_lvl_chk_flag?'1':'0';
                gui_tx_buff[tx_buff++]='$';

                //waste bin present
                if(!instant_machine_flag)
                {
                    strcpy(&gui_tx_buff[tx_buff],"344");
                    tx_buff+=3;
                    gui_tx_buff[tx_buff++]=':';
                    gui_tx_buff[tx_buff++]=wast_bin_prsnt_sw?'0':'1';
                    gui_tx_buff[tx_buff++]='$';


                }

                //fan status
                strcpy(&gui_tx_buff[tx_buff],"347");
                tx_buff+=3;
                gui_tx_buff[tx_buff++]=':';
                gui_tx_buff[tx_buff++]=fan_mtr_flg?'1':'0';

            }
            else if(block_id==STR_RTC)
            {
                date = hex_to_dec_converter(rtc_buf[RTC_DATE]);
                month = hex_to_dec_converter(rtc_buf[RTC_MONTH]);
                year = hex_to_dec_converter(rtc_buf[RTC_YEAR]);
                hour = hex_to_dec_converter(rtc_buf[RTC_HOURS]);
                minute = hex_to_dec_converter(rtc_buf[RTC_MINUTES]);
                week = hex_to_dec_converter(rtc_buf[RTC_DAY]);

                date_time_fun(date,0);
                gui_tx_buff[tx_buff++] = '|';

                date_time_fun(month,0);
                gui_tx_buff[tx_buff++] = '|';

                gui_tx_buff[tx_buff++] = '2';
                gui_tx_buff[tx_buff++] = '0';
                date_time_fun(year,0);
                gui_tx_buff[tx_buff++] = '|';

                date_time_fun(hour,0);
                gui_tx_buff[tx_buff++] = '|';

                date_time_fun(minute,0);
                gui_tx_buff[tx_buff++] = '|';
                week=week==1?1:(week==2?2:(week==4?3:(week==8?4:(week==10?5:(week==20?6:7)))));
                date_time_fun(week,1);
            }
            else if(block_id==ESP_CLN_STEP_STR)
            {
                gui_tx_buff[tx_buff++] = 'D';
                gui_tx_buff[tx_buff++] = 'O';
                gui_tx_buff[tx_buff++] = 'N';
                gui_tx_buff[tx_buff++] = 'E';
                gui_tx_buff[tx_buff++] = '|';
                gui_tx_buff[tx_buff++] = *data[a_val];
            }
            if(block_id==STR_COMMMON)
            string_buff=(char)strlen(data[a_val]);
            else
                string_buff=0;
            last_buff=(char)(string_buff+(tx_buff));
            gui_tx_buff[3]=last_buff-6;
            send_chech_sum=(char)check_sum_fun(last_buff);
            gui_tx_buff[last_buff++]=send_chech_sum;

            memset(final_data_send_buff,0,sizeof(final_data_send_buff));
            memset(error_id,0,sizeof(error_id));

            transmit_no_of_bytes=(char)last_buff;////((gui_tx_buff[3]&0x3F)+8);
            memcpy(temp_send_buf,gui_tx_buff,sizeof(gui_tx_buff));
            transmit_no_of_bytes=(char)add_stuff_bytes(transmit_no_of_bytes);
            gui_tx_buff[transmit_no_of_bytes++]=END_BYTE;
            transmit_no_of_bytes=backup_tx_bytes=transmit_no_of_bytes;

            memcpy(final_data_send_buff,gui_tx_buff,sizeof(gui_tx_buff));
            memcpy(tx_backup_buff,final_data_send_buff,sizeof(final_data_send_buff));

            android_uart.p_api->write(android_uart.p_ctrl,final_data_send_buff,transmit_no_of_bytes);
            heart_beat_timer=0;
            block_id=0;
        }
        else
        {
            if(resend_backup_flag)
            {
                memset(tx_backup_buff,0,sizeof(tx_backup_buff));
                memcpy(tx_backup_buff,tx_backup_store_buff,sizeof(tx_backup_store_buff));
                backup_tx_bytes = backup_tx_store_bytes;
                memset(tx_backup_store_buff,0,sizeof(tx_backup_store_buff));
                backup_tx_store_bytes = 0;
                resend_backup_flag = CLEAR_1;
            }
            android_uart.p_api->write(android_uart.p_ctrl,tx_backup_buff,backup_tx_bytes);
            resend_cnt++;
            if(resend_cnt>1)
            {
                resend_cnt=0;
                resend_flag=CLEAR_1;
            }
        }
        trasmit_dly=250;
    }
}

void data_appid_funid_get_fun()
{
    if(data_ack_flag)
    {
        data_ack_flag=CLEAR_1;
        resend_no_flg=SET;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=app_id;
        array.fun=fun_id;
        a_val=0;
        block_id=STR_COMMMON;
    }
    else if(version_send_flag)
    {
        version_send_flag=CLEAR_1;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=MACHINE_INFO;
        array.fun=VERSION_DETAILS;
        a_val=1;
        block_id=STR_COMMMON;
    }
    else if((drink_start_send_flag)OR(drink_compelet_flag)OR(secondary_drnk_start_flag)OR(secondary_process_complete)OR(stop_done_snd_flg)OR(scndry_stop_done_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=demo_drink_flg?DEMO_DRINK_PROCESS:DRINK_PROCESS;
        if((drink_start_send_flag)OR(secondary_drnk_start_flag))
        {
            if(drink_start_send_flag)
                drink_start_send_flag=CLEAR_1,drnk_prmry=SET;
            else if(secondary_drnk_start_flag)
                secondary_drnk_start_flag=CLEAR_1,drnk_prmry=CLEAR_1;
            array.fun=DRINK_START;
            a_val=4;
        }
        else if((stop_done_snd_flg)OR(scndry_stop_done_snd_flg))
        {
            if(stop_done_snd_flg)
                stop_done_snd_flg=CLEAR_1,drnk_prmry=SET;
            else if(scndry_stop_done_snd_flg)
                scndry_stop_done_snd_flg=CLEAR_1,drnk_prmry=CLEAR_1;
            array.fun=STOP_DONE;
            a_val=6;
        }
        else if((drink_compelet_flag)OR(secondary_process_complete))
        {
            if(drink_compelet_flag)
                drink_compelet_flag=CLEAR_1,drnk_prmry=SET;
            else if(secondary_process_complete)
                secondary_process_complete=drnk_prmry=CLEAR_1;
            array.fun=DRINK_COMPLETED;
            a_val=5;
        }
        block_id=STR_ADD_DRINK_ID;
    }
    else if((multicup_completed_send_flag)OR(scndry_multicup_completed_send_flag))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=DRINK_PROCESS;
        if(multicup_completed_send_flag)
            multicup_completed_send_flag=CLEAR_1,drnk_prmry=SET;
        else if(scndry_multicup_completed_send_flag)
            scndry_multicup_completed_send_flag=CLEAR_1,drnk_prmry=CLEAR_1;
        array.fun=MULTICUP_COMPLETED;
        a_val=7;
        block_id=ADD_DRINK_CUP_AND_ID;
    }
    else if((drip_tray_full_snd_flg)OR(drip_tray_empty_send_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=BLOCKING_ERR;
        if(drip_tray_full_snd_flg)
        {
            drip_tray_full_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='1';
            error_id[1]='0';
            block_id=STR_ERR_SEND;
        }
        else if(drip_tray_empty_send_flg)
        {
            drip_tray_empty_send_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='1';
            error_id[1]='0';
            block_id=STR_ERR_RMV;
        }

    }
    else if((plc_es_brwr_err_snd)OR(plced_es_brwr_err_snd)OR(brwr_init_send_flg)OR(brwr_init_done_flg)OR(es_brwr_brew_pos_er_snd_flg)OR(es_brwr_fil_pos_er_snd_flg)OR(no_cof_grnd_err_snd_flg))
    {
           gui_send_flg=SET;
           header_val=HEADER_DATA;
           array.app=BLOCKING_ERR;
           if(plc_es_brwr_err_snd)
           {
               plc_es_brwr_err_snd=CLEAR_1;
               array.fun=BLCKING_ERR_SEND;
               error_id[0]='1';
               error_id[1]='4';
               block_id=STR_ERR_SEND;
           }
           else if(plced_es_brwr_err_snd)
           {
               plced_es_brwr_err_snd=CLEAR_1;
               array.fun=BLCKING_ERR_CLEARED;
               error_id[0]='1';
               error_id[1]='4';
               block_id=STR_ERR_RMV;
           }
           else if(brwr_init_send_flg)
           {
               brwr_init_send_flg=CLEAR_1;
               array.fun=BLCKING_ERR_SEND;
               error_id[0]='1';
               error_id[1]='5';
               block_id=STR_ERR_SEND;
           }
           else if(brwr_init_done_flg)
           {
               brwr_init_done_flg=CLEAR_1;
               array.fun=BLCKING_ERR_CLEARED;
               error_id[0]='1';
               error_id[1]='5';
               block_id=STR_ERR_RMV;
           }
           else if(es_brwr_brew_pos_er_snd_flg)
           {
               es_brwr_brew_pos_er_snd_flg=CLEAR_1;
               array.fun=BLCKING_ERR_SEND;
               error_id[0]='4';
               block_id=STR_ERR_SEND;
           }
           else if(es_brwr_fil_pos_er_snd_flg)
           {
               es_brwr_fil_pos_er_snd_flg=CLEAR_1;
               array.fun=BLCKING_ERR_SEND;
               error_id[0]='5';
               block_id=STR_ERR_SEND;
           }
           else if(no_cof_grnd_err_snd_flg)
           {
               no_cof_grnd_err_snd_flg=CLEAR_1;
               array.fun=BLCKING_ERR_SEND;
               error_id[0]='3';
               block_id=STR_ERR_SEND;
           }
    }
    else if((eprs_blr_flng_snd_flg)OR(esp_blr_flng_cmplt_snd_flg)OR(opn_blr_flng_snd_flg)OR(opn_blr_flng_done_snd_flg)OR(es_blr_htng_snd_flg)OR(es_blr_heat_cmplt_flg)OR(open_blr_htng_snd_flg)OR(opn_blr_heat_cmplt_flg)OR(es_flow_err_send_flag))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=BLOCKING_ERR;
        if(eprs_blr_flng_snd_flg)
        {
            eprs_blr_flng_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='1';
            block_id=STR_ERR_SEND;
        }
        else if(esp_blr_flng_cmplt_snd_flg)
        {
            esp_blr_flng_cmplt_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='1';
            block_id=STR_ERR_RMV;
        }
        else if(opn_blr_flng_snd_flg)
        {
            opn_blr_flng_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='7';
            block_id=STR_ERR_SEND;
        }
        else if(opn_blr_flng_done_snd_flg)
        {
            opn_blr_flng_done_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='7';
            block_id=STR_ERR_RMV;
        }
        else if(es_blr_htng_snd_flg)
        {
            es_blr_htng_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='2';
            block_id=STRNG_ES_BLR_TEMP;
        }
        else if(es_blr_heat_cmplt_flg)
        {
            es_blr_heat_cmplt_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='2';
            block_id=STRNG_ES_BLR_TEMP_CLR;
        }
        else if(open_blr_htng_snd_flg)
        {
            open_blr_htng_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='8';
            block_id=STRNG_OPEN_BLR_TEMP;
        }
        else if(opn_blr_heat_cmplt_flg)
        {
            opn_blr_heat_cmplt_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='8';
            block_id=STRNG_OPEN_BLR_TEMP_CLR;
        }
        else if(es_flow_err_send_flag)
        {
            es_flow_err_send_flag=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='6';
            block_id=STR_ERR_SEND;
        }
    }
    else if((out_of_fltr_ppr_err_snd_flg)OR(out_of_fltr_ppr_err_clr_snd_flg)OR(wst_bin_full_err_snd_flg)OR(wst_bin_full_err_clr_snd_flg)OR(wst_bin_not_prsnt_snd_flg)OR(wst_bin_prsnt_snd_flg)OR(fb_brwr_run_time_err_snd_flg)OR(fb_brwr_run_time_err_snd_clr_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=BLOCKING_ERR;
        if(out_of_fltr_ppr_err_snd_flg)
        {
            out_of_fltr_ppr_err_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='9';
            block_id=STR_ERR_SEND;
        }
        else if(out_of_fltr_ppr_err_clr_snd_flg)
        {
            out_of_fltr_ppr_err_clr_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='9';
            block_id=STR_ERR_RMV;
        }
        else if(wst_bin_full_err_snd_flg)
        {
            wst_bin_full_err_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='1';
            error_id[1]='1';
            block_id=STR_ERR_SEND;
        }
        else if(wst_bin_full_err_clr_snd_flg)
        {
            wst_bin_full_err_clr_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='1';
            error_id[1]='1';
            block_id=STR_ERR_RMV;
        }
        else if(wst_bin_not_prsnt_snd_flg)
        {
            wst_bin_not_prsnt_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='1';
            error_id[1]='2';
            block_id=STR_ERR_SEND;
        }
        else if(wst_bin_prsnt_snd_flg)
        {
            wst_bin_prsnt_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='1';
            error_id[1]='2';
            block_id=STR_ERR_RMV;
        }
        else if(fb_brwr_run_time_err_snd_flg)
        {
            fb_brwr_run_time_err_snd_flg=CLEAR_1;
            array.fun=BLCKING_ERR_SEND;
            error_id[0]='1';
            error_id[1]='3';
            block_id=STR_ERR_SEND;
        }
        else if(fb_brwr_run_time_err_snd_clr_flg)
        {
            fb_brwr_run_time_err_snd_clr_flg=CLEAR_1;
            array.fun=BLCKING_ERR_CLEARED;
            error_id[0]='1';
            error_id[1]='3';
            block_id=STR_ERR_RMV;
        }
    }
    else if((have_drip_tray_place_err_snd_flg)OR(restart_id_2_send_flg)OR(brwr_abort_infmation_snd_flg)OR(plc_container_undr_outlet_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=REINIT_POPUP;
        array.fun=INITIATE_THE_REINIT_POPUP;
        if(have_drip_tray_place_err_snd_flg)
        {
            have_drip_tray_place_err_snd_flg=CLEAR_1;
            error_id[0]='3';
        }
        else if(restart_id_2_send_flg)
        {
            restart_id_2_send_flg=CLEAR_1;
            error_id[0]='2';
        }
        else if(brwr_abort_infmation_snd_flg)
        {
            brwr_abort_infmation_snd_flg=CLEAR_1;
            error_id[0]='4';
        }
        else if(plc_container_undr_outlet_snd_flg)
        {
            plc_container_undr_outlet_snd_flg=CLEAR_1;
            error_id[0]='1';
        }
        else if(waste_bin_pop_snd_flg)
        {
            waste_bin_pop_snd_flg=CLEAR_1;
            error_id[0]='5';
        }
        block_id=STR_ERR_SEND;
    }
    else if((esp_blr_stp_flng_er_snd_flg)OR(es_sys_err_snd_flg)OR(air_blr_sys_err_snd_flg)OR(air_blr_stp_flng_er_snd_flg)OR(es_blr_rch_tm_err_snd_flg)OR(es_htr_snsr_err_snd_flg)OR(open_blr_htr_snsr_err_snd_flg)OR(open_blr_rch_tm_err_snd_flg)OR(grndr_sply_vltg_err_snd_flg)OR(grndr_mtr_ovr_load_err_snd_flg)OR(grndr_jmd_err_snd_flg)OR(grndr_mtr_drvn_lng_err_snd_flg)OR(grndr_on_at_strtup_err_snd_flg)OR(es_brwr_full_rotat_er_snd_flg)OR(init_fb_pos_err_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=CRITICAL_ER;
        array.fun=CRTCL_ER_SEND;
        if(es_sys_err_snd_flg)
        {
            es_sys_err_snd_flg=CLEAR_1;
            error_id[0]='2';
        }
        else if(esp_blr_stp_flng_er_snd_flg)
        {
            esp_blr_stp_flng_er_snd_flg=CLEAR_1;
            error_id[0]='1';
        }
        else if(air_blr_sys_err_snd_flg)
        {
            air_blr_sys_err_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='1';
        }
        else if(air_blr_stp_flng_er_snd_flg)
        {
            air_blr_stp_flng_er_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='0';
        }
        else if(es_blr_rch_tm_err_snd_flg)
        {
            es_blr_rch_tm_err_snd_flg=CLEAR_1;
            error_id[0]='3';
        }
        else if(es_htr_snsr_err_snd_flg)
        {
            es_htr_snsr_err_snd_flg=CLEAR_1;
            error_id[0]='4';
        }
        else if(open_blr_htr_snsr_err_snd_flg)
        {
            open_blr_htr_snsr_err_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='3';
        }
        else if(open_blr_rch_tm_err_snd_flg)
        {
            open_blr_rch_tm_err_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='2';
        }
        else if(grndr_sply_vltg_err_snd_flg)
        {
            grndr_sply_vltg_err_snd_flg=CLEAR_1;
            error_id[0]='5';
        }
        else if(grndr_mtr_ovr_load_err_snd_flg)
        {
            grndr_mtr_ovr_load_err_snd_flg=CLEAR_1;
            error_id[0]='6';
        }
        else if(grndr_jmd_err_snd_flg)
        {
            grndr_jmd_err_snd_flg=CLEAR_1;
            error_id[0]='7';
        }
        else if(grndr_mtr_drvn_lng_err_snd_flg)
        {
            grndr_mtr_drvn_lng_err_snd_flg=CLEAR_1;
            error_id[0]='8';
        }
        else if(grndr_on_at_strtup_err_snd_flg)
        {
            grndr_on_at_strtup_err_snd_flg=CLEAR_1;
            error_id[0]='9';
        }
        else if(es_brwr_full_rotat_er_snd_flg)           //This is changed from blocking error
        {
            es_brwr_full_rotat_er_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='4';
        }
        else if(init_fb_pos_err_snd_flg)             //This is changed from blocking error
        {
            init_fb_pos_err_snd_flg=CLEAR_1;
            error_id[0]='1';
            error_id[1]='5';
        }
        block_id=STR_ERR_SEND;
    }
    else if(wtr_run_time_done_snd_flg)
    {
        wtr_run_time_done_snd_flg=CLEAR_1;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=WATER_RUN_TIME_TEST;
        array.fun=WTR_RUN_COMPLETE;
        a_val=6;
        block_id=STR_COMMMON;
    }
    else if((indvdl_rins_done_snd_flg)OR(all_mixer_rinse_done_snd_flg)OR(rinse_all_complete_snd_flg)OR(step1_completed_snd_flg)OR(step2_completed_snd_flg)OR(espress_drnk_clng_dspns_strt_flg)OR(espress_drnk_clng_dspns_complt_flg)OR(brwr_pos_id_for_rins_snd_flg)OR(mixer_id_send_flg)OR(frsh_brwr_mvng_done_snd_flg))//(step3_completed_snd_flg)
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=RINSE_MENU;
        if(brwr_pos_id_for_rins_snd_flg)
        {
            brwr_pos_id_for_rins_snd_flg=CLEAR_1;
            array.fun=BRWR_POS_SEND;
            sprintf(error_id,"%hu",brwr_pos_id_for_rins);
            brwr_pos_id_for_rins=0;
            block_id=STR_BRWR_POS_SEND;
        }
        else if(indvdl_rins_done_snd_flg)
        {
            indvdl_rins_done_snd_flg=CLEAR_1;
            array.fun=CH_RINSE_DONE;
            a_val=6;
            block_id=STR_COMMMON;
        }
        else if(mixer_id_send_flg)
        {
            mixer_id_send_flg=CLEAR_1;
            array.fun=RINSE_MIXER_ID;
            sprintf(error_id,"%hu",rinse_id);
            block_id=STR_MXR_ID_SND;
        }
        else if(all_mixer_rinse_done_snd_flg)
        {
            all_mixer_rinse_done_snd_flg=CLEAR_1;
            array.fun=ALL_MIXER_DONE;
            a_val=6;
            block_id=STR_COMMMON;
        }
        else if(rinse_all_complete_snd_flg)
        {
            rinse_all_complete_snd_flg=CLEAR_1;
            array.fun=RINSE_ALL_DONE;
            a_val=11;
            block_id=STR_COMMMON;
        }
        else if((step1_completed_snd_flg)OR(step2_completed_snd_flg))//OR(step3_completed_snd_flg))
        {
            array.fun=ESPRS_CLNG_STEP_DONE;
            block_id=ESP_CLN_STEP_STR;
            if(step1_completed_snd_flg)
            {
                step1_completed_snd_flg=CLEAR_1;
                a_val=9;
            }
            else if(step2_completed_snd_flg)
            {
                step2_completed_snd_flg=CLEAR_1;
                a_val=12;
            }
//            else if(step3_completed_snd_flg)
//            {
//                step3_completed_snd_flg=CLEAR_1;
//                a_val=13;
//            }
        }
        else if((espress_drnk_clng_dspns_strt_flg)OR(espress_drnk_clng_dspns_complt_flg))
        {
            if(espress_drnk_clng_dspns_strt_flg)
            {
                espress_drnk_clng_dspns_strt_flg=CLEAR_1;
                array.fun=ES_DRNK_STRT;
                a_val=9;
            }
            else if(espress_drnk_clng_dspns_complt_flg)
            {
                espress_drnk_clng_dspns_complt_flg=CLEAR_1;
                array.fun=ES_DRNK_DONE;
                a_val=10;
            }
            block_id=STR_COMMMON;
        }
        else if(frsh_brwr_mvng_done_snd_flg)
        {
            frsh_brwr_mvng_done_snd_flg=CLEAR_1;
            array.fun=FB_MVNG_DONE;
            a_val=6;
            block_id=STR_COMMMON;
        }
    }
    else if((canister_test_done)OR(wtr_op_test_done)OR(es_brwr_tst_fail_snd_flg)OR(es_brwr_test_complete_snd_flg)OR(ar_brk_tst_stp_cmplt_snd_flg)OR(es_blr_fil_tst_cmnd_snd_flg)OR(es_htr_ft_tmp_snd_flg)OR(es_htr_tst_id_snd_flg)OR(opn_blr_fil_tst_cmnd_snd_flg)OR(opn_blr_htr_ft_tmp_snd_flg)OR(opn_blr_htr_tst_id_snd_flg)OR(sensr_sw_ft_stp_complt_flg)OR(sensr_sw_ft_tst_done_flg)OR(ar_test_popup_flg)OR(ar_tst_initiate_snd_flg)OR(es_fil_tst_initiate_snd_flg)OR(es_blr_ht_tst_initiate_flg)OR(snsr_sw_popup_flg)OR(snsr_sw_rdy_flg)OR(opn_blr_ht_initiate_snd_flg)OR(reset_fb_tmr_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=FACTORY_TEST;
        if(canister_test_done)
        {
            canister_test_done=CLEAR_1;
            array.fun=CANISTER_MTR_DONE;
            sprintf(error_id,"%hu",canister_test_id);
            canister_test_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if(reset_fb_tmr_snd_flg)
        {
            reset_fb_tmr_snd_flg=CLEAR_1;
            array.fun=FB_TMR_RESET;
            a_val=9;
            block_id=STR_COMMMON;
        }
        else if(wtr_op_test_done)
        {
            wtr_op_test_done=CLEAR_1;
            array.fun=WTR_MXR_DONE;
            sprintf(error_id,"%hu",wtr_op_test_id);
            wtr_op_test_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if(es_brwr_tst_fail_snd_flg)
        {
            es_brwr_tst_fail_snd_flg=CLEAR_1;
            array.fun=ESP_BRWR_FAIL;
            a_val=14;
            block_id=STR_COMMMON;
        }
        else if(es_brwr_test_complete_snd_flg)
        {
            es_brwr_test_complete_snd_flg=CLEAR_1;
            array.fun=ESP_BRWR_DONE;
            fb_dly_timer=5;
            a_val=10;
            block_id=STR_COMMMON;
        }
        else if((ar_test_popup_flg)AND(fb_dly_timer==0))
        {
            ar_test_popup_flg=CLEAR_1;
            array.fun=AR_BRK_POPUP;
            a_val=15;
            block_id=STR_COMMMON;
        }
        else if((ar_tst_initiate_snd_flg)AND(fb_dly_timer==0))
        {
            ar_tst_initiate_snd_flg=CLEAR_1;
            array.fun=AIR_BRK_INITIATE;
            a_val=9;
            block_id=STR_COMMMON;
        }
        else if(ar_brk_tst_stp_cmplt_snd_flg)
        {
            ar_brk_tst_stp_cmplt_snd_flg=CLEAR_1;
            array.fun=AR_BRK_TEST_ID;
            sprintf(error_id,"%hu",ar_brk_tst_case_id);
            ar_brk_tst_case_id=(ar_brk_tst_case_id<4)?++ar_brk_tst_case_id:(fb_dly_timer=5),0;
            block_id=STR_TST_OP_ID;
        }
        else if((es_blr_fil_tst_cmnd_snd_flg)AND(fb_dly_timer==0))
        {
            es_blr_fil_tst_cmnd_snd_flg=CLEAR_1;
            array.fun=ES_LVL_STS_DONE;
            sprintf(error_id,"%hu",es_blr_fil_tst_id);
            if(es_blr_fil_tst_id==3)
                fb_dly_timer=5;
            es_blr_fil_tst_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if((es_fil_tst_initiate_snd_flg)AND(fb_dly_timer==0))
        {
            es_fil_tst_initiate_snd_flg=CLEAR_1;
            array.fun=ES_BLR_FILL_INITATE;
            a_val=9;
            block_id=STR_COMMMON;
        }
        else if((es_blr_ht_tst_initiate_flg)AND(fb_dly_timer==0))
        {
            es_blr_ht_tst_initiate_flg=CLEAR_1;
            array.fun=ES_BLR_HEAT_INITIATE;
            a_val=9;
            block_id=STR_COMMMON;
        }
        else if((es_htr_ft_tmp_snd_flg)AND(fb_dly_timer==0))
        {
            es_htr_ft_tmp_snd_flg=CLEAR_1;
            array.fun=ES_BLR_CRNT_TEMP;
            block_id=SEND_TMP_FOR_FT_ES_BLR;
        }
        else if((es_htr_tst_id_snd_flg)AND(fb_dly_timer==0))
        {
            es_htr_tst_id_snd_flg=CLEAR_1;
            array.fun=ES_BLR_HEAT_TST_ID;
            sprintf(error_id,"%hu",es_htr_tst_id);
            es_htr_tst_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if(opn_blr_fil_tst_cmnd_snd_flg)
        {
            opn_blr_fil_tst_cmnd_snd_flg=CLEAR_1;
            array.fun=OPN_BLR_LVL_STS_DONE;
            sprintf(error_id,"%hu",opn_blr_fil_tst_id);
            if(opn_blr_fil_tst_id==2)
                fb_dly_timer=20;
            opn_blr_fil_tst_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if((opn_blr_ht_initiate_snd_flg)AND(fb_dly_timer==0))
        {
            opn_blr_ht_initiate_snd_flg=CLEAR_1;
            array.fun=OPN_BLR_HEAT_INITIATE;
            a_val=9;
            block_id=STR_COMMMON;
        }
        else if((opn_blr_htr_ft_tmp_snd_flg)AND(fb_dly_timer==0))
        {
            opn_blr_htr_ft_tmp_snd_flg=CLEAR_1;
            array.fun=OPN_BLR_CRNT_TEMP;
            block_id=SEND_TMP_FOR_FT_OPN_BLR;
        }
        else if((opn_blr_htr_tst_id_snd_flg)AND(fb_dly_timer==0))
        {
            opn_blr_htr_tst_id_snd_flg=CLEAR_1;
            array.fun=OPN_BLR_HEAT_TST_ID;
            sprintf(error_id,"%hu",opn_blr_htr_tst_id);
            opn_blr_htr_tst_id=0;
            block_id=STR_TST_OP_ID;
        }
        else if(snsr_sw_popup_flg)
        {
            snsr_sw_popup_flg=CLEAR_1;
            array.fun=SNSR_SW_POPUP;
            sprintf(error_id,"%hu",sensr_sw_ft_id);
            block_id=STR_TST_OP_ID;
        }
        else if(snsr_sw_rdy_flg)
        {
            snsr_sw_rdy_flg=CLEAR_1;
            array.fun=SNSR_SW_READY_FOR_TEST;
            sprintf(error_id,"%hu",sensr_sw_ft_id);
            block_id=STR_TST_OP_ID;
        }
        else if(sensr_sw_ft_stp_complt_flg)
        {
            sensr_sw_ft_stp_complt_flg=CLEAR_1;
            array.fun=SNSR_SW_TEST_ID;
            sprintf(error_id,"%hu",sensr_sw_ft_id);
            error_id[1]='|';
            sprintf(&error_id[2],"%hu",sensr_sw_ft_case_id);
            sensr_sw_ft_case_id=(sensr_sw_ft_case_id<2)?++sensr_sw_ft_case_id:0;
            block_id=STR_TST_OP_ID;
        }
        else if(sensr_sw_ft_tst_done_flg)
        {
            sensr_sw_ft_tst_done_flg=CLEAR_1;
            array.fun=SNSR_SW_TEST_COMP;
            sprintf(error_id,"%hu",sensr_sw_ft_id);
            sensr_sw_ft_id=0;
            block_id=STR_TST_OP_ID;
        }
    }
    else if((send_tmp_empt_blr_seq)OR(stop_done_send_flg)OR(empt_seq_cmplt_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=ESPRESSO_BLR_EMP_SEQ;
        if(send_tmp_empt_blr_seq)
        {
            send_tmp_empt_blr_seq=CLEAR_1;
            array.fun=SEND_TMP;
            block_id=SEND_TMP_FOR_EMPT_BLR;
        }
        else if(stop_done_send_flg)
        {
            stop_done_send_flg=CLEAR_1;
            array.fun=STOP_DONE_SEQ;
            a_val=6;
            block_id=STR_COMMMON;
        }
        else if(empt_seq_cmplt_snd_flg)
        {
            empt_seq_cmplt_snd_flg=CLEAR_1;
            array.fun=COMPLETED_EMPTY_SEQ;
            a_val=7;
            block_id=STR_COMMMON;
        }
    }
    else if(es_flow_warning_send_flag)
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=WARNING;
        if(es_flow_warning_send_flag)
        {
            es_flow_warning_send_flag=CLEAR_1;
            array.fun=ES_FLOW_WARNING;
            error_id[0]='1';
        }
        block_id=STR_ERR_SEND;
    }
    else if((machine_ready_flg)OR(ms_init_start_snd_flg)OR(block_maintain_scrn_snd_flg)OR(allow_maintain_scrn_snd_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=MACHINE_INFO;
        if(machine_ready_flg)
        {
            machine_ready_flg=CLEAR_1;
            array.fun=MACHINE_READY;
            a_val=2;
        }
        else if(ms_init_start_snd_flg)
        {
            ms_init_start_snd_flg=CLEAR_1;
            array.fun=MS_INIT_START;
            a_val=8;
        }
        else if((block_maintain_scrn_snd_flg)OR(allow_maintain_scrn_snd_flg))
        {
            array.fun=ALLOW_OR_DONT_ALLOW;
            if(block_maintain_scrn_snd_flg)
                block_maintain_scrn_snd_flg=CLEAR_1, a_val=10;
            else if(allow_maintain_scrn_snd_flg)
                allow_maintain_scrn_snd_flg=CLEAR_1, a_val=9;
        }
        block_id=STR_COMMMON;
    }
    else if((send_sensor_status_flag)AND(sensr_sts_req_flg))
    {
        send_sensor_status_flag=CLEAR_1;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=SENSOR_STATUS;
        array.fun=SENSOR_STATUS_SEND;
        block_id=STR_SENSOR_STATUS;
    }
    else if((output_off_timeout_flg)OR(output_off_normal_flg))
    {
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=ON_OFF_OUTPUTS;
        array.fun=BREWER_OUTPUT_OFF;
        output_id+=400;
        sprintf(error_id,"%hu",output_id);
        output_id=0;
        if(output_off_timeout_flg)
        {
            output_off_timeout_flg=CLEAR_1;
            error_id[strlen(error_id)]='|';
            error_id[strlen(error_id)]='1';
        }
        else if(output_off_normal_flg)
            output_off_normal_flg=CLEAR_1;
        block_id=STR_ERR_SEND;
    }
    else if(calibrate_cmplt_flg)
    {
        calibrate_cmplt_flg=CLEAR_1;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=ON_OFF_OUTPUTS;
        array.fun=CANISTER_CAL_OFF;
        sprintf(error_id,"%hu",canister_id);
        canister_id=0;
        block_id=STR_ERR_SEND;
    }
    else if(date_time_send_flg)
    {
        date_time_send_flg=CLEAR_1;
        gui_send_flg=SET;
        header_val=HEADER_DATA;
        array.app=RTC_APP_ID;
        array.fun=RTC_SEND;
        block_id=STR_RTC;
    }
}


unsigned char hex_to_dec_converter(unsigned char value)
{
    unsigned char temp;
    temp=value;
    temp=(unsigned char)((temp>>4)*10);
    value=(unsigned char)(temp+((value&0X0F)));
    return value;
}

void date_time_fun(unsigned char value, bool skip_zero)
{
    unsigned char i,j,k,credit_data_siz,amt_arr[3];
    memset(amt_arr,0,sizeof(amt_arr));
    sprintf(amt_arr,"%hu",value);
    for(i=0,j=0,credit_data_siz=0;i<2;i++)
    {
        if(amt_arr[i]>0)
        credit_data_siz++;
    }
    if((credit_data_siz==1)AND(!skip_zero))
        gui_tx_buff[tx_buff++]='0';
    for(i=0;i<credit_data_siz;i++)
        gui_tx_buff[tx_buff++]=amt_arr[i];
}

