/*
 * GET_SET_VAL.c
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */
#include "ANDROID_UART.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "stdlib.h"
#include "string.h"

void settings();
void drink_settings();
void canister_mixer_arrangment();
void all_settings();
void rinse_menu_settings_fn();
void clear_previous_step_date(unsigned char );

void remove_ssid_value(unsigned char ,unsigned int, unsigned char[] );
int str_compare(char [],char []);
void cpy_arr(int [],int []);

int str_compare(char a[],char b[])
{
    int flag=0,i=0;  // integer variables declaration
    while(a[i]!='\0' &&b[i]!='\0')  // while loop
    {
       if(a[i]!=b[i])
       {
           flag=1;
           break;
       }
       i++;
    }
    if(flag==0)
    return 1;
    else
    return 0;
}
//void cpy_arr(int get_arr[],int from_arr[])
//{
//    unsigned char len=sizeof(from_arr)/sizeof(from_arr[0]);         //we got len of the int array
//    for(unsigned char i=0;i<len;i++)
//        get_arr[i]=from_arr[i];
//}

void settings()
{
    unsigned char data_backup_buff[3],j=0,k=0;
    memset(data_backup_buff,0,sizeof(data_backup_buff));
    if(app_id==0X02)
    {
        if(fun_id==CHANNEL_CONFIGURATION)
            canister_mixer_arrangment();
        else if(fun_id==MILK_SUGAR_CAN)
        {
            remove_ssid_value(0,300,string_process_data_buf);
            milk_canister=val_store_array[1];
            sugar_canister=val_store_array[2];
        }
        else if(fun_id==GEN_SETT)
            remove_ssid_value(0,0,string_process_data_buf);
        else if(fun_id==RINSE_MENU_SETTINGS)
            rinse_menu_settings_fn();
        else
           drink_settings();
    }
    else if(app_id==0X07)
    {
        if(fun_id==CHANGE_RTC)
        {
            for(unsigned char i=0;i<strlen(string_process_data_buf);i++)
            {
                if(string_process_data_buf[i]=='|')
                {
                    date_time_arr[k++]=atoi(data_backup_buff);
                    j=0;
                    memset(data_backup_buff,0,sizeof(data_backup_buff));
                }
                else
                {
                    data_backup_buff[j++]=string_process_data_buf[i];
                    if(k==5)
                    {
                        date_time_arr[5]=atoi(data_backup_buff);
                        date_time_arr[5]=date_time_arr[5]==1?1:(date_time_arr[5]==2?2:(date_time_arr[5]==3?4:(date_time_arr[5]==4?8:(date_time_arr[5]==5?10:(date_time_arr[5]==6?20:40)))));
                    }
                }
            }
        }
    }
}
/*
 * rinse id|ssid:value|ssid:value$rinse id|ssid:value|ssid:value
 * 1 to 5|191:2.5|192:2|193:0.25|194:1|195:100|196:5 - mixer
 * 6 to 8|191:2.5|192:2|193:0.25    -   water systems
 * 9|197:2.5|198:10|199:0.25|200:5|201:3|202:0  -   fresh brewer rinsing
 * 10|203:12    -   replace filter paper
 * 11|204:10|205:1|206:1    -   espresso brewer rinsing
 * 12|207:0|208:3.5|209:5|210:1|211:1   -   flush open position
 * 13|212:2|213:20|214:10|215:1     -   espresso brewer cleaning cycle
 * 14|216:0     -   dispense drink after espresso cleaning
 */
void rinse_menu_settings_fn()
{
    unsigned char set_id_arr[3],value_arr[5],ssid_val_arr[3];
    unsigned int i=0,j=0,k=0;
    memset(set_id_arr,0,sizeof(set_id_arr));
    memset(value_arr,0,sizeof(value_arr));
    memset(ssid_val_arr,0,sizeof(ssid_val_arr));
    rinse_set_id=parmtr_ssid=0;
    for(i=0;i<strlen(string_process_data_buf);i++)
    {
        if(string_process_data_buf[i]=='|')
        {
            rinse_set_id=atoi(set_id_arr);
            memset(set_id_arr,0,sizeof(set_id_arr));
            for(j=0,i=++i;(i<strlen(string_process_data_buf))AND(string_process_data_buf[i]!='$');i++)
            {
                if(string_process_data_buf[i]==':')
                {
                    parmtr_ssid=atoi(ssid_val_arr);
                    for(k=0,i=++i;(i<strlen(string_process_data_buf))AND(string_process_data_buf[i]!='$')AND(string_process_data_buf[i]!='|');k++,i++)
                    {
                        if(string_process_data_buf[i]=='.')
                            dot_flag=SET;
                        value_arr[k]=string_process_data_buf[i];
                    }
                    rnse_menu_set[rinse_set_id][RINSE_SET_MINUS_SSID]=dot_flag?((((rinse_set_id>=1)AND(rinse_set_id<=8))AND(CH_RINSE_SET_EXPT_TIME))OR((rinse_set_id==9)AND(FRESH_BRWR_RINSE_EXPT_TIME))OR((rinse_set_id==11)AND(RINSE_ESPRS_BRWR_EXPT_TIME))OR((rinse_set_id==12)AND(FLUSH_ESPRS_BRWR_EXPT_TIME))OR((rinse_set_id==13)AND(ESPRS_BRWR_CLNG_CYCL))OR((rinse_set_id==14)AND(ESPRS_DRNK_AFTR_CLNG)))?(atof(value_arr)*1):(atof(value_arr)*100):((((rinse_set_id>=1)AND(rinse_set_id<=8))AND(CH_RINSE_SET_EXPT_TIME))OR((rinse_set_id==9)AND(FRESH_BRWR_RINSE_EXPT_TIME))OR((rinse_set_id==11)AND(RINSE_ESPRS_BRWR_EXPT_TIME))OR((rinse_set_id==12)AND(FLUSH_ESPRS_BRWR_EXPT_TIME))OR((rinse_set_id==13)AND(ESPRS_BRWR_CLNG_CYCL))OR((rinse_set_id==14)AND(ESPRS_DRNK_AFTR_CLNG)))?(atoi(value_arr)*1):(atoi(value_arr)*100);
                    memset(value_arr,0,sizeof(value_arr));
                    dot_flag=CLEAR_1;
                    k=j=0;
                    if(string_process_data_buf[i]=='$')
                        break;
                }
                else
                    ssid_val_arr[j++]=string_process_data_buf[i];
            }
        }
        else
            set_id_arr[j++]=string_process_data_buf[i];
    }
}

void remove_ssid_value(unsigned char start_from,unsigned int subtract_from,unsigned char get_array[])
{
    unsigned int i=0;
    unsigned char j=0,k=0,ssid_array[5],value_array[5];
    memset(val_store_array,0,sizeof(val_store_array));
    memset(ssid_array,0,sizeof(ssid_array));
    memset(value_array,0,sizeof(value_array));

    for(i=start_from;i<strlen(get_array);i++)
    {
        if(get_array[i]==':')
        {
            ssid=atoi(ssid_array);
            for(i=++i,k=j=0;(i<strlen(get_array))AND(get_array[i]!='|');i++)
            {
                if(get_array[i]=='.')
                    dot_flag=SET;
                value_array[k++]=get_array[i];
            }
            if((app_id==0x02)AND(fun_id==GEN_SETT))
                drnk_genral_set[GENERAL_SET_ARRAY_STORE]=(GENERAL_SET_SECONDS)OR(GERERAL_SET_MINUTES)?(dot_flag?atof(value_array)*(GERERAL_SET_MINUTES?60:100):atoi(value_array)*(GERERAL_SET_MINUTES?60:100)):atoi(value_array);
            else
            {
                ssid_value=atoi(value_array);
                val_store_array[ssid-subtract_from]=ssid_value;
            }
            dot_flag=CLEAR_1;

            memset(ssid_array,0,sizeof(ssid_array));
            memset(value_array,0,sizeof(value_array));
        }
        else
            ssid_array[j++]=get_array[i];
    }
}
/*
 drink settings
1. channel en id/dis|value- 34|1
2. primary settings - 35|ssid:value
3. ch/hw/cw. ch-steps - 32|1$step no|ch id-cycle$.....
4. channels settings - ch id|ssid:value$...
channel configuration
1. ch id|ch status|water&whipper ch|liquid choco status$...

general settings
1. id|ssid:value|ssid:value

*/
/*canister value
 * 1. i==1,i==3,i==5,i==7
 * 2. i==9, i==11, i==13, i==15
 * 3. i==17,i==19, i==21, i==23
 */
void canister_mixer_arrangment()
{
    unsigned char i=0,j=0;
    static unsigned char ch_id,ch_en,wtr_mxr,lqd_chco,ch_count,backup_value;
    unsigned char value_array[3];

    ch_count=ch_id=ch_en=wtr_mxr=lqd_chco=0;
    for(i=0;i<strlen(string_process_data_buf);i++)
    {
        if(string_process_data_buf[i]!='$')
        {
            if(string_process_data_buf[i]!='|')
            {
                value_array[j++]=string_process_data_buf[i],ch_count++;
                if((string_process_data_buf[i+1]=='$')OR(i+1==strlen(string_process_data_buf)))
                    goto GET_VAL_LABEL;
            }
            else
            {
                GET_VAL_LABEL:
                    backup_value=j=0;
                    backup_value=atoi(value_array);
                    if(ch_count==1) //channel id
                        ch_id=backup_value;
                    else if(ch_count==2)    //ingredient enable/disable
                        ch_en=backup_value;
                    else if(ch_count==3)    //water and mixer
                        wtr_mxr=backup_value;
                    else if(ch_count==4)    //liquid choco
                        lqd_chco=backup_value;
                    channel[ch_id]=ch_en?wtr_mxr:0;
                    liquid_choco_ch=lqd_chco?ch_id:(liquid_choco_ch==ch_id)?0:liquid_choco_ch;      // if enable add that channel, else need to check that channel is aready in liquid choco means clear, else still be in existing one
            }
        }
        else
            ch_count=ch_id=ch_en=wtr_mxr=lqd_chco=0;
    }
}


void drink_settings()
{
    unsigned char sub_fun_id[5],ssid_array[5],value_array[6],ch_id_array[5],steps_id_array[5],step_id=0,ch_id=0,cycle=0;
    unsigned int backup_Val[2],i=0,k=0,j=0;
    memset(sub_fun_id,0,sizeof(sub_fun_id));
    memset(backup_Val,0,sizeof(backup_Val));
    memset(steps_id_array,0,sizeof(steps_id_array));
    memset(value_array,0,sizeof(value_array));
    memset(ch_id_array,0,sizeof(ch_id_array));
    memset(ssid_array,0,sizeof(ssid_array));
    drnk_set_len=0;

    drnk_set_len=strlen(string_process_data_buf);
        strncpy(sub_fun_id,string_process_data_buf,2);
        if(str_compare(sub_fun_id,"34"))  //for know the status of the drink
        {
            backup_Val[0]=string_process_data_buf[3];
            drk_main_sett[fun_id-1][1]=atoi(backup_Val);
        }
        else if(str_compare(sub_fun_id,"36"))           // for know the drink type
        {
            backup_Val[0]=string_process_data_buf[3];
              drnk_ch_hw_cw[fun_id-1]=atoi(backup_Val);
              if(string_process_data_buf[3]=='1')         // if this channel means that case they send step settings also
              {
                  clear_previous_step_date((fun_id-1));
                  for(i=5;i<drnk_set_len;i++)
                  {
                      if(string_process_data_buf[i]=='|')
                      {
                          step_id=atoi(steps_id_array);
                          for(i=++i,k=1,j=0;(string_process_data_buf[i]!='$')AND(i<drnk_set_len);i++)
                          {
                              if(string_process_data_buf[i]!='|')
                              {
                                  if((string_process_data_buf[i]!='_')AND(string_process_data_buf[i]!='-'))
                                  value_array[j++]=string_process_data_buf[i];
                              }
                              else
                              {
                                  process_step[fun_id-1][step_id][k++]=atoi(value_array),j=0;
                                  memset(value_array,0,sizeof(value_array));
                              }

                          }
                          process_step[fun_id-1][step_id][k++]=atoi(value_array),j=0;       // WHEN LAST VALUE WITHOUT SPLIT THAT CASE
                          memset(steps_id_array,0,sizeof(steps_id_array));
                          memset(value_array,0,sizeof(value_array));

                      }
                      else
                          steps_id_array[0]=string_process_data_buf[i];         //step id have only one digit
                  }
              }
        }
        else if(str_compare(sub_fun_id,"35"))           //for primary settings
        {
            for(i=3,j=0;i<drnk_set_len;i++)
            {
                if(string_process_data_buf[i]==':')
                {
                    ssid=atoi(ssid_array);
                    for(i=++i,k=j=0;(string_process_data_buf[i]!='|')AND(i<drnk_set_len);i++)
                    {
                        if(string_process_data_buf[i]=='.')
                            dot_flag=SET;
                        value_array[k++]=string_process_data_buf[i];        //get ssid value
                    }
                    if((ssid>=87)AND(ssid<=98))
                        drk_main_sett[fun_id-1][ssid-85]=(dot_flag)?(atof(value_array)*((ssid==90)?10:100)):atoi(value_array)*((ssid==87)OR(ssid==93)?100:1);      //87,93 need 100, 90 NEED 10
                    dot_flag=CLEAR_1;
                    memset(value_array,0,sizeof(value_array));
                    memset(ssid_array,0,sizeof(ssid_array));
                }
                else
                    ssid_array[j++]=string_process_data_buf[i];     //get ssid
            }
        }
        else if((strcmp(sub_fun_id,"21")>=0)AND(strcmp(sub_fun_id,"31")<=0))              // -value - str1 less than str2, 0 - str1=str2, +value - str1 is greater than str2
        {
            for(i=0;i<drnk_set_len;i++)
            {
                if(string_process_data_buf[i]=='|')
                {
                    ch_id=atoi(ch_id_array);
                    memset(ch_id_array,0,sizeof(ch_id_array));
                    if((ch_id>=21)AND(ch_id<=26))
                    {
                        backup_Val[0]=string_process_data_buf[++i];
                        cycle=atoi(backup_Val),i++;     //cycle
                    }
                    for(i=++i,j=0;(string_process_data_buf[i]!='$')AND(i<drnk_set_len);i++)
                    {
                        if(string_process_data_buf[i]==':')
                        {
                            ssid=atoi(ssid_array);
                            for(i=++i,k=j=0;(string_process_data_buf[i]!='$')AND(i<drnk_set_len)AND(string_process_data_buf[i]!='|');i++)
                            {
                                if(string_process_data_buf[i]=='.')
                                    dot_flag=SET;
                                value_array[k++]=string_process_data_buf[i];
                            }
                            if((ssid>=41)AND(ssid<=54)) // FOR CHANNELS
                                drk_sett[fun_id-1][ch_id-20][(cycle==1)?ssid-40:ssid-26]=dot_flag?(atof(value_array)*((CH_TIME_VAL_SKIP)?1:100)):atoi(value_array)*((CH_TIME_VAL_SKIP)?1:100);
                            else if((ssid>=55)AND(ssid<=84))    //for espresso, freshbrew, beanbrew
                                other_than_instant[machine][fun_id-1][(machine==1)?((ssid==501)?(ssid-491):(ssid-54)):((machine==2)?ssid-63:(ssid<=78?ssid-63:ssid-78))]=dot_flag?atof(value_array)*((ES_FB_BB_TIME_VAL_SKIP)?1:100):atoi(value_array)*((ES_FB_BB_TIME_VAL_SKIP)?1:100);
                            else if((ssid==85)OR(ssid==86)) //for hot water, cold water
                                scondary_outlet_wtr_set[fun_id-1][ch_id-29][ssid-84]=dot_flag?atof(value_array)*100:atoi(value_array)*100;

                            dot_flag=CLEAR_1;
                            memset(value_array,0,sizeof(value_array));
                            memset(ssid_array,0,sizeof(ssid_array));
                            if(string_process_data_buf[i]=='$')
                                break;
                        }
                        else
                            ssid_array[j++]=string_process_data_buf[i];
                    }
                }
                else
                    ch_id_array[j++]=string_process_data_buf[i];
            }
        }
/*
 * 1. ch id - if id is from 27 to 31 that we save value into different array
 * 2. cycle id- if id is from 1 or 2 based on that save into the buffer
 * 3. value with ssid will compare and store in the respective buffer.
 * 4. 32,33 also for hw,cw save in the respective buffer
 *
 */
}

void clear_previous_step_date(unsigned char step_drnk_id)
{
    for(unsigned char clear_steps=0;clear_steps<5;clear_steps++)
    {
        for(unsigned char clear_selected_drink=0; clear_selected_drink<5;clear_selected_drink++)
        process_step[step_drnk_id][clear_steps][clear_selected_drink]=0;
    }
}

