/*
 * FAN_AND_EMPTY_BOILER.c
 *
 *  Created on: 28-Mar-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void fan_operation();
void empty_boiler_sequence();
void canister_calibration();
void bean_err();
void beep_fun();
/*
 * 1. fan continuous is on after complete initialization, we should on fan.
 * 2. if the fan on time is setted and fan continuous also setted, we give priority to fan continuous.
 * 3. if fan on during starting the dispense all product, espressso boiler fill, empty boiler,
 *    rinsing, cleaning, we need to switch on the fan , it will off after the fan as per the time.
 * 4. After completed this then only we start the fan on time counter, when drink taken it will resetted.
 *
 */

void fan_operation()
{
    if(!entered_fctry_tst_flg)
    {
        if(drnk_genral_set[fan_cntinus])
            FAN_ON,fan_on_during_dispns_flg=CLEAR_1;
        else
        {
            if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag)AND(!emt_blr_seq_strt_flg)AND(!ar_brk_fil_strt_flg)AND(!opn_blr_fil_strt_flg)AND(!rinse_value_get_flg)AND(!all_mixer_rinse_start_flag)AND(!rinse_all_start_flag)AND(!es_cln_strt_flg))
            {
                if(fan_on_during_dispns_flg)
                {
                    fan_on_during_dispns_flg=CLEAR_1;
                    fan_on_tmr=drnk_genral_set[fan_run_time];
                }
                else if((fan_on_tmr<=0)AND(fan_mtr_flg))
                    FAN_OFF;
            }
            else if((process_initiated_flag)OR(secondary_outlet_process_init_flag)OR(emt_blr_seq_strt_flg)OR(ar_brk_fil_strt_flg)OR(opn_blr_fil_strt_flg)OR(rinse_value_get_flg)OR(all_mixer_rinse_start_flag)OR(rinse_all_start_flag)OR(es_cln_strt_flg))
            {
                if(!fan_on_during_dispns_flg)
                {
                    FAN_ON;
                    fan_on_during_dispns_flg=SET;
                }
            }
        }
    }
    else
    {
        FAN_OFF;
        fan_on_during_dispns_flg=CLEAR_1;
        fan_on_tmr=0;
    }
}

/*
 * 1. After starting empty sequence, the heater must be off.
 * 2. Brewer must be in brew position.
 * 2. 3 way valve and pressure pump on till reach 40 degree.
 * 3. Deviation of temperature must be send.
 * 4. After reach 40 degree of the pressure pump and send a complete command and block the machine.
 * 5. If stops command get we need to stop the process and move the brewer into home position.
 * 6. Successfully moved then only we send the done command
 * 7. We will block all the process, machine will move on to off state.
 */

void empty_boiler_sequence()
{
    if(emt_blr_seq_strt_flg)
    {
        switch(emp_blr_seq)
        {
            case 1:                         //move brewer to brew position
                if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
                {
                    if(es_brwr_mtr_flg)
                    ESPRESSO_BREWER_OFF;
                    if(stop_empt_blr_seq_flg)
                        emp_blr_seq+=2;
                    else
                    emp_blr_seq++;
                }
                else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
                ESPRESSO_BREWER_ON;
                break;
            case 2:                         //process
                if(!stop_empt_blr_seq_flg)
                {
                    if(es_ctemp>40)
                    {
                        if((!three_way_vlv_flg)AND(!presure_pump_flg))
                        {
                            THREE_WAY_VALVE_ON;
                            PRESSURE_PUMP_ON;
                        }
                    }
                    else
                    {
                        PRESSURE_PUMP_OFF;
                        emp_blr_seq++;
                    }
                }
                else
                {
                    THREE_WAY_VALVE_OFF,PRESSURE_PUMP_OFF;
                    emp_blr_seq++;
                }
                break;
            case 3:                             //back to fill position
                if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                {
                    ESPRESSO_BREWER_OFF;
                    emp_blr_seq=0;
                    emp_blr_seq=emt_blr_seq_strt_flg=CLEAR_1;
                    if(stop_empt_blr_seq_flg)
                        stop_done_send_flg=SET,stop_empt_blr_seq_flg=CLEAR_1;
                    else
                    {
                        empt_seq_cmplt_snd_flg=Machine_err_flag=SET;
                        ALL_OUT_OFF;
                    }
                }
                else if(!es_brwr_mtr_flg)
                ESPRESSO_BREWER_ON;
                break;
        }
    }
}

void canister_calibration()
{
    if(calibrate_start_flg)
    {
        switch(canister_id)
        {
            case 1:         //canister 1
                if((can_run_sec_tmr<=0)AND(prmx1_on_flg))
                {
                    PRIMIX_MOTOR1_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx1_on_flg)
                {
                    PRIMIX_MOTOR1_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 2:         //canister 2
                if((can_run_sec_tmr<=0)AND(prmx2_on_flg))
                {
                    PRIMIX_MOTOR2_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx2_on_flg)
                {
                    PRIMIX_MOTOR2_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 3:         //canister 3
                if((can_run_sec_tmr<=0)AND(prmx3_on_flg))
                {
                    PRIMIX_MOTOR3_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx3_on_flg)
                {
                    PRIMIX_MOTOR3_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 4:         //canister 4
                if((can_run_sec_tmr<=0)AND(prmx4_on_flg))
                {
                    PRIMIX_MOTOR4_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx4_on_flg)
                {
                    PRIMIX_MOTOR4_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 5:         //canister 5
                if((can_run_sec_tmr<=0)AND(prmx5_on_flg))
                {
                    PRIMIX_MOTOR5_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx5_on_flg)
                {
                    PRIMIX_MOTOR5_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 6:         //canister 6
                if((can_run_sec_tmr<=0)AND(prmx6_on_flg))
                {
                    PRIMIX_MOTOR6_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!prmx6_on_flg)
                {
                    PRIMIX_MOTOR6_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
            case 7:         //canister 7
                if((can_run_sec_tmr<=0)AND(bean_grndr_on_flg))
                {
                    BEAN_GRINDER_OFF;
                    calibrate_start_flg=CLEAR_1;
                    calibrate_cmplt_flg=SET;
                }
                else if(!bean_grndr_on_flg)
                {
                    BEAN_GRINDER_ON;
                    can_run_sec_tmr=can_run_sec;
                }
                break;
        }
    }

}
/*
 * 1. for espresso and bean brew.
 * 2. During dispensing grinding product or canister calibration.
 * 2. within 100 Ms if the pulses got then the error will occur.
 * 3. we need count the pulses, how many pulse will got within the 100 ms.
 * 4. Based on that, we will identify the errors.
 */
void bean_err()
{
    if((espresso_machine_flag)OR(beanbrew_machine_flag))
    {
        if(grnd_err_get_flg)//(bean_grndr_on_flg)AND
        {
            if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
            {
                switch(grndr_err_id_pulse)
                {
                    case 1:
                        no_cof_grnd_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                    case 2:
                        grndr_sply_vltg_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                    case 3:
                        grndr_mtr_ovr_load_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                    case 4:
                        grndr_jmd_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                    case 5:
                        grndr_mtr_drvn_lng_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                    case 6:
                        grndr_on_at_strtup_err_snd_flg=SET;
                        grndr_err_id_pulse=0;
                        grnd_err_get_flg=CLEAR_1;
                        break;
                }
            }
            else if(!need_stop_drink_due_to_err_flg)
                need_stop_drink_due_to_err_flg=SET;
        }
    }
}

void beep_fun()
{
    if((buzzer_on_flg)AND(buzzer_on_time<=0))
    {
        BEEPER_OFF;
        beep_sound_flg=CLEAR_1;
    }
    else if(!buzzer_on_flg)
    {
        BEEPER_ON;
        buzzer_on_time=entered_fctry_tst_flg?500:100;
    }
}
