/*
 * HEATING.c
 *
 *  Created on: 31-Dec-2022
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define ES_SERIESRESISTOR      5100
//#define ES_THERMISTORNOMINAL   10000//12500 //10k
//#define ES_BETA_VAL           3435
#define ES_TEMPERATURENOMINAL  25

int roundNo(float num);
void check_temperature();
void espresso_boiler_heating();

int roundNo(float num)
{
    return num < 0 ? num - 0.5 : num + 0.5;
}

void check_temperature()
{
    float adc_vol_val,temp_value,ad_result1;
    drnk_genral_set[es_temp_snsr_resistnce]=10000;
    drnk_genral_set[es_temp_snsr_beta_val]=3977;
    drnk_genral_set[es_blr_deg_err_tol]=0;
    if(read_flg_es_boiler)
    {
        read_flg_es_boiler=0;
        ADC_INTERRUPT.p_api->read(ADC_INTERRUPT.p_ctrl,ADC_REG_CHANNEL_1,&es_ad_result);
        es_acc_temp[es_m++]=es_ad_result;
        if(es_m>=20)
        {
            es_m=0;
            es_acc_temp[2]=(es_acc_temp[0]+es_acc_temp[1]+es_acc_temp[2]+es_acc_temp[3]+es_acc_temp[4]+es_acc_temp[5]
                +es_acc_temp[6]+es_acc_temp[7]+es_acc_temp[8]+es_acc_temp[9]+es_acc_temp[10]+es_acc_temp[11]
                +es_acc_temp[12]+es_acc_temp[13]+es_acc_temp[14]+es_acc_temp[15]+es_acc_temp[16]+es_acc_temp[17]
                +es_acc_temp[18]+es_acc_temp[19])/20;
            ad_result1  = es_acc_temp[2];
            adc_vol_val = 1023 / ad_result1 - 1;
                adc_vol_val = ES_SERIESRESISTOR / adc_vol_val;
                temp_value  = adc_vol_val / drnk_genral_set[es_temp_snsr_resistnce];     // (R/Ro)
                temp_value  = log(temp_value);                  // ln(R/Ro)
                temp_value  /=  drnk_genral_set[es_temp_snsr_beta_val];                     // 1/B * ln(R/Ro)
                temp_value  += 1.0 / (ES_TEMPERATURENOMINAL + 273.15); // + (1/To)
                temp_value  = 1.0 / temp_value;                 // Invert
                temp_value  -= 273.15;
            temp_value  = roundNo(temp_value);
            es_ctemp=(unsigned char)temp_value;
            es_ctemp+=drnk_genral_set[es_blr_deg_err_tol];
            es_ctemp_value_get=SET;
            if(drnk_genral_set[es_htr_temp_temp_err_en]?count_es_temp_to_temp<drnk_genral_set[es_temp_temp_sec]:1)
            {
                if((((back_up_es_temp!=es_ctemp)AND(es_htr_tmp_chng_cnfrm>4))OR(first_es_blr_temp_flag))AND((espresso_heater_on_flg)OR(emt_blr_seq_strt_flg)))
                {
                    es_htr_tmp_chng_cnfrm=0;
                    first_es_blr_temp_flag=CLEAR_1;
                    back_up_es_temp=es_ctemp;
                    count_es_temp_to_temp=0;
                    if(one_tm_blr_htng_snd_flg)
                        es_blr_htng_snd_flg=SET;
                    else if(emt_blr_seq_strt_flg)
                        send_tmp_empt_blr_seq=SET;
                    else if(es_htr_ft_strt_flg)
                        es_htr_ft_tmp_snd_flg=SET;
                    else if(sensr_sts_req_flg)
                        send_sensor_status_flag=SET;
                }
                else if(!espresso_heater_on_flg)
                    count_es_temp_to_temp=0;
            }
            else
            {
                es_blr_heat_cmplt_flg=SET;
                es_blr_rch_tm_err_snd_flg=Machine_err_flag=SET;
                ALL_OUT_OFF;
                es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=es_blr_heat_cmplt_flg=CLEAR_1;
                es_htr_err_cnt=count_es_temp_to_temp=back_up_es_temp=es_ctemp=0;
                one_tm_es_blr_htng_cmplt_snd_flg=CLEAR_1;
            }
        }
    }
}
/*
 1. espresso boiler below hysteresis need to turn on heater till reach set temperature.
 2. if, espresso boiler below min operating temperature need to send a blocking error and turn on heater.
 3. during initialization need to heat till set temperature, that case also we need to used the blocking error.
 4. if, espresso boiler abvoe 125 need to send a critical error.
 5. if, espresso boiler below 10 minutes to reach the set temperature from any value.
 6. without error if its reach the set temperature need to move on to the next heating process for initialization.
 7. if heater temp to temp is enabled, then start count from the current temperature to next temp within the set time it's reach, else stop heater and send a critical error.
 */
void espresso_boiler_heating()
{
    if(es_ad_result<1000)
    {
        if(init_flag?!drip_lvl_chk_flag:(!emt_blr_seq_strt_flg)AND(!entered_fctry_tst_flg))
        {
            if((es_ctemp>=125)AND(es_htr_snsr_err_cnfrm_dly>50))        //5 sec for confirmation
            {
                es_blr_heat_cmplt_flg=SET;
                es_htr_snsr_err_snd_flg=Machine_err_flag=SET;
                ALL_OUT_OFF;
                es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=es_blr_heat_cmplt_flg=CLEAR_1;
                es_htr_err_cnt=count_es_temp_to_temp=back_up_es_temp=es_ctemp=0;
                one_tm_es_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
            }
            else if((((init_flag)AND(es_ctemp>=drnk_genral_set[es_op_set_temp]))OR((!init_flag)AND(espresso_heater_on_flg)AND(es_ctemp>drnk_genral_set[es_min_op_temp])))AND(es_htr_err_cnt<60))
            {
                if((es_ctemp>=drnk_genral_set[es_op_set_temp])AND(es_reach_set_temp_cnfrm>=10))
                {
                    if((espresso_heater_on_flg)AND(es_htr_err_cnt_flg))
                    ESPRESSO_HEATER_OFF;
                    es_blr_heat_cmplt_flg=init_flag?(one_tm_es_blr_htng_cmplt_snd_flg=SET,one_tm_blr_htng_snd_flg=CLEAR_1,(es_htr_err_cnt_flg?SET:CLEAR_1)):CLEAR_1;      //init time error will cleared till reach set temp
                    es_htr_err_cnt_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
                }
                else if((!init_flag)AND(es_ctemp>drnk_genral_set[es_min_op_temp])AND(one_tm_blr_htng_snd_flg))          //Run time error will be cleared when reach min temperature
                    es_blr_heat_cmplt_flg=SET,one_tm_blr_htng_snd_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
            }
            else
            {
                if((init_flag?es_ctemp<drnk_genral_set[es_op_set_temp]:es_ctemp<drnk_genral_set[es_op_set_temp]-drnk_genral_set[es_max_temp_var])AND(es_htr_err_cnt<60))
                {
                    if((!one_tm_blr_htng_snd_flg)AND(below_hystr_temp_cnfrm>=20))
                    {
                        if(!espresso_heater_on_flg)
                        ESPRESSO_HEATER_ON,es_htr_err_cnt_flg=SET,first_es_blr_temp_flag=SET;
                        if(init_flag)
                        {
                            es_blr_htng_snd_flg=one_tm_blr_htng_snd_flg=SET;
                            one_tm_es_blr_htng_cmplt_snd_flg=CLEAR_1;
                        }
                        else
                        {
                            if(es_ctemp<=drnk_genral_set[es_min_op_temp])
                            {
                                if((process_initiated_flag)OR(secondary_outlet_process_init_flag))
                                {
                                    if(multicup_start_flag)
                                    {
                                        if(drnk_genral_set[interrupt_multicup])
                                            snd_err_end_of_cup_es_blr=SET;
                                        else
                                            snd_err_aftr_dispns_es_blr=SET;
                                    }
                                    else
                                        snd_err_aftr_dispns_es_blr=SET;

                                }
                                else if(!snd_err_aftr_dispns_es_blr)
                                    es_blr_htng_snd_flg=one_tm_blr_htng_snd_flg=SET;
                            }
                        }
                    }
                }
                else if(es_htr_err_cnt>=60)
                {
                    es_blr_heat_cmplt_flg=SET;
                    es_blr_rch_tm_err_snd_flg=es_blr_heat_cmplt_flg=Machine_err_flag=SET;
                    ALL_OUT_OFF;
                    es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=CLEAR_1;
                    es_htr_err_cnt=count_es_temp_to_temp=back_up_es_temp=es_ctemp=0;
                    one_tm_es_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
                }
            }
        }
        else
        {
            if(espresso_heater_on_flg)
            {
                es_blr_heat_cmplt_flg=SET;
    //            if((es_ctemp>=125)AND(es_htr_snsr_err_cnfrm_dly>50))        //5 sec for confirmation
    //                es_htr_snsr_err_snd_flg=es_blr_heat_cmplt_flg=Machine_err_flag=SET,ALL_OUT_OFF;

                if(!emt_blr_seq_strt_flg)
                ESPRESSO_HEATER_OFF;
            }
            es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=CLEAR_1;
            es_htr_err_cnt=count_es_temp_to_temp=0;
            if(!emt_blr_seq_strt_flg)
            back_up_es_temp=es_ctemp=0;
            one_tm_es_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
        }
    }
    else
    {
        if(es_sensr_err_confm>50)      //5sec delay
        {
            es_blr_heat_cmplt_flg=SET;
            es_blr_rch_tm_err_snd_flg=es_blr_heat_cmplt_flg=Machine_err_flag=SET;
            ALL_OUT_OFF;
            es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=CLEAR_1;
            es_htr_err_cnt=count_es_temp_to_temp=back_up_es_temp=es_ctemp=0;
            one_tm_es_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_es_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
        }
    }
}
