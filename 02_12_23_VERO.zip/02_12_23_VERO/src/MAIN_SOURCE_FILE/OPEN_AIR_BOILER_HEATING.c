/*
 * OPEN_AIR_BOILER_HEATING.c
 *
 *  Created on: 02-Jan-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define OPEN_AIR_SERIESRESISTOR      5100
//#define OPEN_AIR_THERMISTORNOMINAL   12000//12500 //10k
//#define OP_BETA_VAL                  3977
#define OPEN_AIR_TEMPERATURENOMINAL  25

int roundNo1(float num);
void air_boiler_check_temperature();
void open_air_boiler_heating();

int roundNo1(float num1)
{
    return num1 < 0 ? num1 - 0.5 : num1 + 0.5;
}

void air_boiler_check_temperature()
{
    float opn_ar_blr_adc_vol_val,opn_ar_blr_temp_value,opn_ar_blr_ad_result1;
//    drnk_genral_set[temp_snsr_resistnce]=12000;
//    drnk_genral_set[temp_snsr_beta_val]=3740;//3440;
    drnk_genral_set[opn_blr_deg_err_tol]=3;
    if(read_flg_open_air_boiler)
    {
        read_flg_open_air_boiler=0;
        ADC_INTERRUPT.p_api->read(ADC_INTERRUPT.p_ctrl,ADC_REG_CHANNEL_2,&open_ar_ad_result);

        open_ar_acc_temp[ar_m++]=open_ar_ad_result;
        if(ar_m>=20)
        {
            ar_m=0;
            open_ar_acc_temp[2]=(open_ar_acc_temp[0]+open_ar_acc_temp[1]+open_ar_acc_temp[2]+open_ar_acc_temp[3]+open_ar_acc_temp[4]+open_ar_acc_temp[5]
                +open_ar_acc_temp[6]+open_ar_acc_temp[7]+open_ar_acc_temp[8]+open_ar_acc_temp[9]+open_ar_acc_temp[10]+open_ar_acc_temp[11]
                +open_ar_acc_temp[12]+open_ar_acc_temp[13]+open_ar_acc_temp[14]+open_ar_acc_temp[15]+open_ar_acc_temp[16]+open_ar_acc_temp[17]
                +open_ar_acc_temp[18]+open_ar_acc_temp[19])/20;
            opn_ar_blr_ad_result1  = open_ar_acc_temp[2];
            opn_ar_blr_adc_vol_val = 1023 / opn_ar_blr_ad_result1 - 1;
            opn_ar_blr_adc_vol_val = OPEN_AIR_SERIESRESISTOR / opn_ar_blr_adc_vol_val;
            opn_ar_blr_temp_value  = opn_ar_blr_adc_vol_val / drnk_genral_set[temp_snsr_resistnce];     // (R/Ro)
            opn_ar_blr_temp_value  = log(opn_ar_blr_temp_value);                  // ln(R/Ro)
            opn_ar_blr_temp_value  /= drnk_genral_set[temp_snsr_beta_val];                     // 1/B * ln(R/Ro)
            opn_ar_blr_temp_value  += 1.0 / (OPEN_AIR_TEMPERATURENOMINAL + 273.15); // + (1/To)
            opn_ar_blr_temp_value  = 1.0 / opn_ar_blr_temp_value;                 // Invert
            opn_ar_blr_temp_value  -= 273.15;
            opn_ar_blr_temp_value  = roundNo1(opn_ar_blr_temp_value);
            ar_ctemp=(unsigned char)opn_ar_blr_temp_value;
            ar_ctemp+=drnk_genral_set[opn_blr_deg_err_tol];
            ar_ctemp_value_get=SET;
//        ar_ctemp=80;

            if(drnk_genral_set[htr_temp_temp_err_en]?count_ar_temp_to_temp<drnk_genral_set[htr_temp_temp_sec]:1)
            {
                if((((back_up_ar_ctemp!=ar_ctemp)AND(ar_htr_tmp_chng_cnfrm>4))OR(first_ar_blr_temp_flag))AND(air_boiler_heater_on_flg))
                {
                    ar_htr_tmp_chng_cnfrm=0;
                    first_ar_blr_temp_flag=CLEAR_1;
                    back_up_ar_ctemp=ar_ctemp;
                    count_ar_temp_to_temp=0;
                    if(one_tm_opn_blr_htng_snd_flg)
                        open_blr_htng_snd_flg=SET;
                    else if(opn_blr_htr_ft_strt_flg)
                        opn_blr_htr_ft_tmp_snd_flg=SET;
                    else if(sensr_sts_req_flg)
                        send_sensor_status_flag=SET;
                }
                else if(!air_boiler_heater_on_flg)
                    count_ar_temp_to_temp=0;
            }
            else
            {
                opn_blr_heat_cmplt_flg=SET;
                open_blr_rch_tm_err_snd_flg=opn_blr_heat_cmplt_flg=Machine_err_flag=SET;
                OPEN_AIR_BLR_HTR_OFF;
                open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
                open_blr_htr_err_cnt=count_ar_temp_to_temp=back_up_ar_ctemp=ar_ctemp=0;
                one_tm_open_blr_htng_cmplt_snd_flg=CLEAR_1;
            }
        }
    }
}

void open_air_boiler_heating()
{
    if(open_ar_ad_result<1000)
    {
        if((init_flag)AND(!entered_fctry_tst_flg)?!drip_lvl_chk_flag:!opn_blr_sys_test_initated_flg)
        {
            if(!espresso_heater_on_flg)
            {
                if((ar_ctemp>=108)AND(opn_htr_snsr_err_cnfrm_dly>50))   //5sec
                {
                    opn_blr_heat_cmplt_flg=SET;
                    open_blr_htr_snsr_err_snd_flg=opn_blr_heat_cmplt_flg=Machine_err_flag=SET;
                    ALL_OUT_OFF;
                    open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
                    open_blr_htr_err_cnt=count_ar_temp_to_temp=back_up_ar_ctemp=ar_ctemp=0;
                    one_tm_open_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;
                }
                else if(((init_flag)AND(ar_ctemp>=drnk_genral_set[op_set_temp]))OR((!init_flag)AND(air_boiler_heater_on_flg)AND(ar_ctemp>drnk_genral_set[min_op_temp])))
                {
                    if((ar_ctemp>=drnk_genral_set[op_set_temp])AND(opn_reach_set_temp_cnfrm>=10))
                    {
                        if((air_boiler_heater_on_flg)AND(open_blr_htr_err_cnt_flg))
                            OPEN_AIR_BLR_HTR_OFF;
                        opn_blr_heat_cmplt_flg=(init_flag)AND(!entered_fctry_tst_flg)?(one_tm_open_blr_htng_cmplt_snd_flg=SET,one_tm_opn_blr_htng_snd_flg=CLEAR_1,(open_blr_htr_err_cnt_flg?SET:CLEAR_1)):CLEAR_1;      //init time error will cleared till reach set temp
                        open_blr_htr_err_cnt_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;
                    }
                    else if((!init_flag)AND(ar_ctemp>drnk_genral_set[min_op_temp])AND(one_tm_opn_blr_htng_snd_flg))          //Run time error will be cleared when reach min temperature
                        opn_blr_heat_cmplt_flg=SET,one_tm_opn_blr_htng_snd_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;

//                    else if(ar_ctemp<=drnk_genral_set[min_op_temp])
//                    {
//                        if((snd_err_aftr_dispns_opn_blr)AND(!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
//                        {
//                            open_blr_htng_snd_flg=one_tm_opn_blr_htng_snd_flg=SET;
//                            snd_err_aftr_dispns_opn_blr=CLEAR_1;
//                        }
//                    }
                }
                else
                {
                    if((init_flag?ar_ctemp<drnk_genral_set[op_set_temp]:ar_ctemp<(drnk_genral_set[op_set_temp]-drnk_genral_set[max_temp_vari]))AND(open_blr_htr_err_cnt<60))
                    {
                        if((!one_tm_opn_blr_htng_snd_flg)AND(opn_below_hystr_temp_cnfrm>=20))
                        {
                            if(!air_boiler_heater_on_flg)
                                OPEN_AIR_BLR_HTR_ON,open_blr_htr_err_cnt_flg=first_ar_blr_temp_flag=SET;

                            if((init_flag)AND(!entered_fctry_tst_flg))
                            {
                                open_blr_htng_snd_flg=one_tm_opn_blr_htng_snd_flg=SET;
                                one_tm_open_blr_htng_cmplt_snd_flg=CLEAR_1;
                            }
                            else
                            {
                                if(ar_ctemp<=drnk_genral_set[min_op_temp])
                                {
                                    if((process_initiated_flag)OR(secondary_outlet_process_init_flag))
                                    {
                                        if(multicup_start_flag)
                                        {
                                            if(drnk_genral_set[interrupt_multicup])
                                                snd_err_end_of_cup_opn_blr=SET;
                                            else
                                                snd_err_aftr_dispns_opn_blr=SET;
                                        }
                                        else
                                            snd_err_aftr_dispns_opn_blr=SET;        //it will clear after dispense

                                    }
                                    else if(!snd_err_aftr_dispns_opn_blr)
                                        open_blr_htng_snd_flg=one_tm_opn_blr_htng_snd_flg=SET;
                                }
                            }
                        }
                    }
                    else if(open_blr_htr_err_cnt>=120)
                    {
                        open_blr_rch_tm_err_snd_flg=opn_blr_heat_cmplt_flg=Machine_err_flag=SET;
                        ALL_OUT_OFF;
                        open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
                        open_blr_htr_err_cnt=count_ar_temp_to_temp=back_up_ar_ctemp=ar_ctemp=0;
                        one_tm_open_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;
                    }

                }
            }

            else
            {
                if(air_boiler_heater_on_flg)
                {
                    open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=CLEAR_1;
                    OPEN_AIR_BLR_HTR_OFF;
                }
            }
        }
        else if(!block_for_opn_blr_tst)
        {
            if(air_boiler_heater_on_flg)
            {
                opn_blr_heat_cmplt_flg=SET;
                OPEN_AIR_BLR_HTR_OFF;
            }
            open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
            open_blr_htr_err_cnt=count_ar_temp_to_temp=back_up_ar_ctemp=ar_ctemp=0;
            one_tm_open_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;
            block_for_opn_blr_tst=SET;
        }
    }
    else
    {
        if(opn_blr_snsr_err_confrm>50)  //5 sec
        {
            open_blr_rch_tm_err_snd_flg=opn_blr_heat_cmplt_flg=Machine_err_flag=SET;
            ALL_OUT_OFF;
            open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
            open_blr_htr_err_cnt=count_ar_temp_to_temp=back_up_ar_ctemp=ar_ctemp=0;
            one_tm_open_blr_htng_cmplt_snd_flg=snd_err_end_of_cup_opn_blr=snd_err_aftr_dispns_opn_blr=CLEAR_1;
        }
    }
}
