/*
 * TEST_IOS.c
 *
 *  Created on: 24-Jul-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"

void test_switches();

void test_switches()
{
    //switch 1
    if(!ES_BREW_POS)
        MIXER_MOTOR1_ON;
    else
        MIXER_MOTOR1_OFF;

    //switch 2
    if(!ES_FILL_POS)
        MIXER_MOTOR2_ON;
    else
        MIXER_MOTOR2_OFF;

    //switch 3
    if(!FB_BRWR_REST_SW)
        MIXER_MOTOR3_ON;
    else
        MIXER_MOTOR3_OFF;

    //switch 4
    if(!ES_BREWER_PLACED_SW)
        MIXER_MOTOR4_ON;
    else
        MIXER_MOTOR4_OFF;

    //switch 5
    if(!COFFEE_DOSER_SW)
        MIXER_MOTOR5_ON;
    else
        MIXER_MOTOR5_OFF;

    //switch 6
    if(!AIR_BREAK_MIN)
        TEA_BREW_MTR_ON;
    else
        TEA_BREW_MTR_OFF;

    //switch 7
    if(!AIR_BREAK_MAX)
        PRIMIX_MOTOR1_ON;
    else
        PRIMIX_MOTOR1_OFF;

    //switch 8
    if(!WASTE_BIN_PRSNT_SW)
        PRIMIX_MOTOR2_ON;
    else
        PRIMIX_MOTOR2_OFF;

    //switch 9
    if(!TRASH_BIN_FULL_SW)
        PRIMIX_MOTOR3_ON;
    else
        PRIMIX_MOTOR3_OFF;

    //switch 10
    if(!FILTER_PAPER_SW)
        PRIMIX_MOTOR4_ON;
    else
        PRIMIX_MOTOR4_OFF;

    //switch 11
    if(!JUG_TRAY_SW1)
        PRIMIX_MOTOR5_ON;
    else
        PRIMIX_MOTOR5_OFF;

    //switch 12
    if(!JUG_TRAY_SW2)
        PRIMIX_MOTOR6_ON;
    else
        PRIMIX_MOTOR6_OFF;
}

