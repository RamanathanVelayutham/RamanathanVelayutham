/*
 * MDB_UART.c
 *
 *  Created on: 04-Aug-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/MDB_HEADER_FILE/MDB_XVARIABLES.h"
#include "../MAIN_HEADER_FILE/MDB_HEADER_FILE/MDB_CMNDS.h"


void mdb_reader_timer();
void mdb_queue();
void mdb_protocol();

void mdb_queue()
{
    //static __boolean bill_val_en_flag;
    drnk_genral_set[cash_ls_dvc]=1;
    drnk_genral_set[bill_val]=1;
    drnk_genral_set[coin_acc]=1;
    mdb.que=mdb.curent_step=0;
    mdb.step=START_MDB;

    mdb.queue[mdb.que++]=START_MDB;


    if(drnk_genral_set[cash_ls_dvc]==1)
    {
        mdb.queue[mdb.que++]=CASHLESS_RESET;
        mdb.queue[mdb.que++]=CASHLESS_SETUP;
        mdb.queue[mdb.que++]=CASHLESS_MAX_MIN_PRICE;
        mdb.queue[mdb.que++]=CASHLESS_READER_EN;
    }
    if((drnk_genral_set[bill_val]==1))
    {
        if(!mdb.bill_val_en_flag)
        mdb.bill_val_en_flag=SET;
        mdb.queue[mdb.que++]=BV_RESET;
        mdb.queue[mdb.que++]=BV_SETUP;
        mdb.queue[mdb.que++]=BV_TYPE;
    }
    else if(mdb.bill_val_en_flag)
    mdb.queue[mdb.que++]=BV_TYPE_DISABLE,mdb.bill_val_en_flag=0;
    if(drnk_genral_set[coin_acc]==1)
    {
        mdb.queue[mdb.que++]=CC_RESET;
        mdb.queue[mdb.que++]=CC_SETUP;
        mdb.queue[mdb.que++]=CC_COIN_TYPE;
    }

    if(drnk_genral_set[cash_ls_dvc]==1)
    mdb.queue[mdb.que++]=CASHLESS_POLL;
    else if(drnk_genral_set[bill_val]==1)
    mdb.queue[mdb.que++]=BV_POLL;
    else if(drnk_genral_set[coin_acc]==1)
    mdb.queue[mdb.que++]=CC_POLL;

    mdb.queue[mdb.que++]=START_MDB;

}

void mdb_protocol()
{
    static unsigned char poll_count=0;
    unsigned char a,b=0,type_of_bill=0;
    unsigned short card_deduct_amt=0;
    //float deducted_amt=0;

    switch(mdb.step)
    {
        case START_MDB:
                    mdb.step=MD_NXT_STEP;
            break;
        case MD_NXT_STEP:
                    mdb.step= mdb.queue[++mdb.curent_step];
            break;
        case CASHLESS_RESET:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CASHLESS_RESET_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CASHLESS_SETUP:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[8]&0x100)==0x100))
                {
                    mdb.decimal_pont=(unsigned char)mdb_rcvd_buff[5];
                    mdb.card_dec_point=(unsigned short)pow(10,mdb.decimal_pont);
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CASHLESS_SETUP_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CASHLESS_MAX_MIN_PRICE:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CASLESS_MAX_MIN_PRICE_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CASHLESS_READER_EN:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                READER_EN_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CASHLESS_POLL:
            if(mdb.resend_timer<=0)
            {
                if(mdb.one_time_send_flg)
                {
                    if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==5))
                    {
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb.resend_timer=0,mdb.retry_cnt=0;
                        mdb.step= mdb.queue[++mdb.curent_step];
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    }
                    else if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==0X100))
                    {
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb.resend_timer=0,mdb.retry_cnt=0;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    }
                    else if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==3))
                    {
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb.resend_timer=0,mdb.retry_cnt=0;

                        mdb.card_avl_amt=mdb_rcvd_buff[1]<<8;
                        mdb.card_avl_amt|=mdb_rcvd_buff[2];
                        //mdb.credit_amount=mdb.card_avl_amt;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));

                        mdb_no_of_bytes=0;
                        ACK_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        if((payment_st_flg)AND(mdb.card_avl_amt>0))
                        {
                            mdb.que=mdb.curent_step=0;
                            mdb.step=CASHLESS_VEND_REQ;
                            mdb.queue[mdb.que++]=CASHLESS_VEND_REQ;
                            mdb.queue[mdb.que++]=CASHLESS_VEND_SS;
                            mdb.queue[mdb.que++]=CASHLESS_SESSION_COM;
                            mdb.queue[mdb.que++]=CASHLESS_POLL;
                            mdb.queue[mdb.que++]=MDB_END;
//                            blk_low_credit_flg=SET;
                        }
//                        else if((mdb.card_avl_amt>0)AND(!credit_amt_one_time_snd_flg)AND(!_process.flag))
//                        {
//                            credit_amt_one_time_snd_flg=SET;
//                            credit_amt_snd_flg=SET;
//                        }
//                        else if((credit_amt_one_time_snd_flg)AND(mdb.card_avl_amt<=0))
//                        {
//                            credit_amt_one_time_snd_flg=CLEAR_1;
//                            if(mdb.credit_amount>0)
//                            card_crdit_amt_snd_flg=SET;
//                            else
//                            credit_amt_snd_flg=SET;
//                        }
                        else
                        {
                            mdb.que=mdb.curent_step=0;
                            if(drnk_genral_set[bill_val]==1)
                            {
                                mdb.step=BV_POLL;
                                mdb.queue[mdb.que++]=BV_POLL;
                                mdb.queue[mdb.que++]=MDB_END;
                            }
                            else if(drnk_genral_set[coin_acc]==1)
                            {
                                mdb.step=CC_POLL;
                                mdb.queue[mdb.que++]=CC_POLL;
                                mdb.queue[mdb.que++]=MDB_END;
                            }
                        }
                    }
                    else if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]==0)AND(mdb_rcvd_buff[1]==0X100)))
                    {
                        mdb.retry_cnt=0,mdb.resend_flg=CLEAR_1;
                        mdb.one_time_send_flg=0,mdb.data_rcvd_flg=0;
                        mdb_queue();
                    }
                    else if(mdb.data_rcvd_flg)
                    {
                        mdb.retry_cnt=0,mdb.resend_flg=CLEAR_1;
                        mdb.one_time_send_flg=0,mdb.data_rcvd_flg=0;
                    }
                    else if((mdb.resend_timer<=0))
                    {
                        if(++mdb.retry_cnt>10)
                        {
//                            smart_card_err_flg=SET;
                            mdb.chk_device_flg=SET;
                            mdb_err_fun();
                        }
                        else
                        {
                            mdb.one_time_send_flg=CLEAR_1;
                            mdb.data_rcvd_flg=0;
                        }
                    }
                }
                else
                {
                    mdb_no_of_bytes=0;
                    mdb.one_time_send_flg=mdb.resend_flg=SET;
                    CASHLESS_POLL_CMD;
                    mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                    mdb.resend_timer=100;
                }
            }
            break;

        case CASHLESS_VEND_REQ:
            //if(mdb.resend_timer<=0)
            {
                if(mdb.one_time_send_flg)
                {
                    if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==3))
                    {
                        mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb_no_of_bytes=0,mdb.retry_cnt=0;
                        ACK_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        //for(a=0;a<1000;a++);
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.resend_timer=0,mdb_no_of_bytes=0;
                        CASHLESS_POLL_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        mdb.resend_timer=100;
                        if(++poll_count>=2)
                        {
                            mdb.one_time_send_flg=CLEAR_1;
                        }

                    }
                    else if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==5))
                    {
                        //mdb.dispense_flg=0;

                        //card_credit_amt=drink_price;

//                        drink_dispense_cfmd_flg=SET,low_credit_snd_flg=0,blk_low_credit_flg=0;
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb.resend_timer=0,mdb.retry_cnt=0;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));

                        mdb_no_of_bytes=0,card_deduct_amt=0;
                        ACK_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.resend_timer=100;
                        mdb.step= mdb.queue[++mdb.curent_step];
                    }
                    else if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==0x100)/*OR(mdb_rcvd_buff[0]==6)OR(mdb_rcvd_buff[0]==7))*/)
                    {
                        mdb_no_of_bytes=0,mdb.data_rcvd_flg=0;
                        mdb.resend_timer=mdb.retry_cnt=0;
                        CASHLESS_POLL_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        mdb.resend_timer=100;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    }
                    else if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]==6)OR(mdb_rcvd_buff[0]==7)OR(mdb_rcvd_buff[0]==8)))
                    {
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
//                        blk_low_credit_flg=0;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.resend_timer=mdb.retry_cnt=0;
                        //mdb.step=CASHLESS_POLL;
                        mdb.step=CASHLESS_SESSION_COM;
//                        low_credit_snd_flg=SET;
                    }
                    else if((mdb.resend_timer<=0))
                    {
                        if(++mdb.retry_cnt>10)
                        {
                            mdb_no_of_bytes=0,mdb.data_rcvd_flg=0;
                            mdb.resend_timer=mdb.retry_cnt=0;
                            //mdb.chk_device_flg=SET;
                            //mdb_err_fun();
                            mdb_queue();
                        }
                        else
                        {
                            mdb.data_rcvd_flg=0;
                            mdb.one_time_send_flg=CLEAR_1;
                            //mdb.step=CASHLESS_RESET;
                        }
                    }
                }
                else
                {

                    if(mdb.credit_amount>0)
                    {

//                      mdb.credit_amount= (unsigned short)((mdb.credit_amount)*mdb.card_dec_point);
//                      mdb.drink_price= (unsigned short)((mdb.drink_price)*mdb.card_dec_point);
                        card_deduct_amt=(unsigned short)((mdb.drink_price*mdb.card_dec_point)-(mdb.credit_amount*mdb.card_dec_point));
                    }
                    else
                    {
                        //deducted_amt=mdb.drink_price;
                        card_deduct_amt= (unsigned short)((mdb.drink_price)*mdb.card_dec_point);
                    }

                    mdb_no_of_bytes=0,poll_count=0;
                    mdb.one_time_send_flg=mdb.resend_flg=SET;
                    //VEND_REQ_CMD;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x13;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=1;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0x00;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=(unsigned char)((card_deduct_amt>>8)&(0x00ff));
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=(unsigned char)(card_deduct_amt&0x00ff);
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0xff;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0xff;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_uart_send_buff[mdb_no_of_bytes++]=(unsigned char)(mdb_uart_send_buff[0]+mdb_uart_send_buff[2]+mdb_uart_send_buff[4]+mdb_uart_send_buff[6]+  mdb_uart_send_buff[8]+mdb_uart_send_buff[10]);
                    mdb_uart_send_buff[mdb_no_of_bytes++]=0;
                    mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                    mdb.resend_timer=100;
                }
            }
            break;

        case CASHLESS_VEND_SS:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        //mdb_queue();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                        mdb.data_rcvd_flg=0;
                        //mdb.step=CASHLESS_RESET;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                VEND_SUCESS_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CASHLESS_SESSION_COM:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==0x100))
                {
                    mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=mdb.retry_cnt=0;
                    //mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    mdb_no_of_bytes=0;
                    CASHLESS_POLL_CMD;
                    mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                    mdb.resend_timer=100;
                }
                else if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[0]==7))
                {
                    //payment_st_flg=0,insert_tkn_coin_snd_flg=0;       //Commented by Ragesh B
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    mdb.resend_timer=mdb.retry_cnt=0;
                    mdb.step=CASHLESS_POLL;
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
//                        smart_card_err_flg=SET;
                        mdb.chk_device_flg=SET;
                        //mdb_queue();
                    }
                    else
                    {
                        mdb.data_rcvd_flg=0;
                        mdb.one_time_send_flg=CLEAR_1;
                        //mdb.step=CASHLESS_RESET;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                SESSION_COM_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;

        case BV_RESET:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>5)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else if(mdb.resend_timer<=0)
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                BIV_RESET_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case BV_SETUP:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND(mdb_rcvd_buff[27]&0x100==0x100))
                {
                    for(a=0,b=11;b<27;b++,a++)
                    mdb.bill_type_value[a]=(unsigned char)mdb_rcvd_buff[b];

                    mdb.bill_scale_factor=mdb_rcvd_buff[3];
                    mdb.bill_scale_factor=(mdb.bill_scale_factor<<8)|mdb_rcvd_buff[4];

                    mdb.note_dec_point=mdb_rcvd_buff[5];
                    mdb.note_dec_point=(unsigned short)pow(10,mdb.note_dec_point);

                    for(a=0;a<20;a++);
                    mdb_no_of_bytes=0;
                    ACK_CMD;
                    mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                    for(a=0;a<20;a++);

                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>5)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                BIV_SETUP_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
            case BV_TYPE:
                if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                BIV_TYPE_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
                break;

        case BV_TYPE_DISABLE:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=mdb.data_rcvd_flg=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                BIV_TYP_DIS_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;

        case BV_ESCROW_BILL_IN:
            if(mdb.one_time_send_flg)
            {
                if(mdb.data_rcvd_flg)
                {
                    if((mdb_rcvd_buff[0]&0x100)==0x100)
                    mdb.step=MD_NXT_STEP,mdb.one_time_send_flg=mdb.resend_timer=0;//mdb.poll_until_stack_flg=CLEAR;
                    else
                    mdb.step=MD_NXT_STEP,mdb.one_time_send_flg=mdb.resend_timer=0;//mdb.poll_until_stack_flg=CLEAR;
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                    mdb.data_rcvd_flg=0;
                    mdb.BV_pol_timer=25;
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }

            }
            else if(mdb.BV_pol_timer<=0)
            {
                mdb_no_of_bytes=0;
                BIV_ESCROW_BILL_IN;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.one_time_send_flg=SET,mdb.resend_timer=200;
            }
        break;
        case BV_ESCROW_BILL_OUT:
            if(mdb.one_time_send_flg)
            {
                if(mdb.data_rcvd_flg)
                {
                    if((mdb_rcvd_buff[0]&0X100)==0x100)
                    {
                        mdb.step=MD_NXT_STEP,mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.BV_pol_timer=25;
                    }
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }

            }
            else if(mdb.BV_pol_timer<=0)
            {
                mdb_no_of_bytes=0;
                BIV_ESCROW_BILL_OUT;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.one_time_send_flg=SET,mdb.resend_timer=200;
            }
        break;

        case BV_STACKER:
            if(mdb.one_time_send_flg)
            {
                if(mdb.data_rcvd_flg)
                {
                    if((mdb_rcvd_buff[2]&0X100)==0x100)
                    {
                        mdb.step=MD_NXT_STEP,mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        if(mdb_rcvd_buff[0]&0X080==0x80)
                        mdb.b_status=BVV_STACKER;
                        switch(mdb.b_status)
                        {
                            case BVV_STACKER:
                                for(a=0;a<20;a++);
                                mdb.b_status=FAIL_BVV;
                                mdb.b_status=mdb.que=mdb.curent_step=mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.BV_pol_timer=mdb.resend_timer=0;
                                mdb.step=BV_TYPE_DISABLE;
                                mdb.queue[mdb.que++]=BV_TYPE_DISABLE;
                                mdb.queue[mdb.que++]=BV_POLL;
                                break;
                            default:
                                break;
                        }
                    }
                }

            }
            else
            {
                mdb_no_of_bytes=0;
                BIV_STACKER;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.one_time_send_flg=SET,mdb.resend_timer=200;
            }
        break;


        case BV_POLL:
            if(mdb.one_time_send_flg)
            {
                if(mdb.data_rcvd_flg)
                {
                    switch(mdb.b_status)
                    {
                        case START_BVV:
                            break;
                        case BVV_ESCROW_IN:
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        for(a=0;a<20;a++);
                        mdb.b_status=FAIL_BVV;
                        mdb.que=mdb.curent_step=mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.BV_pol_timer=mdb.resend_timer=CLEAR_1;
                        mdb.step=BV_ESCROW_BILL_IN;
                        mdb.queue[mdb.que++]=BV_ESCROW_BILL_IN;
                        mdb.queue[mdb.que++]=BV_POLL;
                        break;
                          case BVV_ESCROW_OUT:
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        for(a=0;a<20;a++);
                        mdb.b_status=FAIL_BVV;
                        mdb.que=mdb.curent_step=mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.BV_pol_timer=mdb.resend_timer=0;
                        mdb.step=BV_ESCROW_BILL_OUT;
                        mdb.queue[mdb.que++]=BV_ESCROW_BILL_OUT;
                        //mdb.queue[mdb.que++]=BV_STACKER;
                        mdb.queue[mdb.que++]=BV_POLL;
                        break;

                        default:
                        if(mdb.mode_bit==1)//ACK
                        {
                            mdb.que=mdb.curent_step=0;

                            if(drnk_genral_set[coin_acc]==1)
                            {
                                mdb.step=CC_POLL;
                                mdb.queue[mdb.que++]=CC_POLL;
                                mdb.queue[mdb.que++]=MDB_END;
                            }
                            else if(drnk_genral_set[cash_ls_dvc]==1)
                            {
                                mdb.step=CASHLESS_POLL;
                                mdb.queue[mdb.que++]=CASHLESS_POLL;
                                mdb.queue[mdb.que++]=MDB_END;
                            }

                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;

                            mdb.BV_pol_timer=50;
                        }
                        else if((mdb_rcvd_buff[0])==5)//bill jammed
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<100;a++);
                            mdb.BV_pol_timer=50;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                            mdb.b_status=BVV_ESCROW_IN;
                        }
                        else if((mdb_rcvd_buff[0])==10)//Invalid escrow
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdb.counter=1;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            for(a=0;a<20;a++);
                            //mdp.BV__bill_jammed_flg=SET;                              home_screen();
                            mdb.BV_pol_timer=25;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                            //if(mdb.escrew_flg)
                            //mdb.b_status=BVV_ESCROW_IN,mdb.escrew_flg=0;
                        }
                        else if((mdb_rcvd_buff[0])==6)//validator was is reset condition
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=1;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            for(a=0;a<20;a++);
//                          mdb_no_of_bytes=0;
//                          BIV_0C_5E_CMD;
//                          R_UART2_Send(mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                        }
                        else if(((mdb_rcvd_buff[0])==9))//OR((mdb_rcvd_buff[0]&0xff)==6))//validator was disabled
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<20;a++);
                            mdb.que=mdb.curent_step=0;
                            mdb.BV_pol_timer=50;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;

                            mdb.que=mdb.curent_step=0;
                            mdb.step=START_MDB;
                            mdb.queue[mdb.que++]=START_MDB;
                            mdb.queue[mdb.que++]=BV_RESET;
                            mdb.queue[mdb.que++]=BV_SETUP;
                            mdb.queue[mdb.que++]=BV_TYPE;
                            mdb.queue[mdb.que++]=BV_POLL;
                            mdb.queue[mdb.que++]=START_MDB;
                        }
                        else if((mdb_rcvd_buff[0])==3)//busy
                        {
                            for(a=0;a<100;a++);
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=3;
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);

//                          mdb_no_of_bytes=0;
//                          BIV_POLL_CMD;
//                          R_UART2_Send(mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
//                          for(a=0;a<20;a++);
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;

                            //mdb.BV_busy_came_chk_for_bill_flg=SET;

                        }
                        else if((mdb_rcvd_buff[0]&0xf0)==0xc0)// DISABLED bill REJECTED
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=5;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<200;a++);
//                          mdb_no_of_bytes=0;
//                          BIV_TYPE_CMD;
//                          R_UART2_Send(mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;

                        }
                        else if((mdb_rcvd_buff[0]&0xf0)==0xB0)//bill TO recycler
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=6;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<20;a++);
//                          mdb_no_of_bytes=0;
//                          BIV_POLL_CMD;
//                          R_UART2_Send(mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                            //mdb.b_status=BVV_ESCROW_IN;

                        }
                        else if((mdb_rcvd_buff[0]&0xF0)==0xA0)// ALL TYPES OF bill returened
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=8;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<20;a++);
//                          mdb_no_of_bytes=0;
//                          BIV_POLL_CMD;
//                          R_UART2_Send(mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
                            mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_timer=CLEAR_1;
                            //mdp.BV_busy_came_chk_for_bill_flg=CLEAR
                        }
                        else if((mdb_rcvd_buff[0]&0xF0)==0x80)// ALL bill stacked
                        {
//                            crdit_time_counter=0;
                            type_of_bill=(unsigned char)(mdb_rcvd_buff[0]&0x0f);
                            mdb.total_note_amount=(unsigned long)(mdb.bill_type_value[type_of_bill]*mdb.bill_scale_factor);
                            mdb.total_note_amount/=mdb.note_dec_point;
                            //mdb.total_note_amount+=tmp_total_amt;

                            mdb.credit_amount+=mdb.total_note_amount;

                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            for(a=0;a<20;a++);
                            mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_timer=CLEAR_1;
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));

                            //note_coin_credit_amt_flg=SET;
//                            card_crdit_amt_snd_flg=SET;

                            //if(!mdb.escrew_flg)
                            //mdb.b_status=BVV_ESCROW_IN;
                            //else
                            //mdb.escrew_flg=0;
                            mdb.BV_pol_timer=50;

                        }
                        else if((mdb_rcvd_buff[0]&0xF0)==0x90)//bill received and position of bill
                        {
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            //for(a=0;a<100;a++);

                            mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_timer=CLEAR_1;
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));

                            mdb.b_status=BVV_ESCROW_OUT;//BVV_ESCROW_IN;

                            //mdb.escrew_flg=SET;
                            mdb.BV_pol_timer=50;
//
                        }
                        else if((mdb_rcvd_buff[0])==0x0b)
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            //mdp.counter=6;
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            for(a=0;a<50;a++);
                            mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                            mdb.BV_pol_timer=50;
                        }
                        else
                        {
                            memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                            for(a=0;a<100;a++);
                            mdb_no_of_bytes=0;
                            ACK_CMD;
                            mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                            mdb.BV_pol_timer=50;
                            mdb_no_of_bytes=mdb.data_rcvd_flg=0;
                            mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;
                            //mdb.BV_pol_timer=100;
                        }
                        break;
                    }
//                  //mdp.end_bit_received=0;
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        bill_val_err_flg=SET;
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }

            }
            else if(mdb.BV_pol_timer<=0)
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                BIV_POLL_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=200;
            }
            break;



        case CC_RESET:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND(mdb.mode_bit==1))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>5)
                    {
                        mdb.chk_device_flg=SET;
                        cc_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CC_RESET_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=300;
            }
            break;
        case CC_SETUP:
            if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[23]&0x100)==0x100))
                {
                    for(a=0,b=7;b<22;b++,a++)
                    mdb.cc_type_value[a]=(unsigned char)mdb_rcvd_buff[b];

                    mdb.cc_scale_factor=(unsigned char)mdb_rcvd_buff[3];

                    mdb.cc_dec_point=mdb_rcvd_buff[4];
                    mdb.cc_dec_point=(unsigned short)pow(10,mdb.cc_dec_point);

                    for(a=0;a<20;a++);
                    mdb_no_of_bytes=0;
                    ACK_CMD;
                    mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                    for(a=0;a<20;a++);

                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>5)
                    {
                        mdb.chk_device_flg=SET;
                        cc_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CC_SETP_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;
        case CC_COIN_TYPE:
                if(mdb.one_time_send_flg)
            {
                if((mdb.data_rcvd_flg)AND((mdb_rcvd_buff[0]&0x100)==0x100))
                {
                    mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                    mdb.resend_timer=0,mdb.retry_cnt=0;
                    mdb.step= mdb.queue[++mdb.curent_step];
                    memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        cc_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }
            }
            else
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CC_TYPE_ENABLE_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;

        case CC_POLL:

            if(mdb.one_time_send_flg)
            {
                if(mdb.data_rcvd_flg)
                {

                    if(mdb.mode_bit==1)
                    {
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.data_rcvd_flg=mdb.one_time_send_flg=mdb.resend_timer=CLEAR_1;

                        if(drnk_genral_set[cash_ls_dvc]==1)
                        {
                            mdb.step=CASHLESS_POLL;
                            mdb.queue[mdb.que++]=CASHLESS_POLL;
                            mdb.queue[mdb.que++]=MDB_END;
                        }
                        else if(drnk_genral_set[bill_val]==1)
                        {
                            mdb.step=BV_POLL;
                            mdb.queue[mdb.que++]=BV_POLL;
                            mdb.queue[mdb.que++]=MDB_END;
                        }
                        mdb.cc_interval_timer=50;

                    }
                    else if((mdb_rcvd_buff[0]&0x00f0)==0x40)
                    {
//                        crdit_time_counter=0;
                        type_of_bill=(unsigned char)(mdb_rcvd_buff[0]&0x0f);
                        mdb.cc_total_amount=(mdb.cc_type_value[type_of_bill]*mdb.cc_scale_factor);
                        mdb.cc_total_amount/=mdb.cc_dec_point;
                        //mdb.total_note_amount+=tmp_total_amt;

                        mdb.credit_amount+=mdb.cc_total_amount;

                        for(a=0;a<100;a++);
                        mdb_no_of_bytes=0;
                        ACK_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        //for(a=0;a<20;a++);
                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_timer=CLEAR_1;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));

                        //note_coin_credit_amt_flg=SET;
//                        card_crdit_amt_snd_flg=SET;
                        mdb.cc_interval_timer=50;
                    }
                    else
                    {
                        for(a=0;a<100;a++);
                        mdb_no_of_bytes=0;
                        ACK_CMD;
                        mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                        //for(a=0;a<20;a++);

                        mdb.one_time_send_flg=mdb.data_rcvd_flg=mdb.resend_flg=CLEAR_1;
                        mdb.resend_timer=0;
                        memset(mdb_rcvd_buff,0,sizeof(mdb_rcvd_buff));
                        mdb.cc_interval_timer=50;
                    }
                }
                else if((mdb.resend_timer<=0))
                {
                    if(++mdb.retry_cnt>10)
                    {
                        mdb.chk_device_flg=SET;
                        cc_err_flg=SET;
                        mdb_err_fun();
                    }
                    else
                    {
                        mdb.one_time_send_flg=CLEAR_1;
                    }
                }

            }
            else if(mdb.cc_interval_timer<=0)
            {
                mdb_no_of_bytes=0;
                mdb.one_time_send_flg=mdb.resend_flg=SET;
                CC_POLL_CMD;
                mdb_com.p_api->write(mdb_com.p_ctrl,mdb_uart_send_buff,mdb_no_of_bytes);
                mdb.resend_timer=100;
            }
            break;

        default:
            break;
    }
}


void mdb_reader_timer()
{
    static unsigned char _1ms_tmr;
    if(++_1ms_tmr>=40)
    {
        _1ms_tmr=0;
        if(mdb.resend_timer>0)
        mdb.resend_timer--;
        if(mdb.BV_pol_timer>0)
        mdb.BV_pol_timer--;
        if(mdb.cc_interval_timer>0)
        mdb.cc_interval_timer--;
        if(mdb_uart_err_clr_cnt>0)
        {
            mdb_uart_err_clr_cnt--;
            if(mdb_uart_err_clr_cnt<=0)
            mdb_buff=0;
        }
    }
}
