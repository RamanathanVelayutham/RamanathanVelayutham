/*
 * SWITCHES_SECTION.c
 *
 *  Created on: 20-Jan-2023
 *      Author: afila
 */
#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"

void sensors();
void drip_tray_level_pulse();
void drip_tray_confirm();
void clear_init_things();
void snsr_status_chck();

//unsigned char DRIP1_ON_TIME = 25, DRIP1_OFF_TIME =3;

void sensors()
{
    if(!entered_fctry_tst_flg)
    {
        if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
        {
            if((!filter_paper_present)AND(!one_time_fltr_ppr_err_snd_flg))        //not present
            {
                if(confrm_no_paper_dly>=4)      //confirm within 200 msec
                {
                    if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                    one_time_fltr_ppr_err_snd_flg=out_of_fltr_ppr_err_snd_flg=SET;
                    else if(!need_stop_drink_due_to_err_flg)
                        need_stop_drink_due_to_err_flg=SET;
                }
            }
            else if((one_time_fltr_ppr_err_snd_flg)AND(filter_paper_present))      //paper present
            {
                if(ppr_prsnt_cnfrm_dly>=4)
                {
                    one_time_fltr_ppr_err_snd_flg=CLEAR_1;
                    out_of_fltr_ppr_err_clr_snd_flg=SET;
                }
            }
            if((!process_initiated_flag)AND(!init_flag))
            {
                if((fb_home_pos_flg)AND(!one_time_fb_brwr_err_snd_flg))        //not in position
                {
                    if(confrm_brwr_not_in_pos_dly>=4)      //confirm within 200 msec
                        one_time_fb_brwr_err_snd_flg=fb_brwr_run_time_err_snd_flg=SET;
                }
                else if((one_time_fb_brwr_err_snd_flg)AND(!fb_home_pos_flg))       // in position
                {
                    if(confrm_brwr_in_pos_dly>=4)
                    {
                        one_time_fb_brwr_err_snd_flg=CLEAR_1;
                        fb_brwr_run_time_err_snd_clr_flg=SET;
                    }
                }
            }
            if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
            {
                if(waste_bin_full)
                {
                    if(cnfrm_wst_bin_empt_dly>=4)
                    {
                        if(one_time_wst_bin_ful_err_snd_flg)
                        {
                            if((waste_bin_placed_flg)AND(one_time_wst_bin_pop_snd_flg))
                            {
                                waste_bin_placed_flg=one_time_wst_bin_pop_snd_flg=one_time_wst_bin_ful_err_snd_flg=CLEAR_1;
                                wst_bin_full_err_clr_snd_flg=SET;

                            }
                            else if(!one_time_wst_bin_pop_snd_flg)
                            {
                                one_time_wst_bin_pop_snd_flg=SET;
                                waste_bin_pop_snd_flg=SET;
                            }
                        }
                    }
                }
                else if((!one_time_wst_bin_ful_err_snd_flg)AND(cnfrm_wst_bin_ful_dly>=4))
                {
                    if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                    {
                        one_time_wst_bin_ful_err_snd_flg=SET;
                        wst_bin_full_err_snd_flg=SET;
                    }
                    else if(!need_stop_drink_due_to_err_flg)
                        need_stop_drink_due_to_err_flg=SET;
                }

            }
        }
        if(espresso_machine_flag)
        {
            if((wast_bin_prsnt_sw)AND(!one_time_wst_bin_not_prsnt_err_snd_flg))        //not present
            {
                if(cnfrm_wst_bin_not_prsnt_dly>=4)      //confirm within 200 msec
                {
                    if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                    one_time_wst_bin_not_prsnt_err_snd_flg=wst_bin_not_prsnt_snd_flg=SET;
                    else if(!need_stop_drink_due_to_err_flg)
                        need_stop_drink_due_to_err_flg=SET;
                }
            }
            else if((one_time_wst_bin_not_prsnt_err_snd_flg)AND(!wast_bin_prsnt_sw))      //present
            {
                if(cnfrm_wst_bin_prsnt_dly>=4)
                {
                    one_time_wst_bin_not_prsnt_err_snd_flg=CLEAR_1;
                    wst_bin_prsnt_snd_flg=SET;
                }
            }
        }
    }
    else
    {
        one_time_fltr_ppr_err_snd_flg=one_time_fb_brwr_err_snd_flg=CLEAR_1;
        waste_bin_placed_flg=one_time_wst_bin_pop_snd_flg=one_time_wst_bin_ful_err_snd_flg=CLEAR_1;
        one_time_wst_bin_not_prsnt_err_snd_flg=CLEAR_1;
    }
}

void drip_tray_level_pulse()
{

    static unsigned char drip_lvl1_pulse_counter,DRIP1_ON_TIME,DRIP1_OFF_TIME;
    static bool drip_lvl1_pulse_on_flag;

    drip_lvl1_pulse_counter++;
    if(drip_lvl1_pulse_counter <= DRIP1_ON_TIME)
    {
        if(!drip_lvl1_pulse_on_flag)
        {
            drip_lvl1_pulse_on_flag = SET;
            DRIP_LVL1_PWM_ON;
        }
    }
    else if(drip_lvl1_pulse_counter<(DRIP1_ON_TIME+DRIP1_OFF_TIME))
    {
        if(drip_lvl1_pulse_on_flag)
        {
            drip_lvl1_pulse_on_flag = CLEAR_1;
            DRIP_LVL1_PWM_OFF;
        }
    }
    else
    drip_lvl1_pulse_counter = 0;

    DRIP1_ON_TIME = 43;
    DRIP1_OFF_TIME =3;
}

void drip_tray_confirm()
{
    //g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_02,&DRIP_LVL1);
    for(unsigned int i=0;i<500;i++)
    {
        g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_02,&DRIP_LVL1);
        if(!DRIP_LVL1)//if(!drip_level_flag)//STEAM_BOILER_WATER_LVL_IN=1
        {
            drip_lvl1_open_counter=0;
        }
        else
        {
            drip_lvl1_close_counter=0;
        }
    }
    if(!entered_fctry_tst_flg)
    {
        if(drip_lvl1_open_counter>20)
        {
            if(drip_lvl_chk_flag)
            {
                if(!sensr_sts_req_flg)
                {
                    if((drip_tray_placed_flg)AND(one_time_drip_try_plc_snd_flg))
                    {
                        drip_lvl_chk_flag=CLEAR_1;  // empty then only allow to the next process
                        one_time_drip_try_plc_snd_flg=drip_tray_placed_flg=CLEAR_1;
                        drip_tray_empty_send_flg=SET;
                        if(init_flag)
                        {
                            need_to_get_reinit_cnfrm_flg=SET;
                            clear_init_things();
                        }
                    }
                    else if(!one_time_drip_try_plc_snd_flg)
                        have_drip_tray_place_err_snd_flg=one_time_drip_try_plc_snd_flg=SET;  //  During initialization means, After sended this command. we need to clear all and after getting confirmation need to clear the reinit_flag

                }
                else
                    drip_lvl_chk_flag=CLEAR_1;
            }

        }
        else if(drip_lvl1_close_counter>20)
        {
            if(!drip_lvl_chk_flag)
            {
                if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag))
                {
                    drip_lvl_chk_flag=SET;  // if full, stop all the process during run time and initialization.
                    drip_tray_full_snd_flg=SET;
                }
                else if(!need_stop_drink_due_to_err_flg)
                    need_stop_drink_due_to_err_flg=SET;
            }
        }
    }
    else
    {
        drip_lvl_chk_flag=CLEAR_1;
        one_time_drip_try_plc_snd_flg=drip_tray_placed_flg=CLEAR_1;
    }
}

void snsr_status_chck()
{
    if(backup_opn_blr_min_levl!=blr_lvl1_wtr_flg)
        backup_opn_blr_min_levl=blr_lvl1_wtr_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    if(backup_opn_blr_max_levl!=blr_lvl2_wtr_flg)
        backup_opn_blr_max_levl=blr_lvl2_wtr_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    if(backup_opn_blr_htr_status!=air_boiler_heater_on_flg)
        backup_opn_blr_htr_status=air_boiler_heater_on_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    if(espresso_machine_flag)
    {
        if(backup_esp_blr_min_levl!=ar_brk_min_flg)
            backup_esp_blr_min_levl=ar_brk_min_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
        if(backup_esp_blr_max_levl!=ar_brk_max_flg)
            backup_esp_blr_max_levl=ar_brk_max_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
        if(backup_esp_blr_htr_status!=espresso_heater_on_flg)
            backup_esp_blr_htr_status=espresso_heater_on_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    }
    if(!instant_machine_flag)
    {
        if(backup_wst_bin_status!=wast_bin_prsnt_sw)
            backup_wst_bin_status=wast_bin_prsnt_sw,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
        if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
        {
            if(backup_wst_bin_lvl_status!=waste_bin_full)
                backup_wst_bin_lvl_status=waste_bin_full,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
            if(backup_fb_paper_status!=filter_paper_present)
                backup_fb_paper_status=filter_paper_present,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
        }
    }
    if(backup_fan_status!=fan_mtr_flg)
        backup_fan_status=fan_mtr_flg,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    if(backup_drip_lvl_status!=drip_lvl_chk_flag)
        backup_drip_lvl_status=drip_lvl_chk_flag,send_sensor_status_flag=first_time_sensor_read_flg?CLEAR_1:SET;
    first_time_sensor_read_flg=CLEAR_1;
}

void clear_init_things()
{
    ALL_OUT_OFF;
    if(!one_time_drip_try_plc_snd_flg)
    drip_lvl_chk_flag=one_time_drip_try_plc_snd_flg=CLEAR_1;        // drip tray

    one_time_fltr_ppr_err_snd_flg=one_time_fb_brwr_err_snd_flg=CLEAR_1; //filter paper
    waste_bin_placed_flg=one_time_wst_bin_pop_snd_flg=one_time_wst_bin_ful_err_snd_flg=CLEAR_1; //waste bin full
    one_time_wst_bin_not_prsnt_err_snd_flg=CLEAR_1;         //waste bin present

    init_brwr_alrdy_in_pos_flag=CLEAR_1;
    //Espresso Brewer

    drip_lvl_chk_flag=one_time_drip_try_plc_snd_flg=for_rnd_2_cycle=pos_cnfrm_flg=CLEAR_1;
    brwr_stpd_flg=fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=one_tme_brw_plc_err_snd=CLEAR_1;
    es_brwr_err_cnt_flg=brewr_en_or_dis=one_time_brwr_abrt_snd_flg=init_brwr_alrdy_in_pos_flag=need_to_get_reinit_cnfrm_flg=CLEAR_1;
    es_brwr_err_cnt=restart_init_with_brwr_fail=brw_to_fil_cnt=fill_to_brew_err_cnt=pos_id=0;

    //Fresh Brewer
    fb_brwr_err_cnt_flg=CLEAR_1;
    fb_brwr_err_cnt=0;

    //Air Break
    one_tm_cntr_plc_err_snd_flg=container_plcd_flg=need_clr_aftr_ar_fl_flg=CLEAR_1;
    ar_brk_min_cnt_flg=ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=CLEAR_1;
    start_es_boilr_fill_flg=one_tm_blr_fl_snd_flg=CLEAR_1;
    init_es_htr_strt_flg=init_air_break_only_flg=CLEAR_1;
    ar_brk_min_cnt=ar_brk_max_cnt=0;

    //Espresso boiler filling
    es_brwr_in_brw_pos_flg=es_boiler_fill_strt_flg=CLEAR_1;
    es_flw_cnt=es_brwr_flw_err_cnt=0;

    //Espresso boiler heating
    es_htr_err_cnt_flg=one_tm_blr_htng_snd_flg=one_tm_es_blr_htng_cmplt_snd_flg=first_es_blr_temp_flag=CLEAR_1;
    es_htr_err_cnt=count_es_temp_to_temp=0;
    one_tm_es_blr_htng_cmplt_snd_flg=CLEAR_1;

    //Open Air boiler Filling
    opn_blr_fil_strt_flg=opn_blr_min_cnt_flg=opn_blr_max_cnt_flg=need_clr_aftr_opn_blr_fl_flg=CLEAR_1;
    init_opn_brl_htr_start_flg=one_tm_open_blr_fl_snd_flg=CLEAR_1;
    opn_blr_max_cnt=opn_blr_min_cnt=0;

    //Open Air boiler heating
    open_blr_htr_err_cnt_flg=one_tm_opn_blr_htng_snd_flg=one_tm_open_blr_htng_cmplt_snd_flg=first_ar_blr_temp_flag=CLEAR_1;
    open_blr_htr_err_cnt=count_ar_temp_to_temp=0;
    one_tm_open_blr_htng_cmplt_snd_flg=CLEAR_1;
}
