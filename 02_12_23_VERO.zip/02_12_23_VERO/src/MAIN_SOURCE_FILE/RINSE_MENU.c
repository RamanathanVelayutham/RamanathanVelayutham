/*
 * RINSE_MENU.c
 *
 *  Created on: 04-Apr-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

/*
 * Based on the command we switch on the mixer.
 * if the rinsing all is given selected mixer will run as per the order.
 * and if the machine have fresh brewer or espresso brewer, we need to turn on that also.
 * cleaning process for espresso.
 * paper feeding  is for fresh brewer machines.
 * hot water and cold water also possible at both the individual or auto idle rinse.
 * if the ch 6 is set as 6, that is extra hot water.
 *
 */

void rinse_process();
void scndry_valv_rins();
void all_mixer_rinse();
void rinse_all();
void espresso_brewer_cleaning();
void fresh_brewer_movement();

void rinse_process()
{
    if((individual_rinse_start_flag)OR(start_rinse_from_all_mxr_flg)OR(initiate_espresso_brwr_rins_flg)OR(initiate_fb_brwr_rins_flg)OR(start_water_valve_flg))
    {
        if(rinse_value_get_flg)
        {
            switch(rinse_id)
            {
                case 1:             //mixer 1
                    if((ch_flags[1].solnd_prcs_cmplt)AND(ch_flags[1].whpr_prcs_cmplete))
                    {
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[1].solnd_prcs_cmplt=ch_flags[1].whpr_prcs_cmplete=rinse_id=0;
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                    }
                    else
                    {
                        solenoid_fun(1);
                        mixer_motor_fun(1);
                    }
                    break;
                case 2:             //mixer 2
                    if((ch_flags[2].solnd_prcs_cmplt)AND(ch_flags[2].whpr_prcs_cmplete))
                    {
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[2].solnd_prcs_cmplt=ch_flags[2].whpr_prcs_cmplete=rinse_id=0;
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                    }
                    else
                    {
                        solenoid_fun(2);
                        mixer_motor_fun(2);
                    }
                    break;
                case 3:             //mixer 3
                    if((ch_flags[3].solnd_prcs_cmplt)AND(ch_flags[3].whpr_prcs_cmplete))
                    {
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[3].solnd_prcs_cmplt=ch_flags[3].whpr_prcs_cmplete=rinse_id=0;
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                    }
                    else
                    {
                        solenoid_fun(3);
                        mixer_motor_fun(3);
                    }
                    break;
                case 4:             //mixer 4
                    if((ch_flags[4].solnd_prcs_cmplt)AND(ch_flags[4].whpr_prcs_cmplete))
                    {
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[4].solnd_prcs_cmplt=ch_flags[4].whpr_prcs_cmplete=rinse_id=0;
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                    }
                    else
                    {
                        solenoid_fun(4);
                        mixer_motor_fun(4);
                    }
                    break;
                case 5:             //mixer 5
                    if((ch_flags[5].solnd_prcs_cmplt)AND(ch_flags[5].whpr_prcs_cmplete))
                    {
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[5].solnd_prcs_cmplt=ch_flags[5].whpr_prcs_cmplete=rinse_id=0;
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                    }
                    else
                    {
                        solenoid_fun(5);
                        mixer_motor_fun(5);
                    }
                    break;
                case 6:             //EX hot water
                    if((ch_flags[6].solnd_prcs_cmplt)OR(cancel_initiate_flg))
                    {
                        if(cancel_initiate_flg)
                        {
                            cancel_initiate_flg=CLEAR_1;
                            ch_flags[6].one_time_sol_flag=ch_tmr[6].wtr_off_time=ch_process[6].wtr_on_off_cnt=0;
                            back_up[6].backup_wtr_on_time=back_up[6].backup_wtr_off_time=ch_tmr[6].wtr_on_time=0;
                            SOLENOID6_OFF;
                        }
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        ch_flags[6].solnd_prcs_cmplt=rinse_id=0;
                        start_water_valve_flg=CLEAR_1;
                    }
                    else
                        solenoid_fun(6);
                    break;
                case 7:             // hot water
                case 8:             // cold water
                    if((sndry_vlv_rns_prcs_complete_flg)OR(cancel_initiate_flg))
                    {
                        if(cancel_initiate_flg)
                        {
                            cancel_initiate_flg=CLEAR_1;
                            sncdry_vlv_on_flg=scndry_vlv_off_tmr=scndr_vlv_on_off_cnt=0;
                            backup_scndry_wtr_on_time=scndry_vlv_off_tmr=scndry_vlv_on_tmr=0;
                            HOT_WATER_OFF,COOLER_OFF;
                        }
                        indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                        rinse_value_get_flg=CLEAR_1;
                        sndry_vlv_rns_prcs_complete_flg=rinse_id=0;
                        start_water_valve_flg=CLEAR_1;
                    }
                    else
                        scndry_valv_rins();
                    break;
                case 9:                     //espresso brewer rinsing
                    switch(close_pos_rins_stp)
                    {
                        case 1:                         //move brewer to brew position
                            if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
                            {
                                if(es_brwr_mtr_flg)
                                ESPRESSO_BREWER_OFF;
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=2;             //brew position
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                                cycle_count=rnse_menu_set[esp_rns_set][cls_pos_cycl_cnt];
                                close_pos_rins_stp++;
                            }
                            else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
                            {
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=3;             //travelling
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                                ESPRESSO_BREWER_ON;
                            }
                            break;
                        case 2:             //rinse brewer
                            if(cycle_count>0)
                            {
                                if((es_rns_wtr_tmr<=0)AND(presure_pump_flg)AND(three_way_vlv_flg))
                                {
                                    PRESSURE_PUMP_OFF;
                                    THREE_WAY_VALVE_OFF;
                                    close_pos_rins_stp++;
                                }
                                else if((!presure_pump_flg)AND(!three_way_vlv_flg))
                                {
                                    PRESSURE_PUMP_ON;
                                    THREE_WAY_VALVE_ON;
                                    es_rns_wtr_tmr=rnse_menu_set[esp_rns_set][cls_pos_rns_wtr];
                                }
                            }
                            else
                                close_pos_rins_stp+=2;
                            break;
                        case 3:                             //pauze time
                            if((es_rns_pauz_tmr<=0)AND(es_paus_tm_flg))
                            {
                                es_paus_tm_flg=CLEAR_1;
                                cycle_count--;
                                close_pos_rins_stp--;
                            }
                            else if(!es_paus_tm_flg)
                            {
                                es_rns_pauz_tmr=rnse_menu_set[esp_rns_set][cls_pos_rns_pauz];
                                es_paus_tm_flg=SET;
                            }
                            break;
                        case 4:                             //back to fill position
                            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                            {
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=1;             //fill pos
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                                ESPRESSO_BREWER_OFF;
                                close_pos_rins_stp=rinse_id=0;
                                indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                                espresso_brwr_rnse_cmplet_flg=initiate_espresso_brwr_rins_flg?(initiate_espresso_brwr_rins_flg=CLEAR_1,SET):CLEAR_1;
                                rinse_value_get_flg=CLEAR_1;
                            }
                            else if(!es_brwr_mtr_flg)
                            {
                                ESPRESSO_BREWER_ON;
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=3;             //travelling
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                            }
                            break;
                    }
                    break;
                case 10:        //fresh brewer rinsing
                    switch(fb_rns_stp)
                    {
                        case 1:             //water pulse
                            if(ch_flags[1].solnd_prcs_cmplt)
                            {
                                ch_flags[1].solnd_prcs_cmplt=0;
                                fb_rns_stp++;
                            }
                            else
                                solenoid_fun(1);
                            break;
                        case 2:     //move to the position
                            if((fb_pos_move_tmr<=0)AND(fresh_brewer_mtr_flg))
                            {
                                FRESH_BREWER_OFF;
                                fb_rns_stp++;
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=4;             //Brewer stop
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                            }
                            else if(!fresh_brewer_mtr_flg)
                            {
                                FRESH_BREWER_ON;
                                fb_pos_move_tmr=rnse_menu_set[fb_rns_set][fb_pos_brwrstop];
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=3;             //travelling
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                            }
                            break;
                        case 3:     //wait on position brewer
                            if((fb_rns_wait_tmr<=0)AND(fb_rnse_wait_flg))
                            {
                                fb_rnse_wait_flg=CLEAR_1;
                                fb_rns_stp++;
                            }
                            else if(!fb_rnse_wait_flg)
                            {
                                fb_rnse_wait_flg=SET;
                                fb_rns_wait_tmr=rnse_menu_set[fb_rns_set][fb_brwrstop];
                            }
                            break;
                        case 4:
                            if((fb_rnse_drp_time<=0)AND(fb_rnse_drp_time_flg))
                            {
                                fb_rnse_drp_time_flg=CLEAR_1;
                                fb_rns_stp++;
                            }
                            else if(!fb_rnse_drp_time_flg)
                            {
                                fb_rnse_drp_time_flg=SET;
                                fb_rnse_drp_time=rnse_menu_set[fb_rns_set][fb_drip_time];
                            }
                            break;
                        case 5:
                            if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4))
                            {
                                FRESH_BREWER_OFF;
                                confrm_brwr_in_pos_dly=fb_rns_stp=rinse_id=0;
                                indvdl_rins_done_snd_flg=individual_rinse_start_flag?(individual_rinse_start_flag=CLEAR_1,SET):CLEAR_1;
                                fb_brwr_rnse_cmplet_flg=initiate_fb_brwr_rins_flg?(initiate_fb_brwr_rins_flg=CLEAR_1,SET):CLEAR_1;
                                rinse_value_get_flg=CLEAR_1;
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=5;             //rest position
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                            }
                            else if((fb_home_pos_flg)AND(!fresh_brewer_mtr_flg))
                            {
                                FRESH_BREWER_ON;
                                if(individual_rinse_start_flag)
                                {
                                    brwr_pos_id_for_rins=3;             //travelling
                                    brwr_pos_id_for_rins_snd_flg=SET;
                                }
                            }
                            break;
                    }
                    break;

                    default:
                        start_rinse_from_all_mxr_flg=CLEAR_1;
                        break;
            }
        }
        else
        {
            if((rinse_id>=1)AND(rinse_id<=6))
            {
                ch_process[rinse_id].wtr_time=rnse_menu_set[rinse_id][total_wtr_time];
                ch_process[rinse_id].wtr_puls_no=rnse_menu_set[rinse_id][no_of_pulz];
                ch_process[rinse_id].wtr_puls_time=rnse_menu_set[rinse_id][pulz_pauz_time];
                if((rinse_id>=1)AND(rinse_id<=5))
                {
                    ch_process[rinse_id].mxr_dly=rnse_menu_set[rinse_id][rns_mxr_dly_time];
                    ch_process[rinse_id].mxr_rpm=rnse_menu_set[rinse_id][rns_mxr_rpm];
                    ch_process[rinse_id].mxr_time=rnse_menu_set[rinse_id][rns_mxr_run_time];
                }
            }
            else if(rinse_id==9)
            {
                close_pos_rins_stp=1;
            }
            else if(rinse_id==10)
            {
                ch_process[1].wtr_time=rnse_menu_set[fb_rns_set][fb_total_wtr_time];
                ch_process[1].wtr_puls_no=rnse_menu_set[fb_rns_set][fb_no_of_pulz];
                ch_process[1].wtr_puls_time=rnse_menu_set[fb_rns_set][fb_pulz_pauz_time];
                fb_rns_stp=1;
            }
            rinse_value_get_flg=SET;
        }
    }
}

void scndry_valv_rins()
{
    if(!sndry_vlv_rns_prcs_complete_flg)
    {
        if(scndr_vlv_on_off_cnt>0)
        {
            if((scndry_vlv_off_tmr<=0)AND(!sncdry_vlv_on_flg))
            {
                switch(rinse_id)
                {
                    case 7:

                        if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                            PRESSURE_PUMP_ON;
                        HOT_WATER_ON;
                        break;
                    case 8:
                        COOLER_ON;
                        break;
                }
                sncdry_vlv_on_flg=SET;
                scndry_vlv_on_tmr=backup_scndry_wtr_on_time;
            }
            else if((scndry_vlv_on_tmr<=0)AND(sncdry_vlv_on_flg))
            {
                switch(rinse_id)
                {
                    case 7:
                        if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                            PRESSURE_PUMP_OFF;
                        HOT_WATER_OFF;
                        break;
                    case 8:
                        COOLER_OFF;
                        break;
                }
                sncdry_vlv_on_flg=CLEAR_1;
                scndry_vlv_off_tmr=backup_scndry_wtr_off_time;
                scndr_vlv_on_off_cnt--;
                sndry_vlv_rns_prcs_complete_flg=(scndr_vlv_on_off_cnt==0)?(backup_scndry_wtr_on_time=backup_scndry_wtr_off_time=0,SET):CLEAR_1;
            }
        }
        else
        {
            scndr_vlv_on_off_cnt=rnse_menu_set[rinse_id][no_of_pulz];
            backup_scndry_wtr_on_time=rnse_menu_set[rinse_id][total_wtr_time]/scndr_vlv_on_off_cnt;
            backup_scndry_wtr_off_time=(rnse_menu_set[rinse_id][no_of_pulz]>1)?rnse_menu_set[rinse_id][pulz_pauz_time]:0;
        }
    }
}

/*
 * we need what are mixer are present in the machine.
 * Based on that we provide a rinse id
 */

void all_mixer_rinse()
{
    if(all_mixer_rinse_start_flag)
    {
        if(!start_rinse_from_all_mxr_flg)
        {
            if((mixer_id<5)AND(!cancel_all_mixer_rins_flg))
            {
                if(backup_rinse_id!=channel[++mixer_id])            //we ignore the duplicate mixers
                {
                    rinse_id=channel[mixer_id];
                    backup_rinse_id=rinse_id;
                    mixer_id_send_flg=SET;
                    start_rinse_from_all_mxr_flg=SET;
                }
            }
            else
            {
                all_mixer_rinse_start_flag=cancel_all_mixer_rins_flg=CLEAR_1;
                all_mixer_rinse_done_snd_flg=rinse_all_start_flag?(all_mixer_complete_flg=SET,CLEAR_1):SET;
                mixer_id=backup_rinse_id=0;
            }
        }
    }
}

void rinse_all()
{
    if(rinse_all_start_flag)
    {
        switch(rinse_all_seq)
        {
            case 1:                     //espresso brewer
                if(espresso_brwr_rnse_cmplet_flg)
                {
                    espresso_brwr_rnse_cmplet_flg=CLEAR_1;
                    rinse_all_seq+=2;
                }
                else if(!initiate_espresso_brwr_rins_flg)
                {
                    initiate_espresso_brwr_rins_flg=SET;
                    rinse_id=9;
                }
                break;
            case 2:                     //fresh brewer
                if(fb_brwr_rnse_cmplet_flg)
                {
                    fb_brwr_rnse_cmplet_flg=CLEAR_1;
                    rinse_all_seq++;
                }
                else if(!initiate_fb_brwr_rins_flg)
                {
                    initiate_fb_brwr_rins_flg=SET;
                    rinse_id=10;
                }
                break;
            case 3:                     //all mixers
                if(all_mixer_complete_flg)
                {
                    all_mixer_complete_flg=CLEAR_1;
                    rinse_all_seq++;
                }
                else if(!all_mixer_rinse_start_flag)
                all_mixer_rinse_start_flag=SET;
                break;
            case 4:                 //hot water and cold water and extra hot water
                if(!start_water_valve_flg)
                {
                    if(water_id<3)
                    {
                        water_id++;
                        if((water_id==1)AND(channel[6]!=6))         //if channel 6 have mixer 5 means there is no extra hot water will be there
                        water_id++;
                        rinse_id=(water_id==1)?6:(water_id==2?7:8);
                        if((!cooler_en)AND(water_id==3))            //if the machine have cooler then only we rinse that
                        {
                            water_id++;
                            rinse_id=0;
                        }
                        else
                        start_water_valve_flg=SET;
                    }
                    else
                    {
                        water_id=rinse_all_seq=0;
                        rinse_all_start_flag=CLEAR_1;
                        rinse_all_complete_snd_flg=SET;
                    }
                }
                break;
        }
    }
}
/*
 * 1. brewer rinsing.
 * 2. if the flush is enabled, then we move the brewer based on the time then do flush
 * 3. do rinsing with the cleaning pill.
 * 4. if espresso drink is enabled then we dispense espresso drink with standard settings.
 *
 *
 */

void espresso_brewer_cleaning()
{
    if(es_cln_strt_flg)
    {
        switch(es_clean_stp_id)
        {
            case 1:                 //espresso brewer rinse with closed position
                if(espresso_brwr_rnse_cmplet_flg)
                {
                    espresso_brwr_rnse_cmplet_flg=CLEAR_1;
                    es_clean_stp_id++;
                    opn_pos_rins_stp=1;
                }
                else if(!initiate_espresso_brwr_rins_flg)
                {
                    initiate_espresso_brwr_rins_flg=SET;
                    rinse_id=9;
                }
                break;
            case 2:                 //espresso brewer rinse with open position
                if(rnse_menu_set[flus_es_set][fls_es_brwr_en])
                {
                    switch(opn_pos_rins_stp)
                    {
                        case 1:             //move brewer to open position based on time
                            if((es_brwr_mtr_flg)AND(es_brwr_opn_pos_tmr<=0))
                            {
                                ESPRESSO_BREWER_OFF;
                                cycle_count=rnse_menu_set[flus_es_set][fls_es_brwr_cycl_cnt];
                                opn_pos_rins_stp++;
                            }
                            else if(!es_brwr_mtr_flg)
                            {
                                ESPRESSO_BREWER_ON;
                                es_brwr_opn_pos_tmr=rnse_menu_set[flus_es_set][fls_es_brwr_run_time];
                            }
                            break;
                        case 2:             //rinse brewer
                            if(cycle_count>0)
                            {
                                if((es_rns_wtr_tmr<=0)AND(presure_pump_flg)AND(three_way_vlv_flg))
                                {
                                    PRESSURE_PUMP_OFF;
                                    THREE_WAY_VALVE_OFF;
                                    opn_pos_rins_stp++;
                                }
                                else if((!presure_pump_flg)AND(!three_way_vlv_flg))
                                {
                                    PRESSURE_PUMP_ON;
                                    THREE_WAY_VALVE_ON;
                                    es_rns_wtr_tmr=rnse_menu_set[flus_es_set][fls_es_brwr_wtr];
                                }
                            }
                            else
                                opn_pos_rins_stp+=2;
                            break;
                        case 3:                             //pauze time
                            if((es_rns_pauz_tmr<=0)AND(es_paus_tm_flg))
                            {
                                es_paus_tm_flg=CLEAR_1;
                                cycle_count--;
                                opn_pos_rins_stp--;
                            }
                            else if(!es_paus_tm_flg)
                            {
                                es_rns_pauz_tmr=rnse_menu_set[flus_es_set][fls_es_brwr_pauz];
                                es_paus_tm_flg=SET;
                            }
                            break;
                        case 4:                             //back to fill position
                            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                            {
                                ESPRESSO_BREWER_OFF;
                                opn_pos_rins_stp=es_clean_stp_id=0;
                                es_cln_strt_flg=CLEAR_1;
                                step1_completed_snd_flg=SET;
                            }
                            else if(!es_brwr_mtr_flg)
                            ESPRESSO_BREWER_ON;
                            break;
                    }
                }
                else
                {
                    opn_pos_rins_stp=es_clean_stp_id=0;
                    es_cln_strt_flg=CLEAR_1;
                    step1_completed_snd_flg=SET;
                }
                break;
            case 3:
                switch(cln_pill_rnse_stp)
                {
                    case 1:         //move to brew pos
                        if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
                        {
                            ESPRESSO_BREWER_OFF;
                            cycle_count=rnse_menu_set[es_cln_set][cln_es_brwr_cycl_cnt];
                            cln_pill_rnse_stp++;
                        }
                        else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
                        ESPRESSO_BREWER_ON;
                        break;
                    case 2:             //rinse brewer
                        if(cycle_count>0)
                        {
                            if((es_rns_wtr_tmr<=0)AND(presure_pump_flg))
                            {
                                PRESSURE_PUMP_OFF;
                                cln_pill_rnse_stp++;
                            }
                            else if(!presure_pump_flg)
                            {
                                PRESSURE_PUMP_ON;
                                if(!three_way_vlv_flg)
                                THREE_WAY_VALVE_ON;
                                es_rns_wtr_tmr=rnse_menu_set[es_cln_set][cln_es_brwr_wtr];
                            }
                        }
                        else
                        {
                            THREE_WAY_VALVE_OFF;
                            cln_pill_rnse_stp+=2;
                        }
                        break;
                    case 3:                             //soaking brew chamber
                        if((es_brwr_soak_tmr<=0)AND(es_soak_tm_flg))
                        {
                            es_soak_tm_flg=CLEAR_1;
                            cycle_count--;
                            cln_pill_rnse_stp--;
                        }
                        else if(!es_soak_tm_flg)
                        {
                            es_brwr_soak_tmr=rnse_menu_set[es_cln_set][cln_es_brwr_soak_chmbr];
                            es_soak_tm_flg=SET;
                        }
                        break;
                    case 4:                             //pauze time
                        if((es_rns_pauz_tmr<=0)AND(es_paus_tm_flg))
                        {
                            es_paus_tm_flg=CLEAR_1;
                            cln_pill_rnse_stp++;
                        }
                        else if(!es_paus_tm_flg)
                        {
                            es_rns_pauz_tmr=rnse_menu_set[es_cln_set][cln_es_brwr_pauz];
                            es_paus_tm_flg=SET;
                        }
                        break;
                    case 5:                             //back to fill position
                        if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                        {
                            ESPRESSO_BREWER_OFF;
                            cln_pill_rnse_stp=0;
                            es_cln_strt_flg=CLEAR_1;
                            step2_completed_snd_flg=SET;
                            if(rnse_menu_set[es_drnk_aftr_cln][es_drnk_aftr_cln_en])
                                es_clean_stp_id=4;
                            else
                                es_clean_stp_id=0;
                        }
                        else if(!es_brwr_mtr_flg)
                        ESPRESSO_BREWER_ON;
                        break;
                }
                break;
            case 4:         //dispense espresso drink
                if(rnse_menu_set[es_drnk_aftr_cln][es_drnk_aftr_cln_en])
                {
                    if(get_esprs_drnk_vlu_flg)
                    {
                        if(espresso_procs_cmplete_flag)
                        {
                            espresso_procs_cmplete_flag=get_esprs_drnk_vlu_flg=CLEAR_1;
                            cln_pill_rnse_stp=0;
                            es_cln_strt_flg=CLEAR_1;
                            espress_drnk_clng_dspns_complt_flg=SET;
                        }
                        else
                        espresso_dispens_process();
                    }
                    else if(!get_esprs_drnk_vlu_flg)
                    {
                        es_drnk_grndr_dly_time=0;
                        es_drnk_grndr_run_time=190;     //1.9 sec
                        es_drnk_pre_brw_wtr_time=60;    //0.6 sec
                        es_drnk_pre_brw_wait_time=100;  //1 sec
                        es_drnk_cof_wtr_pulz=110;
                        es_drnk_brwr_pauz_time=300;     //3 sec
                        es_drnk_brwr_dly_time=50;       //0.5 sec
                        get_esprs_drnk_vlu_flg=SET;
                        espresso_sequence=GRINDER,reprsr_intrvl_time_count=0;
                        espress_drnk_clng_dspns_strt_flg=SET;
                    }
                }
                break;
        }
    }
}

void fresh_brewer_movement()
{
    if(move_fb_flg)
    {
        switch(fb_move_id)
        {
            case 1:     // open the top of the brewer
                if((fb_pos_move_tmr<=0)AND(fresh_brewer_mtr_flg))
                {
                    FRESH_BREWER_OFF;
                    fb_move_id=0;
                    move_fb_flg=CLEAR_1;
                    frsh_brwr_mvng_done_snd_flg=SET;
                }
                else if(!fresh_brewer_mtr_flg)
                {
                    FRESH_BREWER_ON;
                    fb_pos_move_tmr=rnse_menu_set[rplc_fltr_ppr][fb_fltr_ppr_pos_stp];
                }
                break;
            case 2:             //back to the home position
                if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4))
                {
                    FRESH_BREWER_OFF;
                    confrm_brwr_in_pos_dly=fb_move_id=0;
                    move_fb_flg=CLEAR_1;
                    frsh_brwr_mvng_done_snd_flg=SET;
                }
                else if((fb_home_pos_flg)AND(!fresh_brewer_mtr_flg))
                    FRESH_BREWER_ON;
                break;
        }
    }
}

