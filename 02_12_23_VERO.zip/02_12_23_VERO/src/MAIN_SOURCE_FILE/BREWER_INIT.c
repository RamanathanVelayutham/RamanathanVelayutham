/*
 * BREWER_INIT.c
 *
 *  Created on: 23-Feb-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/MDB_HEADER_FILE/MDB_XVARIABLES.h"


void espresso_brewer_initialization();
void fresh_brew_brewer_initialization();

/*
1. first need to check brewer is placed or not based on settings.
2. if placed, need to check brewer in fill position or not, not in fill position confirm within 500 msec then need to run brewer.
3. find the fill position, then again run the brewer and find the fill position 2nd time, within 22 sec, else error.
*/

void espresso_brewer_initialization()
{
        brewr_en_or_dis=drnk_genral_set[use_brwr_plced_sw]?(es_brwr_plc_sw_flg?0:(brwr_plced_cnfrm>=4)?1:0):SET;
        if(brewr_en_or_dis)
        {
            plced_es_brwr_err_snd=one_tme_brw_plc_err_snd?one_tme_brw_plc_err_snd=CLEAR_1,SET:CLEAR_1;
            if(!es_brwr_mtr_flg?!drip_lvl_chk_flag:1)
            {
                if((door_opened_flg)AND(!one_time_brwr_abrt_snd_flg))
                {
                    if(es_brwr_mtr_flg)
                    {
                        ESPRESSO_BREWER_OFF;
                        wait_for_continue_flg=SET;
                        if(brw_2_fil_err_cnt_start_flg)
                            backup_brw_2_fil_cnt_start_flg=SET,brw_2_fil_err_cnt_start_flg=CLEAR_1;
                        else if(fil_2_brw_err_cnt_start_flg)
                            backup_fil_2_brw_cnt_start_flg=SET,fil_2_brw_err_cnt_start_flg=CLEAR_1;
                        es_brwr_err_cnt_flg=CLEAR_1;
                    }
                    brwr_stpd_flg=SET;      // after confirmation clear these and on the brewer and set the brewer err count
                    brwr_abort_infmation_snd_flg=one_time_brwr_abrt_snd_flg=SET;
                }
                if(door_opened_flg?!brwr_stpd_flg:1)
                {
                    if(wait_for_continue_flg)
                    {
                        wait_for_continue_flg=CLEAR_1;
                        ESPRESSO_BREWER_ON;
                        es_brwr_err_cnt_flg=SET;
                        if(backup_brw_2_fil_cnt_start_flg)
                            brw_2_fil_err_cnt_start_flg=SET,backup_brw_2_fil_cnt_start_flg=CLEAR_1;
                        else if(backup_fil_2_brw_cnt_start_flg)
                            fil_2_brw_err_cnt_start_flg=SET,backup_fil_2_brw_cnt_start_flg=CLEAR_1;
                    }
                    if(!pos_cnfrm_flg)
                    {
                        pos_id=((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))?1:2;
                        pos_cnfrm_flg=SET;
                    }
                    else
                    {
                        if(es_brwr_err_cnt<220)
                        {
                            switch(pos_id)
                            {
                                case 1:         //already in fill
                                    if(es_brwr_mtr_flg)
                                    {
//                                        if(!es_brw_pos_sw_flg)
//                                            test_time_id++;
                                        if(((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=2)AND(fill_to_brew_err_cnt<70))OR(for_rnd_2_cycle))
                                        {
                                            if((!brw_2_fil_err_cnt_start_flg)AND(fil_2_brw_err_cnt_start_flg))
                                                brw_2_fil_err_cnt_start_flg=SET,fil_2_brw_err_cnt_start_flg=CLEAR_1, for_rnd_2_cycle=SET;
                                            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=2)AND(brw_to_fil_cnt<90))
                                            {
                                                ESPRESSO_BREWER_OFF;
                                                brwr_init_done_flg=SET;
                                                pos_cnfrm_flg=for_rnd_2_cycle=brwr_stpd_flg=CLEAR_1;
                                                es_brwr_err_cnt_flg=brewr_en_or_dis=one_time_brwr_abrt_snd_flg=brw_2_fil_err_cnt_start_flg=fil_2_brw_err_cnt_start_flg=CLEAR_1;
                                                brw_to_fil_cnt=fill_to_brew_err_cnt=0;
                                                es_brwr_err_cnt=restart_init_with_brwr_fail=pos_id=0;
                                                init_brwr_alrdy_in_pos_flag=SET;
                                            }
                                            else if(brw_to_fil_cnt>=90)
                                            {
                                                ESPRESSO_BREWER_OFF;
                                                goto ERROR;
                                            }
                                        }
                                        else if(fill_to_brew_err_cnt>=70)
                                        {
                                            ESPRESSO_BREWER_OFF;
                                            goto ERROR;
                                        }
                                    }
                                    else
                                    {
                                        ESPRESSO_BREWER_ON;
                                        brwr_init_send_flg=SET;
                                        es_brwr_err_cnt_flg=fil_2_brw_err_cnt_start_flg=SET;
                                    }
                                    break;
                                case 2:         //not in proper position
                                    if(es_brwr_mtr_flg)
                                    {
                                        if(((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=2)AND(fill_to_brew_err_cnt<70))OR((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=2)AND(brw_to_fil_cnt<90)))
                                        {
                                            if((brw_2_fil_err_cnt_start_flg)AND(fil_2_brw_err_cnt_start_flg))
                                            {
                                                brw_2_fil_err_cnt_start_flg=fil_2_brw_err_cnt_start_flg=CLEAR_1;
                                                if(!es_brw_pos_sw_flg)
                                                    brw_2_fil_err_cnt_start_flg=SET, brw_to_fil_cnt=fill_to_brew_err_cnt=0,pos_id=3;      //brew to fill position
                                                else
                                                    fil_2_brw_err_cnt_start_flg=SET, brw_to_fil_cnt=fill_to_brew_err_cnt=0,pos_id=1;      //fill to another fill
                                            }

                                        }
                                    }
                                    else
                                    {
                                        ESPRESSO_BREWER_ON;
                                        brwr_init_send_flg=SET;
                                        es_brwr_err_cnt_flg=fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=SET;
                                    }
                                    break;
                                case 3:             //brew to fill
                                    if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=2)AND(brw_to_fil_cnt<90))
                                        fil_2_brw_err_cnt_start_flg=SET,brw_to_fil_cnt=fill_to_brew_err_cnt=brw_2_fil_err_cnt_start_flg=0, pos_id=1;
                                    else if(brw_to_fil_cnt>=90)
                                    {
                                        ESPRESSO_BREWER_OFF;
                                        goto ERROR;
                                    }
                                    break;

                            }
                        }
                        else
                        {
                            if(pos_id>0)
                            {
                                ERROR:
                                    if(es_brwr_mtr_flg)
                                    ESPRESSO_BREWER_OFF;
                                    if(restart_init_with_brwr_fail>2)
                                    {
                                        brwr_init_done_flg=Machine_err_flag=SET;
                                        es_brwr_full_rotat_er_snd_flg=SET;
                                        drip_lvl_chk_flag=one_time_drip_try_plc_snd_flg=for_rnd_2_cycle=pos_cnfrm_flg=one_tme_brw_plc_err_snd=CLEAR_1;
                                        brwr_stpd_flg=fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=CLEAR_1;
                                        es_brwr_err_cnt_flg=brewr_en_or_dis=one_time_brwr_abrt_snd_flg=init_brwr_alrdy_in_pos_flag=need_to_get_reinit_cnfrm_flg=CLEAR_1;
                                        es_brwr_err_cnt=restart_init_with_brwr_fail=brw_to_fil_cnt=fill_to_brew_err_cnt=pos_id=0;
                                    }
                                    else
                                    {
                                        brwr_init_done_flg=SET;
                                        restart_init_with_brwr_fail++;
                                        restart_id_2_send_flg=need_to_get_reinit_cnfrm_flg=SET;
                                        drip_lvl_chk_flag=one_time_drip_try_plc_snd_flg=for_rnd_2_cycle=pos_cnfrm_flg=CLEAR_1;
                                        fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=CLEAR_1;
                                        es_brwr_err_cnt_flg=brewr_en_or_dis=one_time_brwr_abrt_snd_flg=init_brwr_alrdy_in_pos_flag=CLEAR_1;
                                        es_brwr_err_cnt=brw_to_fil_cnt=fill_to_brew_err_cnt=pos_id=0;
                                    }
                            }
                        }
                    }
                }
            }
        }
        else if((es_brwr_plc_sw_flg)AND(!one_tme_brw_plc_err_snd)AND(brwr_not_plced_cnfrm>=4))
            one_tme_brw_plc_err_snd=plc_es_brwr_err_snd=SET;
}

void fresh_brew_brewer_initialization()
{
    if(!fresh_brewer_mtr_flg?!drip_lvl_chk_flag:1)
    {
        if((door_opened_flg)AND(!one_time_brwr_abrt_snd_flg))
        {
            if(fresh_brewer_mtr_flg)
            {
                FRESH_BREWER_OFF;
                wait_for_continue_flg=SET;
                fb_brwr_err_cnt_flg=CLEAR_1;
            }
            brwr_stpd_flg=SET;      // after confirmation clear these and on the brewer and set the brewer err count
            brwr_abort_infmation_snd_flg=one_time_brwr_abrt_snd_flg=SET;
        }
        if(door_opened_flg?!brwr_stpd_flg:1)
        {
            fb_brwr_err_cnt_flg=wait_for_continue_flg?(wait_for_continue_flg=CLEAR_1,FRESH_BREWER_ON,SET):fb_brwr_err_cnt_flg;
            if(fb_brwr_err_cnt<220)
            {
                if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4))//AND(fb_brwr_err_cnt>30))
                {
                    if(fresh_brewer_mtr_flg)
                    {
                        FRESH_BREWER_OFF;
                        brwr_init_done_flg=SET;
                        fb_brwr_err_cnt_flg=one_time_brwr_abrt_snd_flg=CLEAR_1;
                        fb_brwr_err_cnt=0;
                        init_brwr_alrdy_in_pos_flag=SET;
                    }
                    else
                        init_brwr_alrdy_in_pos_flag=SET;

                }
                else                                    //if((fb_home_pos_flg)AND(confrm_brwr_not_in_pos_dly>=4))
                {
                    if(!fresh_brewer_mtr_flg)
                    {
                        FRESH_BREWER_ON;
//                        run_time_pos_chck_flg=SET;
                        brwr_init_send_flg=SET;
                        fb_brwr_err_cnt_flg=SET;
                    }
                }
            }
            else
            {
                FRESH_BREWER_OFF;
                if(restart_init_with_brwr_fail>3)
                {
                    brwr_init_done_flg=Machine_err_flag=SET;
                    init_fb_pos_err_snd_flg=SET;
                    drip_lvl_chk_flag=one_time_drip_try_plc_snd_flg=CLEAR_1;
                    fb_brwr_err_cnt_flg=one_time_brwr_abrt_snd_flg=init_brwr_alrdy_in_pos_flag=need_to_get_reinit_cnfrm_flg=CLEAR_1;
                    fb_brwr_err_cnt=restart_init_with_brwr_fail=0;
                }
                else
                {
                    restart_init_with_brwr_fail++;
                    restart_id_2_send_flg=SET;
                    fb_brwr_err_cnt_flg=one_time_brwr_abrt_snd_flg=CLEAR_1;
                    fb_brwr_err_cnt=0;
                }
            }
        }
    }
}


