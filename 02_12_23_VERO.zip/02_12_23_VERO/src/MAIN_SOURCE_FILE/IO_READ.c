/*
 * IO_READ.c
 *
 *  Created on: 29-Dec-2022
 *      Author: afila
 */
#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void ios_read();

void ios_read()
{
    //espresso air break
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_07,&AIR_BREAK_MIN);  //sw 6
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_06,&AIR_BREAK_MAX);  //sw 7

    //espresso brewer
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_12,&ES_BREW_POS);        //NC        //sw1
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_11,&ES_FILL_POS);        //NO        //sw2
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_09,&ES_BREWER_PLACED_SW);        //sw4


    //open air boiler fill
//    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_04,&OPEN_AIR_BOILER_WTR_LVL1);
//    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_03,&OPEN_AIR_BOILER_WTR_LVL2);

    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_03,&FILTER_PAPER_SW);    //sw 10
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_05,&WASTE_BIN_PRSNT_SW );  //sw 8
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_04,&TRASH_BIN_FULL_SW); //sw 9
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_10,&FB_BRWR_REST_SW);    //sw 3


    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_08,&COFFEE_DOSER_SW);        //sw 5
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_02,&JUG_TRAY_SW1);    //sw 11
    g_ioport.p_api->pinRead(IOPORT_PORT_03_PIN_01,&JUG_TRAY_SW2);    //sw 12

    g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_02,&DRIP_LVL1);
}
void ios_flag()
{
    if(!drnk_genral_set[air_break_rod_en])
    {
        ar_brk_min_flg=AIR_BREAK_MIN;
        ar_brk_max_flg=AIR_BREAK_MAX;
    }

    es_fill_pos_sw_flg=ES_FILL_POS;
    es_brw_pos_sw_flg=ES_BREW_POS;
    es_brwr_plc_sw_flg=ES_BREWER_PLACED_SW;

    filter_paper_present=FILTER_PAPER_SW;
    waste_bin_full=TRASH_BIN_FULL_SW;
    wast_bin_prsnt_sw=WASTE_BIN_PRSNT_SW;
    fb_home_pos_flg=FB_BRWR_REST_SW?CLEAR_1:SET;
}

