/*
 * FACTORY_TEST.c
 *
 *  Created on: 15-May-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void beeper_test();
void canister_tests();
void wtr_op_test();
void espresso_systems_test();
void opn_blr_system_test();
void snsr_sw_ft();
void fatory_test();
void opn_blr_ft_filling();
void ft_opn_blr_heating();
void ft_es_blr_heating();
void ft_air_break_fill_program();
void ft_espresso_blr_fill_program();
void espresso_brewer_ft();
void ft_drip_tray();

void fatory_test()
{
    beeper_test();
    canister_tests();
    wtr_op_test();
    espresso_systems_test();
    opn_blr_system_test();
    snsr_sw_ft();
}

void beeper_test()
{
    if(!beep_sound_flg)
    {
        if((beeper_ft_on_flg)AND(!buzzer_on_flg))
            BEEPER_ON;
        else if((buzzer_on_flg)AND(!beeper_ft_on_flg))
            BEEPER_OFF;
    }
}

void canister_tests()
{
    if(canister_initated_flg)
    {
        switch(canister_test_id)
        {
            case 1:                 //canister 1
                if(((prmx1_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[1].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==1)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR1_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx1_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==1)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR1_ON;
                    ch_tmr[1].prmx_on_time=300;
                }
                break;
            case 2:                 //canister 2
                if(((prmx2_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[2].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==2)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR2_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx2_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==2)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR2_ON;
                    ch_tmr[2].prmx_on_time=300;
                }
                break;
            case 3:                 //canister 3
                if(((prmx3_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[3].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==3)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR3_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx3_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==3)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR3_ON;
                    ch_tmr[3].prmx_on_time=300;
                }
                break;
            case 4:                 //canister 4
                if(((prmx4_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[4].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==4)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR4_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx4_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==4)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR4_ON;
                    ch_tmr[4].prmx_on_time=300;
                }
                break;
            case 5:                 //canister 5
                if(((prmx5_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[5].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==5)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR5_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx5_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==5)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR5_ON;
                    ch_tmr[5].prmx_on_time=300;
                }
                break;
            case 6:                 //canister 6
                if(((prmx6_on_flg)OR(prstltc_pmp_flg))AND(ch_tmr[6].prmx_on_time<=0))
                {
                    if(liquid_choco_ch==6)
                        PERISTALTIC_PUMP_OFF;
                    else
                        PRIMIX_MOTOR6_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if((!prmx6_on_flg)AND(!prstltc_pmp_flg))
                {
                    if(liquid_choco_ch==6)
                        PERISTALTIC_PUMP_ON;
                    else
                        PRIMIX_MOTOR6_ON;
                    ch_tmr[6].prmx_on_time=300;
                }
                break;
            case 7:                 //Bean Canister
                if((bean_grndr_on_flg)AND(bean_grinder_run_time<=0))
                {
                    BEAN_GRINDER_OFF;
                    canister_initated_flg=CLEAR_1;
                    canister_test_done=beep_sound_flg=SET;
                }
                else if(!bean_grndr_on_flg)
                {
                    BEAN_GRINDER_ON;
                    bean_grinder_run_time=300;
                }
                break;
        }
    }
}
void wtr_op_test()
{
    if((wtr_op_initated_flg)OR(wtr_run_time_initiate_flg))
    {
        switch(wtr_op_test_id)
        {
            case 1:         //fresh brewer
                switch(fb_ft_test_id)
                {
                    case 1:
                        if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4))
                            fb_ft_test_id=3;
                        else
                            fb_ft_test_id=2;
                        break;
                    case 2:
                        if(fb_brwr_err_cnt<220)
                        {
                            if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4)AND(fresh_brewer_mtr_flg))
                            {
                                if(!wtr_run_time_initiate_flg)
                                    reset_fb_tmr_snd_flg=SET;
                                fb_ft_test_id=3;
                            }
                        }
                        else
                        {
                            FRESH_BREWER_OFF;
                            fb_brwr_err_cnt_flg=0;
                            fb_brwr_err_cnt=0;
                            wtr_op_test_id=fb_ft_test_id=0;
                            if(wtr_run_time_initiate_flg)
                            {
                                wtr_run_time_initiate_flg=CLEAR_1,water_ch_id=0;
                                wtr_run_time_done_snd_flg=SET;
                            }
                            else
                            {
                                wtr_op_initated_flg=CLEAR_1;
                                wtr_op_test_done=beep_sound_flg=SET;
                            }
                        }
                        break;
                    case 3:
                    if(((ch_tmr[1].wtr_on_time<=0)AND(sol_vlv1_on_flg))OR(enter_for_fb_movement))
                    {
                        if(sol_vlv1_on_flg)
                        {
                            SOLENOID1_OFF;
                            enter_for_fb_movement=SET;
                        }
                        if(fb_brwr_err_cnt<220)
                        {
                            if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4)AND(fresh_brewer_mtr_flg))
                            {
                                if(!brewer_already_in_pos)
                                {
                                    FRESH_BREWER_OFF;
                                    fb_brwr_err_cnt_flg=enter_for_fb_movement=CLEAR_1;
                                    fb_brwr_err_cnt=0;
                                    if(wtr_run_time_initiate_flg)
                                    {
                                        wtr_run_time_initiate_flg=CLEAR_1;
                                        water_ch_id=demo_wtr_run_time=0;
                                        wtr_run_time_done_snd_flg=SET;
                                    }
                                    else
                                    {
                                        wtr_op_initated_flg=CLEAR_1;
                                        wtr_op_test_done=beep_sound_flg=SET;
                                    }
                                }
                            }
                            else
                            {
                                if(!fresh_brewer_mtr_flg)
                                {
                                    FRESH_BREWER_ON;
                                    fb_brwr_err_cnt_flg=SET;
                                    brewer_already_in_pos=fb_home_pos_flg?CLEAR_1:SET;
                                }
                                else if(brewer_already_in_pos)
                                    brewer_already_in_pos=CLEAR_1;
                            }
                        }
                        else
                        {
                            FRESH_BREWER_OFF;
                            fb_brwr_err_cnt_flg=0;
                            fb_brwr_err_cnt=0;
                            wtr_op_test_id=fb_ft_test_id=0;
                            enter_for_fb_movement=CLEAR_1;
                            if(wtr_run_time_initiate_flg)
                            {
                                wtr_run_time_initiate_flg=CLEAR_1,water_ch_id=0;
                                wtr_run_time_done_snd_flg=SET;
                            }
                            else
                                wtr_op_initated_flg=CLEAR_1;
                        }
                    }
                    else if(!sol_vlv1_on_flg)
                    {
                        SOLENOID1_ON;
                        ch_tmr[1].wtr_on_time=wtr_run_time_initiate_flg?demo_wtr_run_time:100;
                    }
                }
                break;
            case 2:        //fan
                if((fan_mtr_flg)AND(fan_on_tmr<=0))
                {
                    FAN_OFF;
                    wtr_op_initated_flg=CLEAR_1;
                    wtr_op_test_done=beep_sound_flg=SET;
                }
                else if(!fan_mtr_flg)
                {
                    FAN_ON;
                    fan_on_tmr=5;
                }
                break;
            case 3:        //mixer 1
               if((ch_tmr[1].wtr_on_time<=200)AND(sol_vlv1_on_flg))
               {
                   if((ch_tmr[1].mxr_on_time<=0)AND(mxr1_on_flg))
                   {
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID1_OFF;
                       MIXER_MOTOR1_OFF;
                       wtr_op_initated_flg=CLEAR_1;
                       wtr_op_test_done=beep_sound_flg=SET;
                   }
                   else if(!mxr1_on_flg)
                   {
                       MIXER_MOTOR1_ON;
                       ch_tmr[1].mxr_on_time=200;
                   }
               }
               else if(!sol_vlv1_on_flg)
               {
                   if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                       PRESSURE_PUMP_ON;
                   SOLENOID1_ON;
                   ch_tmr[1].wtr_on_time=300;
               }
               break;
            case 4:        //mixer 2
               if((ch_tmr[2].wtr_on_time<=200)AND(sol_vlv2_on_flg))
               {
                   if((ch_tmr[2].mxr_on_time<=0)AND(mxr2_on_flg))
                   {
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID2_OFF;
                       MIXER_MOTOR2_OFF;
                       wtr_op_initated_flg=CLEAR_1;
                       wtr_op_test_done=beep_sound_flg=SET;
                   }
                   else if(!mxr2_on_flg)
                   {
                       MIXER_MOTOR2_ON;
                       ch_tmr[2].mxr_on_time=200;
                   }
               }
               else if(!sol_vlv2_on_flg)
               {
                   if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                       PRESSURE_PUMP_ON;
                   SOLENOID2_ON;
                   ch_tmr[2].wtr_on_time=300;
               }
               break;
            case 5:        //mixer 3
               if((ch_tmr[3].wtr_on_time<=200)AND(sol_vlv3_on_flg))
               {
                   if((ch_tmr[3].mxr_on_time<=0)AND(mxr3_on_flg))
                   {
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID3_OFF;
                       MIXER_MOTOR3_OFF;
                       wtr_op_initated_flg=CLEAR_1;
                       wtr_op_test_done=beep_sound_flg=SET;
                   }
                   else if(!mxr3_on_flg)
                   {
                       MIXER_MOTOR3_ON;
                       ch_tmr[3].mxr_on_time=200;
                   }
               }
               else if(!sol_vlv3_on_flg)
               {
                   if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                       PRESSURE_PUMP_ON;
                   SOLENOID3_ON;
                   ch_tmr[3].wtr_on_time=300;
               }
               break;
            case 6:        //mixer 4
               if((ch_tmr[4].wtr_on_time<=200)AND(sol_vlv4_on_flg))
               {
                   if((ch_tmr[4].mxr_on_time<=0)AND(mxr4_on_flg))
                   {
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID4_OFF;
                       MIXER_MOTOR4_OFF;
                       wtr_op_initated_flg=CLEAR_1;
                       wtr_op_test_done=beep_sound_flg=SET;
                   }
                   else if(!mxr4_on_flg)
                   {
                       MIXER_MOTOR4_ON;
                       ch_tmr[4].mxr_on_time=200;
                   }
               }
               else if(!sol_vlv4_on_flg)
               {
                   if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                       PRESSURE_PUMP_ON;
                   SOLENOID4_ON;
                   ch_tmr[4].wtr_on_time=300;
               }
               break;
            case 7:        //mixer 5
               if((ch_tmr[5].wtr_on_time<=200)AND(sol_vlv5_on_flg))
               {
                   if((ch_tmr[5].mxr_on_time<=0)AND(mxr5_on_flg))
                   {
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID5_OFF;
                       MIXER_MOTOR5_OFF;
                       wtr_op_initated_flg=CLEAR_1;
                       wtr_op_test_done=beep_sound_flg=SET;
                   }
                   else if(!mxr5_on_flg)
                   {
                       MIXER_MOTOR5_ON;
                       ch_tmr[5].mxr_on_time=200;
                   }
               }
               else if(!sol_vlv5_on_flg)
               {
                   if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                       PRESSURE_PUMP_ON;
                   SOLENOID5_ON;
                   ch_tmr[5].wtr_on_time=300;
               }
               break;
            case 8:        //Extra hot water
                if((sol_vlv6_on_flg)AND(ch_tmr[6].wtr_off_time<=0))
                {
                    if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                        PRESSURE_PUMP_OFF;
                    SOLENOID6_OFF;
                    wtr_op_initated_flg=CLEAR_1;
                    wtr_op_test_done=beep_sound_flg=SET;
                }
                else if(!sol_vlv6_on_flg)
                {
                    if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                        PRESSURE_PUMP_ON;
                    SOLENOID6_ON;
                    ch_tmr[6].wtr_off_time=300;
                }
                break;
            case 9:        // hot water
                if((hot_wtr_on_flg)AND(hot_or_cold_run_time<=0))
                {
                    if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                        PRESSURE_PUMP_OFF;
                    HOT_WATER_OFF;
                    wtr_op_initated_flg=CLEAR_1;
                    wtr_op_test_done=beep_sound_flg=SET;
                }
                else if(!hot_wtr_on_flg)
                {
                    if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                        PRESSURE_PUMP_ON;
                    HOT_WATER_ON;
                    hot_or_cold_run_time=300;
                }
                break;
            case 10:        // cold water
                if((cold_wtr_on_flg)AND(hot_or_cold_run_time<=0))
                {
                    COOLER_OFF;
                    wtr_op_initated_flg=CLEAR_1;
                    wtr_op_test_done=beep_sound_flg=SET;
                }
                else if(!cold_wtr_on_flg)
                {
                    COOLER_ON;
                    hot_or_cold_run_time=300;
                }
                break;
        }
    }
}
void espresso_brewer_ft()
{
    if(!pos_cnfrm_flg)
    {
        es_brwr_tst_stp=((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))?1:2;
        pos_cnfrm_flg=SET;
    }
    else
    {
        if(es_brwr_err_cnt<220)
        {
            switch(es_brwr_tst_stp)
            {
                case 1:         //already in fill
                    if(es_brwr_mtr_flg)
                    {
                        if(((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=2)AND(fill_to_brew_err_cnt<70))OR(for_rnd_2_cycle))
                        {
                            if((!brw_2_fil_err_cnt_start_flg)AND(fil_2_brw_err_cnt_start_flg))
                                brw_2_fil_err_cnt_start_flg=SET,fil_2_brw_err_cnt_start_flg=CLEAR_1, for_rnd_2_cycle=SET;
                            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=2)AND(brw_to_fil_cnt<90))
                            {
                                ESPRESSO_BREWER_OFF;
                                es_brwr_test_complete_snd_flg=beep_sound_flg=SET;
                                pos_cnfrm_flg=for_rnd_2_cycle=CLEAR_1;
                                es_brwr_err_cnt_flg=brw_2_fil_err_cnt_start_flg=fil_2_brw_err_cnt_start_flg=CLEAR_1;
                                brw_to_fil_cnt=fill_to_brew_err_cnt=0;
                                es_brwr_err_cnt=es_brwr_tst_stp=0;//es_sys_test_id
                                es_sys_test_id=drnk_genral_set[air_break_rod_en]?5:2;   //if rod enabled we need to start the espresso fill. else start the air break switch test
                            }
                            else if(brw_to_fil_cnt>=90)
                            {
                                ESPRESSO_BREWER_OFF;
                                goto ERROR;
                            }
                        }
                        else if(fill_to_brew_err_cnt>=70)
                        {
                            ESPRESSO_BREWER_OFF;
                            goto ERROR;
                        }
                    }
                    else
                    {
                        ESPRESSO_BREWER_ON;
                        es_brwr_err_cnt_flg=fil_2_brw_err_cnt_start_flg=SET;
                    }
                    break;
                case 2:         //not in proper position
                    if(es_brwr_mtr_flg)
                    {
                        if(((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=2)AND(fill_to_brew_err_cnt<70))OR((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4)AND(brw_to_fil_cnt<90)))
                        {
                            if((brw_2_fil_err_cnt_start_flg)AND(fil_2_brw_err_cnt_start_flg))
                            {
                                brw_2_fil_err_cnt_start_flg=fil_2_brw_err_cnt_start_flg=CLEAR_1;
                                if(!es_brw_pos_sw_flg)
                                    brw_2_fil_err_cnt_start_flg=SET, brw_to_fil_cnt=fill_to_brew_err_cnt=0,es_brwr_tst_stp=3;      //brew to fill position
                                else
                                    fil_2_brw_err_cnt_start_flg=SET, brw_to_fil_cnt=fill_to_brew_err_cnt=0,es_brwr_tst_stp=1;      //fill to another fill
                            }

                        }
                    }
                    else
                    {
                        ESPRESSO_BREWER_ON;
                        brwr_init_send_flg=SET;
                        es_brwr_err_cnt_flg=fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=SET;
                    }
                    break;
                case 3:             //brew to fill
                    if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=2)AND(brw_to_fil_cnt<90))
                        fil_2_brw_err_cnt_start_flg=SET,brw_to_fil_cnt=fill_to_brew_err_cnt=brw_2_fil_err_cnt_start_flg=0, es_brwr_tst_stp=1;           //fill to another fill
                    else if(brw_to_fil_cnt>=90)
                    {
                        ESPRESSO_BREWER_OFF;
                        goto ERROR;
                    }
                    break;
            }
        }
        else
        {
            ERROR:
                ESPRESSO_BREWER_OFF;
                es_brwr_tst_fail_snd_flg=SET;
                for_rnd_2_cycle=pos_cnfrm_flg=CLEAR_1;
                fil_2_brw_err_cnt_start_flg=brw_2_fil_err_cnt_start_flg=es_brwr_err_cnt_flg=CLEAR_1;
                es_brwr_err_cnt=brw_to_fil_cnt=fill_to_brew_err_cnt=es_brwr_tst_stp=es_sys_test_id=0;
        }
    }
}
void espresso_systems_test()
{
    if(espso_sys_test_initated_flg)
    {
        switch(es_sys_test_id)
        {
            case 1:                 //brewer test
                espresso_brewer_ft();
                break;
            case 2:             //Air break float tests popups
                if((!ar_brk_min_flg)OR(!ar_brk_max_flg))
                    ar_test_popup_flg=SET;
                es_sys_test_id=3;
                break;
            case 3:
                if((ar_brk_min_flg)AND(ar_brk_max_flg))
                {
                    es_sys_test_id=4;
                    ar_brk_tst_case_id=1;
                    ar_tst_initiate_snd_flg=SET;
                }
                break;
            case 4:             //Air break float tests
                if(!exit_ar_brk_tst_flg)
                {
                    switch(ar_brk_tst_case_id)
                    {
                        case 1:         //switch the min level sensor
                            if((!ar_brk_min_flg)AND(ar_brk_max_flg))
                                ar_brk_tst_stp_cmplt_snd_flg=SET;
                            break;
                        case 2:         //Hold the min level and switch the max level sensor
                            if((!ar_brk_min_flg)AND(!ar_brk_max_flg))
                                ar_brk_tst_stp_cmplt_snd_flg=SET;
                            break;
                        case 3:         //Release the max level sensor and hold the min level
                            if((!ar_brk_min_flg)AND(ar_brk_max_flg))
                                ar_brk_tst_stp_cmplt_snd_flg=SET;
                            break;
                        case 4:         //Release the min level sensor
                            if((ar_brk_min_flg)AND(ar_brk_max_flg))
                            {
                                ar_brk_tst_stp_cmplt_snd_flg=SET;
                                beep_sound_flg=SET;
                                es_sys_test_id=5;
                            }
                            break;
                    }
                }
                else
                {
                    exit_ar_brk_tst_flg=CLEAR_1;
                    ar_brk_tst_case_id=es_sys_test_id=0;
                }
                break;
            case 5:         //espresso boiler fill test popup of the filling
                if((!ar_brk_min_flg)OR(!ar_brk_max_flg))
                {
                    es_blr_fil_tst_id=4;
                    es_blr_fil_tst_cmnd_snd_flg=SET;
                }
                es_sys_test_id=6;
                break;
            case 6:
                if((ar_brk_min_flg)AND(ar_brk_max_flg))
                {
                    es_fil_tst_initiate_snd_flg=SET;
                    es_sys_test_id=7;
                }
                break;
            case 7:
                ft_air_break_fill_program();
                ft_espresso_blr_fill_program();
                break;
            case 8:         //espresso boiler heat test
                ft_es_blr_heating();
                break;
        }
    }
}

void opn_blr_system_test()
{
    if(opn_blr_sys_test_initated_flg)
    {
        switch(opn_blr_sys_test_id)
        {
            case 1:         //open air boiler fill program
                opn_blr_ft_filling();
                break;
            case 2:
                ft_opn_blr_heating();
                break;
        }
    }
}

void opn_blr_ft_filling()
{
    if((!blr_lvl1_wtr_flg)OR(!blr_lvl2_wtr_flg))          //any one of the level is not reached then only we do a process.
    {
        if((blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg))      //max detected, min doesnot detected need to send a critical error.
        {
            OPEN_AIR_BOILER_INLET_VALVE_OFF;
            opn_blr_fil_tst_id=3;
            opn_blr_sys_test_id=0;
            opn_blr_fil_tst_cmnd_snd_flg=SET;
            opn_blr_sys_test_initated_flg=opn_blr_ft_fil_strt_flg=block_for_opn_blr_tst=CLEAR_1;
        }
        else
        {
            if(opn_blr_ft_fil_strt_flg)
            {
                if((!blr_lvl1_wtr_flg)AND(blr_lvl2_wtr_flg)AND(opn_blr_min_cnt<600))
                {
                    if((!opn_blr_max_cnt_flg)AND(opn_blr_min_cnt_flg)AND(opn_blr_min_cnfrm_dly>=4))
                    {
                        opn_blr_min_cnfrm_dly=0;
                        opn_blr_min_cnt=0;
                        opn_blr_min_cnt_flg=CLEAR_1;
                        opn_blr_max_cnt_flg=SET;
                        opn_blr_fil_tst_id=1;
                        opn_blr_fil_tst_cmnd_snd_flg=SET;
                    }
                    else if(opn_blr_max_cnt>30)
                    {
                        OPEN_AIR_BOILER_INLET_VALVE_OFF;
                        opn_blr_fil_tst_id=3;
                        opn_blr_sys_test_id=0;
                        opn_blr_fil_tst_cmnd_snd_flg=SET;
                        opn_blr_sys_test_initated_flg=opn_blr_ft_fil_strt_flg=block_for_opn_blr_tst=CLEAR_1;
                    }
                }
                else
                {
                    if((!blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg)AND(opn_blr_max_cnt<30)AND(opn_blr_fl_cnfm_dly>4)) //confirm in 200 msec
                    {
                        if(open_air_blr_inlet_vlv_flg)
                        {
                            OPEN_AIR_BOILER_INLET_VALVE_OFF;
                            opn_blr_fl_cnfm_dly=opn_blr_max_cnt=0;
                            opn_blr_ft_fil_strt_flg=opn_blr_max_cnt_flg=CLEAR_1;//opn_blr_sys_test_initated_flg
                            opn_blr_fil_tst_id=2;
                            opn_blr_sys_test_id=2;
                            opn_blr_ht_initiate_snd_flg=SET;
                            opn_blr_fil_tst_cmnd_snd_flg=beep_sound_flg=SET;
                        }
                    }
                }
            }
            else
            {
                opn_blr_fil_tst_id=4;
                opn_blr_sys_test_id=0;
                opn_blr_fil_tst_cmnd_snd_flg=SET;
                opn_blr_sys_test_initated_flg=opn_blr_ft_fil_strt_flg=block_for_opn_blr_tst=CLEAR_1;
            }
        }
    }
    else
    {
        if(opn_blr_min_cnt>=600)
        {
            OPEN_AIR_BOILER_INLET_VALVE_OFF;
            opn_blr_fil_tst_id=3;
            opn_blr_sys_test_id=0;
            opn_blr_min_cnt=0;
            opn_blr_fil_tst_cmnd_snd_flg=SET;
            opn_blr_sys_test_initated_flg=opn_blr_min_cnt_flg=opn_blr_ft_fil_strt_flg=block_for_opn_blr_tst=CLEAR_1;
        }
        else if((open_blr_empt_cnfrm_dly>=4)AND(!open_air_blr_inlet_vlv_flg))
        {
            OPEN_AIR_BOILER_INLET_VALVE_ON;
            opn_blr_min_cnt_flg=opn_blr_ft_fil_strt_flg=SET;
        }
    }
}
void ft_opn_blr_heating()
{
    if(ar_ctemp>=drnk_genral_set[op_set_temp])
    {
        if(air_boiler_heater_on_flg)
        {
            OPEN_AIR_BLR_HTR_OFF;
            open_blr_htr_err_cnt_flg=opn_blr_htr_ft_strt_flg=opn_blr_sys_test_initated_flg=block_for_opn_blr_tst=CLEAR_1;
            open_blr_htr_err_cnt=opn_blr_sys_test_id=0;
            opn_blr_htr_tst_id=2;
            opn_blr_htr_tst_id_snd_flg=beep_sound_flg=SET;
        }
        else
        {
            opn_blr_sys_test_initated_flg=block_for_opn_blr_tst=CLEAR_1;
            opn_blr_htr_tst_id=3;
            opn_blr_htr_tst_id_snd_flg=SET;
        }
    }
    else
    {
        if(open_blr_htr_err_cnt>=60)
        {
            OPEN_AIR_BLR_HTR_OFF;
            open_blr_htr_err_cnt_flg=opn_blr_htr_ft_strt_flg=opn_blr_sys_test_initated_flg=block_for_opn_blr_tst=CLEAR_1;
            open_blr_htr_err_cnt=opn_blr_sys_test_id=0;
            opn_blr_htr_tst_id=1;
            opn_blr_htr_tst_id_snd_flg=SET;
        }
        else if(!air_boiler_heater_on_flg)
        {
            OPEN_AIR_BLR_HTR_ON;
            open_blr_htr_err_cnt_flg=opn_blr_htr_ft_strt_flg=SET;
            first_ar_blr_temp_flag=SET;
        }
    }
}

void ft_es_blr_heating()
{
    if(es_ctemp>=drnk_genral_set[es_op_set_temp])
    {
        if(espresso_heater_on_flg)
        {
            ESPRESSO_HEATER_OFF;
            es_htr_err_cnt_flg=es_htr_ft_strt_flg=espso_sys_test_initated_flg=CLEAR_1;
            es_htr_err_cnt=es_sys_test_id=0;
            es_htr_tst_id=2;
            es_htr_tst_id_snd_flg=beep_sound_flg=SET;
        }
        else
        {
            espso_sys_test_initated_flg=CLEAR_1;
            es_htr_tst_id=3;
            es_htr_tst_id_snd_flg=SET;
        }
    }
    else
    {
        if(es_htr_err_cnt>=60)
        {
            ESPRESSO_HEATER_OFF;
            es_htr_err_cnt_flg=es_htr_ft_strt_flg=espso_sys_test_initated_flg=CLEAR_1;
            es_htr_err_cnt=es_sys_test_id=0;
            es_htr_tst_id=1;
            es_htr_tst_id_snd_flg=SET;
        }
        else if(!espresso_heater_on_flg)
        {
            ESPRESSO_HEATER_ON;
            es_htr_err_cnt_flg=es_htr_ft_strt_flg=SET;
            first_es_blr_temp_flag=SET;
        }
    }
}

void ft_air_break_fill_program()
{
    if((!ar_brk_min_flg)OR(!ar_brk_max_flg))          //any one of the level is not reached then only we do a process.
    {
        if((ar_brk_min_flg)AND(!ar_brk_max_flg))      //max detected, min doesnot detected need to send a critical error.
        {
            AIR_BREAK_INLET_VALVE_OFF;
            es_blr_fil_tst_id=5;
            es_sys_test_id=0;
            es_blr_fil_tst_cmnd_snd_flg=SET;
            espso_sys_test_initated_flg=air_break_test_fill_start_flg=CLEAR_1;
        }
        else
        {
            if(air_break_test_fill_start_flg)
            {
                if((!ar_brk_min_flg)AND(ar_brk_max_flg)AND(ar_brk_min_cnt<120))
                {
                    if((!ar_brk_max_cnt_flg)AND(ar_brk_min_cnt_flg)AND(ar_brk_min_cnfrm_dly>=4))
                    {
                        ar_brk_min_cnfrm_dly=ar_brk_min_cnt=0;
                        ar_brk_min_cnt_flg=CLEAR_1;
                        ar_brk_max_cnt_flg=SET;
                        es_blr_fil_tst_id=1;
                        es_blr_fil_tst_cmnd_snd_flg=SET;
                    }
                    else if(ar_brk_max_cnt>30)
                    {
                        AIR_BREAK_INLET_VALVE_OFF;
                        es_blr_fil_tst_id=5;
                        es_sys_test_id=0;
                        es_blr_fil_tst_cmnd_snd_flg=SET;
                        espso_sys_test_initated_flg=air_break_test_fill_start_flg=CLEAR_1;
                    }
                }
                else
                {
                    if((!ar_brk_min_flg)AND(!ar_brk_max_flg)AND(ar_brk_max_cnt<30)AND(ar_brk_fl_cnfm_dly>4)) //confirm in 200 msec
                    {
                        if(ar_brk_inlt_vlv_flg)
                        {
                            AIR_BREAK_INLET_VALVE_OFF;
                            ar_brk_fl_cnfm_dly=ar_brk_max_cnt=0;
                            air_break_test_fill_start_flg=ar_brk_max_cnt_flg=air_break_test_fill_start_flg=CLEAR_1;
                            if(!start_es_boilr_fill_flg)
                            {
                                es_blr_fil_tst_id=2;
                                es_blr_fil_tst_cmnd_snd_flg=SET;
                            }
                            start_es_boilr_fill_flg=SET;
                        }
                    }
                }
            }
        }
    }
    else
    {
        if(ar_brk_min_cnt>=120)
        {
            AIR_BREAK_INLET_VALVE_OFF;
            es_blr_fil_tst_id=5;
            es_sys_test_id=0;
            es_blr_fil_tst_cmnd_snd_flg=SET;
            espso_sys_test_initated_flg=ar_brk_min_cnt_flg=air_break_test_fill_start_flg=CLEAR_1;
        }
        else if((ar_brk_emt_cnfrm_dly>=4)AND(!ar_brk_inlt_vlv_flg))
        {
            AIR_BREAK_INLET_VALVE_ON;
            ar_brk_min_cnt_flg=air_break_test_fill_start_flg=SET;
        }
    }
}

void ft_espresso_blr_fill_program()
{
    if(start_es_boilr_fill_flg)
    {
        if(es_brwr_in_brw_pos_flg)
        {
            if(ft_es_boiler_fill_strt_flg)
            {
                if(es_brwr_flw_err_cnt<180)         //3 minutes
                {
                    if(es_flw_cnt<=0)
                    {
                        if((dly_pmp_3vlv<=0)AND(!presure_pump_flg))
                        {
                            if(three_way_vlv_flg)
                            THREE_WAY_VALVE_OFF;
                            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                            {
                                ESPRESSO_BREWER_OFF;
                                es_blr_fil_tst_id=3;
                                es_sys_test_id=8;
                                es_blr_ht_tst_initiate_flg=SET;
                                es_blr_fil_tst_cmnd_snd_flg=beep_sound_flg=SET;
                                start_es_boilr_fill_flg=ft_es_boiler_fill_strt_flg=es_brwr_in_brw_pos_flg=CLEAR_1;//espso_sys_test_initated_flg
                                es_brwr_flw_err_cnt=0;
                            }
                            else if(!es_brwr_mtr_flg)
                            ESPRESSO_BREWER_ON;
                        }
                        else if(presure_pump_flg)
                        {
                            PRESSURE_PUMP_OFF;
                            dly_pmp_3vlv=50;
                            es_brwr_flw_err_cnt=0;
                        }
                    }
                }
                else
                {
                    if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                    {
                        ESPRESSO_BREWER_OFF;
                        THREE_WAY_VALVE_OFF;
                        PRESSURE_PUMP_OFF;
                        start_es_boilr_fill_flg=es_brwr_in_brw_pos_flg=ft_es_boiler_fill_strt_flg=espso_sys_test_initated_flg=CLEAR_1;
                        es_flw_cnt=es_brwr_flw_err_cnt=es_sys_test_id=0;
                        es_blr_fil_tst_id=5;
                        es_blr_fil_tst_cmnd_snd_flg=SET;
                    }
                    else
                        ESPRESSO_BREWER_ON;
                }
            }
            else
            {
                if((!three_way_vlv_flg)AND(!presure_pump_flg))
                {
                    ft_es_boiler_fill_strt_flg=SET;
                    bckup_es_flw_cnt=drnk_genral_set[vlm_of_es_blr];
                    bckup_es_flw_cnt/=1000;
                    bckup_es_flw_cnt*=drnk_genral_set[flw_mtr_puls_per_lit];
                    es_flw_cnt=1.1*bckup_es_flw_cnt;
                    THREE_WAY_VALVE_ON;
                    PRESSURE_PUMP_ON;
                }
            }
        }
        else
        {
            if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
            {
                if(es_brwr_mtr_flg)
                ESPRESSO_BREWER_OFF;
                es_brwr_in_brw_pos_flg=SET;
            }
            else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
            ESPRESSO_BREWER_ON;
        }
    }
}
void ft_drip_tray()
{
    for(unsigned int i=0;i<500;i++)
    {
        g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_02,&DRIP_LVL1);
        if(!DRIP_LVL1)
        {
            drip_lvl1_open_counter=0;
        }
        else
        {
            drip_lvl1_close_counter=0;
        }
    }
}
void snsr_sw_ft()
{
    if(snsr_sw_ft_initiate_flg)
    {
        if(!exit_snsr_sw_tst_flg)
        {
            switch(snsr_sw_id)
            {
                case 1:         //drip tray level sensor is already full
                    ft_drip_tray();
                    if(drip_lvl1_close_counter>20)
                        snsr_sw_popup_flg=SET;
                    snsr_sw_id=2;
                    break;
                case 2:             //till empty we need to wait
                    ft_drip_tray();
                    if(drip_lvl1_open_counter>20)
                    {
                        snsr_sw_rdy_flg=SET;
                        snsr_sw_id=3;
                    }
                    break;
                case 3:             //check drip tray
                    ft_drip_tray();
                    switch(sensr_sw_ft_case_id)
                    {
                        case 1:         //fill the drip tray
                            if(drip_lvl1_close_counter>20)
                                sensr_sw_ft_stp_complt_flg=SET;
                            break;
                        case 2:         //empty the drip tray
                            if(drip_lvl1_open_counter>20)
                            {
                                sensr_sw_ft_stp_complt_flg=SET;
                                sensr_sw_ft_tst_done_flg=beep_sound_flg=SET;
                                snsr_sw_id=0;
                                snsr_sw_ft_initiate_flg=CLEAR_1;
                            }
                            break;
                    }
                    break;
                case 4:         //Trash bin placed sw check is already removed
                    if((wast_bin_prsnt_sw)AND(cnfrm_wst_bin_not_prsnt_dly>4))
                        snsr_sw_popup_flg=SET;
                    snsr_sw_id=5;
                    break;
                case 5:         //till place we need to wait
                    if((!wast_bin_prsnt_sw)AND(cnfrm_wst_bin_prsnt_dly>4))
                    {
                        snsr_sw_rdy_flg=SET;
                        snsr_sw_id=6;
                    }
                    break;
                case 6:         //Trash bin placed sw test cases
                    switch(sensr_sw_ft_case_id)
                    {
                        case 1:         //remove trash bin
                            if((wast_bin_prsnt_sw)AND(cnfrm_wst_bin_not_prsnt_dly>4))
                                sensr_sw_ft_stp_complt_flg=SET;
                            break;
                        case 2:         //place trash bin
                            if((!wast_bin_prsnt_sw)AND(cnfrm_wst_bin_prsnt_dly>4))
                            {
                                sensr_sw_ft_stp_complt_flg=SET;
                                sensr_sw_ft_tst_done_flg=beep_sound_flg=SET;
                                snsr_sw_id=0;
                                snsr_sw_ft_initiate_flg=CLEAR_1;
                            }
                            break;
                    }
                    break;
                case 7:         //Trash bin full sw - check which is already full
                    if((!waste_bin_full)AND(cnfrm_wst_bin_ful_dly>4))
                        snsr_sw_popup_flg=SET;
                    snsr_sw_id=8;
                    break;
                case 8:         //verify the trash is empty
                    if((waste_bin_full)AND(cnfrm_wst_bin_empt_dly>4))
                    {
                        snsr_sw_rdy_flg=SET;
                        snsr_sw_id=9;
                    }
                    break;
                case 9:          //Trash bin full sw - test cases
                    switch(sensr_sw_ft_case_id)
                    {
                        case 1:         //move trash bin the trash bin full switch
                            if((!waste_bin_full)AND(cnfrm_wst_bin_ful_dly>4))
                                sensr_sw_ft_stp_complt_flg=SET;
                            break;
                        case 2:         //Release the trash bin full switch
                            if((waste_bin_full)AND(cnfrm_wst_bin_empt_dly>4))
                            {
                                sensr_sw_ft_stp_complt_flg=SET;
                                sensr_sw_ft_tst_done_flg=beep_sound_flg=SET;
                                snsr_sw_id=0;
                                snsr_sw_ft_initiate_flg=CLEAR_1;
                            }
                            break;
                    }
                    break;
                case 10:         //paper present sw - check if the paper is already placed
                    if((!filter_paper_present)AND(ppr_prsnt_cnfrm_dly>4))
                        snsr_sw_popup_flg=SET;
                    snsr_sw_id=11;
                    break;
                case 11:        //verify the paper is removed
                    if((filter_paper_present)AND(confrm_no_paper_dly>4))
                    {
                        snsr_sw_rdy_flg=SET;
                        snsr_sw_id=12;
                    }
                    break;
                case 12:    //paper present sw - test cases
                    switch(sensr_sw_ft_case_id)
                    {
                        case 1:         //move paper present switch
                            if((!filter_paper_present)AND(ppr_prsnt_cnfrm_dly>4))
                                sensr_sw_ft_stp_complt_flg=SET;
                            break;
                        case 2:         //Release the paper present switch
                            if((filter_paper_present)AND(confrm_no_paper_dly>4))
                            {
                                sensr_sw_ft_stp_complt_flg=SET;
                                snsr_sw_id=0;
                                snsr_sw_ft_initiate_flg=CLEAR_1;
                                sensr_sw_ft_tst_done_flg=beep_sound_flg=SET;
                            }
                            break;
                    }
                    break;
            }
        }
        else
        {
            exit_snsr_sw_tst_flg=snsr_sw_ft_initiate_flg=CLEAR_1;
            sensr_sw_ft_id=sensr_sw_ft_case_id=snsr_sw_id=0;
        }
    }
}
