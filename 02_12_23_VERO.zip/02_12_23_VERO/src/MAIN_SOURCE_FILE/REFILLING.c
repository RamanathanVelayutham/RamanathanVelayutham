/*
 * REFILLING.c
 *
 *  Created on: 19-Dec-2022
 *      Author: afila
 */
#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void air_break_refilling();
void espresso_boiler_fill();
void repressurise_pump();
void air_break_lvl1_pwm();
void air_break_lvl2_pwm();


/*
1. check the air break level min & max. if max lvl detected, but min lvl does not detected need to send a critical error.
2. only on inlet valve when water reach below min.
3. if, water filling is start need to display. Espresso boiler is filling(blocked error), based on the screen fun id will be change
4. water need to reach the min lvl below 2minutes, else need to send a error "espresso boiler stopped filling"(critical error)
5. if, reach time then need to calculate the time between min & max lvl, which is reach below 30 sec, else same critical error will be send.
6. if, reach in time then need to start the espresso boiler filling for inialization only.
*/
void air_break_refilling()
{
    if((!drip_lvl_chk_flag)AND(!entered_fctry_tst_flg))
    {
        if((!ar_brk_min_flg)OR(!ar_brk_max_flg))      //checking lvl reached?
        {
            if((ar_brk_min_flg)AND(!ar_brk_max_flg))      //max detected, min doesnot detected need to send a critical error.
            {
                esp_blr_flng_cmplt_snd_flg=SET;
                es_sys_err_snd_flg=Machine_err_flag=SET;
                ALL_OUT_OFF;
                one_tm_cntr_plc_err_snd_flg=container_plcd_flg=need_clr_aftr_ar_fl_flg=CLEAR_1;
                ar_brk_min_cnt_flg=ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=CLEAR_1;
                start_es_boilr_fill_flg=one_tm_blr_fl_snd_flg=CLEAR_1;
                init_es_htr_strt_flg=init_air_break_only_flg=CLEAR_1;
                ar_brk_min_cnt=ar_brk_max_cnt=0;
            }
            if(ar_brk_fil_strt_flg)
            {
                if((!ar_brk_min_flg)AND(ar_brk_max_flg)AND(ar_brk_min_cnt<120))
                {
                    if((!ar_brk_max_cnt_flg)AND(ar_brk_min_cnt_flg)AND(ar_brk_min_cnfrm_dly>=4))
                    {
                        ar_brk_min_cnfrm_dly=0;
                        ar_brk_min_cnt_flg=CLEAR_1;
                        ar_brk_min_cnt=0;
                        ar_brk_max_cnt_flg=SET;
                    }
                    else if(ar_brk_max_cnt>30)      //send a critical error for max reach in time
                    {
                        esp_blr_flng_cmplt_snd_flg=SET;
                        esp_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
                        ALL_OUT_OFF;
                        one_tm_cntr_plc_err_snd_flg=container_plcd_flg=need_clr_aftr_ar_fl_flg=CLEAR_1;
                        ar_brk_min_cnt_flg=ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=CLEAR_1;
                        start_es_boilr_fill_flg=one_tm_blr_fl_snd_flg=CLEAR_1;
                        init_es_htr_strt_flg=init_air_break_only_flg=CLEAR_1;
                        ar_brk_min_cnt=ar_brk_max_cnt=0;
                    }
                }
                else
                {
                    if((!ar_brk_min_flg)AND(!ar_brk_max_flg)AND(ar_brk_max_cnt<30)AND(ar_brk_fl_cnfm_dly>4)) //confirm in 200 msec
                    {
                        if(ar_brk_inlt_vlv_flg)
                        {
                            AIR_BREAK_INLET_VALVE_OFF;              //init flag set, don't possible to send a esp fll after air break fill
                            esp_blr_flng_cmplt_snd_flg=init_flag?CLEAR_1:((need_clr_aftr_ar_fl_flg)?(need_clr_aftr_ar_fl_flg=CLEAR_1,SET):CLEAR_1);
                            stop_at_current_cup_for_ar_brk_flg=CLEAR_1;
                            ar_brk_fl_cnfm_dly=ar_brk_max_cnt=0;
                            ar_brk_fil_strt_flg=ar_brk_max_cnt_flg=CLEAR_1;
                            one_tm_blr_fl_snd_flg=init_air_break_only_flg?SET:CLEAR_1;
                            start_es_boilr_fill_flg=((init_flag)AND(!init_air_break_only_flg))?SET:CLEAR_1; // Need start espresso boiler filling during initialization
                            init_es_htr_strt_flg=init_air_break_only_flg?(init_air_break_only_flg=CLEAR_1,SET):CLEAR_1;
                        }
                    }
                }
            }
            else         //when cleared the init flag that case we need clear the one tm blr_snd_flg
            {
                if((!ar_brk_min_flg)AND(ar_brk_max_flg)AND(!ar_brk_inlt_vlv_flg))
                {
                    if(ar_brk_min_cnfrm_dly>=4)
                    {
                        AIR_BREAK_INLET_VALVE_ON;
                        ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=SET;
                        if((init_flag)AND(!start_es_boilr_fill_flg))
                        {
                            eprs_blr_flng_snd_flg=SET;
                            init_air_break_only_flg=SET;
                        }
                    }
                }
                else if((!ar_brk_min_flg)AND(!ar_brk_max_flg)AND(!one_tm_blr_fl_snd_flg)AND(!start_es_boilr_fill_flg)AND((init_flag)))
                {
                    if(ar_brk_fl_cnfm_dly>=4)
                    init_es_htr_strt_flg=one_tm_blr_fl_snd_flg=SET; //=esp_blr_flng_cmplt_snd_flg
                }
            }
        }
        else                        //air break below min
        {
            if(ar_brk_min_cnt>=120)     //min did not reach in time send error.
            {
                esp_blr_flng_cmplt_snd_flg=SET;
                esp_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
                ALL_OUT_OFF;
                one_tm_cntr_plc_err_snd_flg=container_plcd_flg=need_clr_aftr_ar_fl_flg=CLEAR_1;
                ar_brk_min_cnt_flg=ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=CLEAR_1;
                start_es_boilr_fill_flg=one_tm_blr_fl_snd_flg=CLEAR_1;
                init_es_htr_strt_flg=init_air_break_only_flg=CLEAR_1;
                ar_brk_min_cnt=ar_brk_max_cnt=0;
            }
            else if((ar_brk_emt_cnfrm_dly>=4)AND((!ar_brk_inlt_vlv_flg)OR(ar_brk_max_cnt_flg)))      //confirm in 200 msec
            {
                if(init_flag?container_plcd_flg:1)
                {
                    if(!multicup_start_flag?1:proceed_refill_ar_brk_flg)           //during multicup, if the level goes below. stop at current cup. and complete refill, then only continue
                    {
                        AIR_BREAK_INLET_VALVE_ON;
                        one_tm_cntr_plc_err_snd_flg=proceed_refill_ar_brk_flg=CLEAR_1;
                        if(ar_brk_max_cnt_flg)   //during run time, first max reduced then goes below the min level
                        {
                            ar_brk_max_cnt=0;
                            ar_brk_max_cnt_flg=CLEAR_1;
                            ar_brk_min_cnt_flg=SET;
                        }
                        ar_brk_min_cnt_flg=ar_brk_fil_strt_flg=SET;
                        if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag)?1:multicup_start_flag)               // for multicup only, we need to send the error
                        eprs_blr_flng_snd_flg=need_clr_aftr_ar_fl_flg=SET;
                    }
                    else if(!stop_at_current_cup_for_ar_brk_flg)
                        stop_at_current_cup_for_ar_brk_flg=SET;
                }
                else if((!one_tm_cntr_plc_err_snd_flg)AND(init_flag))
                    plc_container_undr_outlet_snd_flg=one_tm_cntr_plc_err_snd_flg=SET;
            }
        }
    }
    else
    {
        if(ar_brk_inlt_vlv_flg)
        {
            esp_blr_flng_cmplt_snd_flg=SET;
            AIR_BREAK_INLET_VALVE_OFF;
        }
        one_tm_cntr_plc_err_snd_flg=container_plcd_flg=need_clr_aftr_ar_fl_flg=CLEAR_1;
        ar_brk_min_cnt_flg=ar_brk_max_cnt_flg=ar_brk_fil_strt_flg=CLEAR_1;
        start_es_boilr_fill_flg=one_tm_blr_fl_snd_flg=CLEAR_1;
        init_es_htr_strt_flg=init_air_break_only_flg=CLEAR_1;
        ar_brk_min_cnt=ar_brk_max_cnt=0;
    }
}

/*
1. on 3wayvalve and pump and err count also on.
2. till that time all pulse didn't get need to send a error.
3. all pulse get below err count need to off pump -5sec delay - off 3way valve, then move the brewer to fill position, then start boiler heating
*/

void espresso_boiler_fill()
{
    if(drnk_genral_set[flow_puls_puls_err_en]?es_flow_count_sec<drnk_genral_set[flow_puls_puls_sec]:1)
    {
        if((backup_flow_cnt!=es_flw_cnt)AND((three_way_vlv_flg)AND(presure_pump_flg)))
        {
            es_flow_count_sec=0;
            backup_flow_cnt=es_flw_cnt;
        }
        else if(((!three_way_vlv_flg)AND(!presure_pump_flg))OR(emt_blr_seq_strt_flg))
            es_flow_count_sec=0;
    }
    else
    {
        ALL_OUT_OFF;
        esp_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
        es_brwr_in_brw_pos_flg=es_boiler_fill_strt_flg=CLEAR_1;
        es_flw_cnt=es_brwr_flw_err_cnt=0;
    }
    if(!drip_lvl_chk_flag)
    {
        if(start_es_boilr_fill_flg)
        {
            if(es_brwr_in_brw_pos_flg)
            {
                if(es_boiler_fill_strt_flg)
                {
                    if(es_brwr_flw_err_cnt<180)         //3 minutes
                    {
                        if(es_flw_cnt<=0)
                        {
                            if((dly_pmp_3vlv<=0)AND(!presure_pump_flg))
                            {
                                if(three_way_vlv_flg)
                                THREE_WAY_VALVE_OFF;
                                if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                                {
                                    ESPRESSO_BREWER_OFF;
                                    esp_blr_flng_cmplt_snd_flg=one_tm_blr_fl_snd_flg=SET;
                                    start_es_boilr_fill_flg=es_boiler_fill_strt_flg=es_brwr_in_brw_pos_flg=container_plcd_flg=CLEAR_1;
                                    es_brwr_flw_err_cnt=0;
                                    init_es_htr_strt_flg=SET;
                                }
                                else if(!es_brwr_mtr_flg)
                                ESPRESSO_BREWER_ON;
                            }
                            else if(presure_pump_flg)
                            {
                                PRESSURE_PUMP_OFF;
                                dly_pmp_3vlv=50;
                                es_brwr_flw_err_cnt=0;
                            }
                        }
                    }
                    else
                    {
                        esp_blr_flng_cmplt_snd_flg=SET;
                        ALL_OUT_OFF;
                        esp_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
                        es_brwr_in_brw_pos_flg=es_boiler_fill_strt_flg=CLEAR_1;
                        es_flw_cnt=es_brwr_flw_err_cnt=0;
                    }
                }
                else
                {
                    if((!three_way_vlv_flg)AND(!presure_pump_flg))
                    {
                        es_boiler_fill_strt_flg=SET;
                        bckup_es_flw_cnt=drnk_genral_set[vlm_of_es_blr];
                        bckup_es_flw_cnt/=1000;
                        bckup_es_flw_cnt*=drnk_genral_set[flw_mtr_puls_per_lit];
                        es_flw_cnt=1.1*bckup_es_flw_cnt;
                        THREE_WAY_VALVE_ON;
                        PRESSURE_PUMP_ON;
                    }
                }
            }
            else
            {
                if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
                {
                    if(es_brwr_mtr_flg)
                    ESPRESSO_BREWER_OFF;
                    es_brwr_in_brw_pos_flg=SET;
                }
                else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
                ESPRESSO_BREWER_ON;
            }
        }
    }
    else
    {
        if(ar_brk_inlt_vlv_flg)
        esp_blr_flng_cmplt_snd_flg=SET;
        if(((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))OR((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4)))
        ESPRESSO_BREWER_OFF;
        if(three_way_vlv_flg)
        THREE_WAY_VALVE_OFF;
        if(presure_pump_flg)
        PRESSURE_PUMP_OFF;
        es_brwr_in_brw_pos_flg=CLEAR_1;
        es_flw_cnt=0;
        es_brwr_flw_err_cnt=0;
        es_boiler_fill_strt_flg=CLEAR_1;
    //    init_es_htr_strt_flg=CLEAR_1;
    }
}
/*
 * machine must be a espresso
 * repressure pump must enabled
 * count the time. if the time reach the set value we switch on the espresso pump.
 *  if the espresso drink or espresso brewer rinse mean we reset the count.
 */
void repressurise_pump()
{
    if(!entered_fctry_tst_flg)
    {
        if(drnk_genral_set[use_blr_perdc_reprsr])
        {
            if(reprsr_intrvl_time_count>=drnk_genral_set[perdc_reprsr_intrval])             // when espresso product take we need to reset the time
            {
                if((represr_pump_on_time<=0)AND(presure_pump_flg))
                    PRESSURE_PUMP_OFF,reprsr_intrvl_time_count=0;
                else if(!presure_pump_flg)
                {
                    PRESSURE_PUMP_ON;
                    represr_pump_on_time=drnk_genral_set[repsrsr_pump_on_time];
                }

            }
        }
    }
    else
    {
        PRESSURE_PUMP_OFF;
        reprsr_intrvl_time_count=represr_pump_on_time=0;
    }
}

/*
 * When flow meter is possible to count. Always we need to check time from the current pulse to the next pulse.
 * The time must be within the set time, else we need to show a critical error.
 *
 */

void air_break_lvl1_pwm() //called by 50usec ISR
{
    g_ioport.p_api->pinRead(IOPORT_PORT_00_PIN_14,&AIR_BRK_ROD_LVL1);
    air_break_rod_lvl_1_flg=AIR_BRK_ROD_LVL1?SET:CLEAR_1;
    static unsigned short air_brk_lvl1_pwm_on_time,
    air_brk_lvl1_internal_pwm_on_off_timer,air_brk_lvl1_internal_pwm_on_timer,air_brk_lvl1_internal_pwm_off_timer,
    air_brk_lvl1_open_conform_counter,air_brk_lvl1_close_conform_counter;
    static unsigned short air_brk_lvl1_pwm_off_time,air_brk_lvl1_pwm_on_off_timer;

    air_brk_lvl1_pwm_on_off_timer++;
    if(air_brk_lvl1_pwm_on_off_timer <= air_brk_lvl1_pwm_on_time)
    {
        AIR_BRK_LVL_1_PWM_ON;
    }
    else if(air_brk_lvl1_pwm_on_off_timer<=(air_brk_lvl1_pwm_on_time+air_brk_lvl1_pwm_off_time))
    {
        air_brk_lvl1_internal_pwm_on_off_timer++;
        if(air_brk_lvl1_internal_pwm_on_off_timer <= air_brk_lvl1_internal_pwm_on_timer)
        {
            AIR_BRK_LVL_1_PWM_OFF;
        }
        else if(air_brk_lvl1_internal_pwm_on_off_timer<=(air_brk_lvl1_internal_pwm_on_timer+air_brk_lvl1_internal_pwm_off_timer))
        {
            AIR_BRK_LVL_1_PWM_ON;
        }
        else
            air_brk_lvl1_internal_pwm_on_off_timer=0;
    }
    else
    {
        air_brk_lvl1_pwm_on_off_timer = 0;
        air_brk_lvl1_internal_pwm_on_off_timer=0;
    }
    air_brk_lvl1_pwm_on_time =60;//10;//60;
    air_brk_lvl1_pwm_off_time=9880;//9880;//9880;

    air_brk_lvl1_internal_pwm_on_timer=80;//20;//80;
    air_brk_lvl1_internal_pwm_off_timer=80;//80;

    if(air_break_rod_lvl_1_flg)
    {
        if(air_brk_lvl1_open_conform_counter<air_brk_lvl1_pwm_off_time)
            air_brk_lvl1_open_conform_counter++;
        air_brk_lvl1_close_conform_counter=0;
    }
    else
    {
        if(air_brk_lvl1_close_conform_counter<air_brk_lvl1_pwm_off_time)
            air_brk_lvl1_close_conform_counter++;
        air_brk_lvl1_open_conform_counter=0;
    }
    if(air_brk_lvl1_open_conform_counter>50)            // min level
    {
        ar_brk_min_flg=SET;
    }
    if(air_brk_lvl1_close_conform_counter>300)
    {
        ar_brk_min_flg=CLEAR_1;
    }
}

void air_break_lvl2_pwm() //called by 50usec ISR
{
    g_ioport.p_api->pinRead(IOPORT_PORT_05_PIN_01,&AIR_BRK_ROD_LVL2);
    air_break_rod_lvl_2_flg=AIR_BRK_ROD_LVL2?SET:CLEAR_1;
    static unsigned short air_brk_lvl2_pwm_on_time,
    air_brk_lvl2_internal_pwm_on_off_timer,air_brk_lvl2_internal_pwm_on_timer,air_brk_lvl2_internal_pwm_off_timer,
    air_brk_lvl2_open_conform_counter,air_brk_lvl2_close_conform_counter;
    static unsigned short air_brk_lvl2_pwm_off_time,air_brk_lvl2_pwm_on_off_timer;

    air_brk_lvl2_pwm_on_off_timer++;
    if(air_brk_lvl2_pwm_on_off_timer <= air_brk_lvl2_pwm_on_time)
    {
        AIR_BRK_LVL_2_PWM_ON;
    }
    else if(air_brk_lvl2_pwm_on_off_timer<=(air_brk_lvl2_pwm_on_time+air_brk_lvl2_pwm_off_time))
    {
        air_brk_lvl2_internal_pwm_on_off_timer++;
        if(air_brk_lvl2_internal_pwm_on_off_timer <= air_brk_lvl2_internal_pwm_on_timer)
        {
            AIR_BRK_LVL_2_PWM_OFF;
        }
        else if(air_brk_lvl2_internal_pwm_on_off_timer<=(air_brk_lvl2_internal_pwm_on_timer+air_brk_lvl2_internal_pwm_off_timer))
        {
            AIR_BRK_LVL_2_PWM_ON;
        }
        else
            air_brk_lvl2_internal_pwm_on_off_timer=0;
    }
    else
    {
        air_brk_lvl2_pwm_on_off_timer = 0;
        air_brk_lvl2_internal_pwm_on_off_timer=0;
    }
    air_brk_lvl2_pwm_on_time =60;//10;//60;
    air_brk_lvl2_pwm_off_time=9880;//9880;//9880;

    air_brk_lvl2_internal_pwm_on_timer=80;//20;//80;
    air_brk_lvl2_internal_pwm_off_timer=80;//80;

    if(air_break_rod_lvl_2_flg)
    {
        if(air_brk_lvl2_open_conform_counter<air_brk_lvl2_pwm_off_time)
            air_brk_lvl2_open_conform_counter++;
        air_brk_lvl2_close_conform_counter=0;
    }
    else
    {
        if(air_brk_lvl2_close_conform_counter<air_brk_lvl2_pwm_off_time)
            air_brk_lvl2_close_conform_counter++;
        air_brk_lvl2_open_conform_counter=0;
    }
    if(air_brk_lvl2_open_conform_counter>50)     // max level
    {
        ar_brk_max_flg=SET;
    }
    if(air_brk_lvl2_close_conform_counter>300)
    {
        ar_brk_max_flg=CLEAR_1;
    }
}

