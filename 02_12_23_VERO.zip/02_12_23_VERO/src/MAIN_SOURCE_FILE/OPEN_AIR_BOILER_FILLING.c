/*
 * OPEN_AIR_BOILER_FILLING.c
 *
 *  Created on: 29-Dec-2022
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"

void water_lvl2_pwm();
void water_lvl1_pwm();
void open_air_boiler_filling();

/*
 * 1. when open air boiler water level goes under min level then only we need to on inlet valve.
 * 2. water level will reach min level in 10 min else need to send a critical error.
 * 3. from min to max water will reach with 30 sec else need to send a critical error.
 * 4. if, max only detect min did not detected that case we need send a critical error too.
 */

void open_air_boiler_filling()
{
    if((!drip_lvl_chk_flag)AND(!opn_blr_sys_test_initated_flg))
    {
        if((!blr_lvl1_wtr_flg)OR(!blr_lvl2_wtr_flg))      //checking lvl reached?
        {
            if((blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg))      //max detected, min doesnot detected need to send a critical error.
            {
                opn_blr_flng_done_snd_flg=SET;
                ALL_OUT_OFF;
                air_blr_sys_err_snd_flg=Machine_err_flag=SET;
                opn_blr_fil_strt_flg=opn_blr_min_cnt_flg=opn_blr_max_cnt_flg=need_clr_aftr_opn_blr_fl_flg=CLEAR_1;
                init_opn_brl_htr_start_flg=one_tm_open_blr_fl_snd_flg=CLEAR_1;
                opn_blr_max_cnt=opn_blr_min_cnt=0;
            }
            if(opn_blr_fil_strt_flg)
            {
                if((!blr_lvl1_wtr_flg)AND(blr_lvl2_wtr_flg)AND(opn_blr_min_cnt<600))
                {
                    if((!opn_blr_max_cnt_flg)AND(opn_blr_min_cnt_flg)AND(opn_blr_min_cnfrm_dly>=30))
                    {
                        opn_blr_flng_done_snd_flg=init_flag?CLEAR_1:SET;          //APART FROM INIT WE NEED TO CLEAR THE BLOCKING WHEN THE LEVEL REACHED THE MIN
                        opn_blr_min_cnfrm_dly=0;
                        opn_blr_min_cnt_flg=CLEAR_1;
                        opn_blr_min_cnt=0;
                        opn_blr_max_cnt_flg=SET;
                    }
                    else if(opn_blr_max_cnt>30)      //send a critical error for max reach in time
                    {
                        opn_blr_flng_done_snd_flg=SET;
                        ALL_OUT_OFF;
                        air_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
                        opn_blr_fil_strt_flg=opn_blr_min_cnt_flg=opn_blr_max_cnt_flg=need_clr_aftr_opn_blr_fl_flg=CLEAR_1;
                        init_opn_brl_htr_start_flg=one_tm_open_blr_fl_snd_flg=CLEAR_1;
                        opn_blr_max_cnt=opn_blr_min_cnt=0;
                    }
                }
                else
                {
                    if((!blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg)AND(opn_blr_max_cnt<30)AND(opn_blr_fl_cnfm_dly>30)) //confirm in 1.5sec
                    {
                        if(open_air_blr_inlet_vlv_flg)
                        {
                            OPEN_AIR_BOILER_INLET_VALVE_OFF;
                            stop_at_current_cup_for_opn_blr_flg=CLEAR_1;
                            opn_blr_fl_cnfm_dly=0;
                            opn_blr_fil_strt_flg=CLEAR_1;
                            opn_blr_max_cnt_flg=CLEAR_1;
                            opn_blr_max_cnt=0;
                            if(!entered_fctry_tst_flg)
                            opn_blr_flng_done_snd_flg=need_clr_aftr_opn_blr_fl_flg?one_tm_open_blr_fl_snd_flg=init_opn_brl_htr_start_flg=SET,need_clr_aftr_opn_blr_fl_flg=CLEAR_1,SET:CLEAR_1;
                        }
                    }
                }
            }
            else         //when cleared the init flag that case we need clear the one tm blr_snd_flg
            {
                if((!blr_lvl1_wtr_flg)AND(blr_lvl2_wtr_flg)AND(!open_air_blr_inlet_vlv_flg))
                {
                    OPEN_AIR_BOILER_INLET_VALVE_ON;
                    opn_blr_max_cnt_flg=opn_blr_fil_strt_flg=SET;
                    if((init_flag)AND(!entered_fctry_tst_flg))
                    opn_blr_flng_snd_flg=SET;
                }
                else if((!blr_lvl1_wtr_flg)AND(!blr_lvl2_wtr_flg)AND(!one_tm_open_blr_fl_snd_flg)AND(init_flag)AND(!entered_fctry_tst_flg))
                {
                    one_tm_open_blr_fl_snd_flg=init_opn_brl_htr_start_flg=SET; //opn_blr_flng_done_snd_flg=
                }
            }
        }
        else                        //Open boiler below min
        {
            if(opn_blr_min_cnt>=600)     //min did not reach in time send error.
            {
                opn_blr_flng_done_snd_flg=SET;
                ALL_OUT_OFF;
                air_blr_stp_flng_er_snd_flg=Machine_err_flag=SET;
                opn_blr_fil_strt_flg=opn_blr_min_cnt_flg=opn_blr_max_cnt_flg=need_clr_aftr_opn_blr_fl_flg=CLEAR_1;
                init_opn_brl_htr_start_flg=one_tm_open_blr_fl_snd_flg=CLEAR_1;
                opn_blr_max_cnt=opn_blr_min_cnt=0;
            }
            else if(open_blr_empt_cnfrm_dly>=30)        //confirm in 1.5 sec
            {
                if((!open_air_blr_inlet_vlv_flg)OR(opn_blr_max_cnt_flg))
                {
                    if(!multicup_start_flag?1:proceed_refill_opn_blr_flg)           //during multicup, if the level goes below. stop at current cup. and complete refill, then only continue
                    {
                        OPEN_AIR_BOILER_INLET_VALVE_ON;
                        proceed_refill_opn_blr_flg=CLEAR_1;
                        if(opn_blr_max_cnt_flg)
                        {
                            opn_blr_max_cnt_flg=CLEAR_1;
                            opn_blr_max_cnt=0;
                            opn_blr_min_cnt_flg=SET;
                        }
                        opn_blr_min_cnt_flg=opn_blr_fil_strt_flg=SET;
                        if((!process_initiated_flag)AND(!secondary_outlet_process_init_flag)?1:multicup_start_flag)
                        {
                            if(!entered_fctry_tst_flg)
                            opn_blr_flng_snd_flg=need_clr_aftr_opn_blr_fl_flg=SET;
                        }
                    }
                    else if(!stop_at_current_cup_for_opn_blr_flg)
                        stop_at_current_cup_for_opn_blr_flg=SET;
                }
            }
        }
    }
    else if(!block_for_opn_blr_tst)
    {
        if(open_air_blr_inlet_vlv_flg)
        {
            opn_blr_flng_done_snd_flg=SET;
            OPEN_AIR_BOILER_INLET_VALVE_OFF;
        }
        opn_blr_fil_strt_flg=opn_blr_min_cnt_flg=opn_blr_max_cnt_flg=need_clr_aftr_opn_blr_fl_flg=CLEAR_1;
        init_opn_brl_htr_start_flg=one_tm_open_blr_fl_snd_flg=CLEAR_1;
        opn_blr_max_cnt=opn_blr_min_cnt=0;
    }
}

void water_lvl1_pwm() //called by 50usec ISR
{
    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_04,&OPEN_AIR_BOILER_WTR_LVL1);
    open_air_blr_lvl_1_flg=OPEN_AIR_BOILER_WTR_LVL1?SET:CLEAR_1;
    static unsigned short lvl1_pwm_on_time,
    lvl1_internal_pwm_on_off_timer,lvl1_internal_pwm_on_timer,lvl1_internal_pwm_off_timer,
    lvl1_open_conform_counter,lvl1_close_conform_counter;
    static unsigned short lvl1_pwm_off_time,lvl1_pwm_on_off_timer;

    lvl1_pwm_on_off_timer++;
    if(lvl1_pwm_on_off_timer <= lvl1_pwm_on_time)
    {
        WAT_LVL_1_PWM_ON;
    }
    else if(lvl1_pwm_on_off_timer<=(lvl1_pwm_on_time+lvl1_pwm_off_time))
    {
        lvl1_internal_pwm_on_off_timer++;
        if(lvl1_internal_pwm_on_off_timer <= lvl1_internal_pwm_on_timer)
        {
            WAT_LVL_1_PWM_OFF;
            //LVL1_PWM_OFF;
        }
        else if(lvl1_internal_pwm_on_off_timer<=(lvl1_internal_pwm_on_timer+lvl1_internal_pwm_off_timer))
        {
            WAT_LVL_1_PWM_ON;
            //LVL1_PWM_ON;
        }
        else
        lvl1_internal_pwm_on_off_timer=0;
    }
    else
    {
        lvl1_pwm_on_off_timer = 0;
        lvl1_internal_pwm_on_off_timer=0;
    }
    lvl1_pwm_on_time =60;//10;//60;
    lvl1_pwm_off_time=9880;//9880;//9880;

    lvl1_internal_pwm_on_timer=80;//20;//80;
    lvl1_internal_pwm_off_timer=80;//80;

    if(open_air_blr_lvl_1_flg)
    {
        if(lvl1_open_conform_counter<lvl1_pwm_off_time)
        lvl1_open_conform_counter++;
        lvl1_close_conform_counter=0;
    }
    else
    {
        if(lvl1_close_conform_counter<lvl1_pwm_off_time)
        lvl1_close_conform_counter++;
        lvl1_open_conform_counter=0;
    }
    if(lvl1_open_conform_counter>50)
    {
        blr_lvl1_wtr_flg=SET;
    }
    if(lvl1_close_conform_counter>300)
    {
        blr_lvl1_wtr_flg=CLEAR_1;
    }

}

void water_lvl2_pwm() //called by 50usec ISR
{

    g_ioport.p_api->pinRead(IOPORT_PORT_06_PIN_03,&OPEN_AIR_BOILER_WTR_LVL2);
    open_air_blr_lvl_2_flg=OPEN_AIR_BOILER_WTR_LVL2?SET:CLEAR_1;
    static unsigned char lvl2_pwm_on_time,
    lvl2_internal_pwm_on_off_timer,lvl2_internal_pwm_on_timer,lvl2_internal_pwm_off_timer,
    lvl2_open_conform_counter,lvl2_close_conform_counter;
    static unsigned short lvl2_pwm_off_time,lvl2_pwm_on_off_timer;

    lvl2_pwm_on_off_timer++;
    if(lvl2_pwm_on_off_timer <= lvl2_pwm_on_time)
    {
        WAT_LVL_2_PWM_ON;
    }
    else if(lvl2_pwm_on_off_timer<=(lvl2_pwm_on_time+lvl2_pwm_off_time))
    {
        lvl2_internal_pwm_on_off_timer++;
        if(lvl2_internal_pwm_on_off_timer <= lvl2_internal_pwm_on_timer)
        {
            WAT_LVL_2_PWM_OFF;
        }
        else if(lvl2_internal_pwm_on_off_timer<=(lvl2_internal_pwm_on_timer+lvl2_internal_pwm_off_timer))
        {
            WAT_LVL_2_PWM_ON;
        }
        else
        lvl2_internal_pwm_on_off_timer=0;
    }
    else
    {
        lvl2_pwm_on_off_timer = 0;
        lvl2_internal_pwm_on_off_timer=0;
    }
    lvl2_pwm_on_time =60;//39040;//60;
    lvl2_pwm_off_time =9880;//480;//9880;

    lvl2_internal_pwm_on_timer=80;
    lvl2_internal_pwm_off_timer=80;

    if(open_air_blr_lvl_2_flg)
    {
        if(lvl2_open_conform_counter<lvl2_pwm_off_time)
        lvl2_open_conform_counter++;
        lvl2_close_conform_counter=0;
    }
    else
    {
        if(lvl2_close_conform_counter<lvl2_pwm_off_time)
        lvl2_close_conform_counter++;
        lvl2_open_conform_counter=0;
    }
    if(lvl2_open_conform_counter>50)
    {
        blr_lvl2_wtr_flg=SET;
    }
    if(lvl2_close_conform_counter>200)
    {
        blr_lvl2_wtr_flg=CLEAR_1;
    }

}

