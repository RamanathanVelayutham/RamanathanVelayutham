/*
 * PRIMIX_MOTOR.c
 *
 *  Created on: 07-Jan-2023
 *      Author: afila
 */
#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void powder_motor_fun(unsigned char );
void prmx1_rpm();
void prmx2_rpm();
void prmx3_rpm();
void prmx4_rpm();
void prmx5_rpm();
void prmx6_rpm();

void powder_motor_fun(unsigned char prmx_ch)
{
    if(!ch_flags[prmx_ch].prmx_prcs_cmplt)
    {
        if(ch_process[prmx_ch].prmx_dly<=0)
        {
            if(ch_tmr[prmx_ch].prcs_prmx_dly<=0)
            {
                if((ch_process[prmx_ch].prmx_time<=0)AND(ch_process[prmx_ch].prmx_on_of_cnt>0))
                {
                    if((ch_tmr[prmx_ch].prmx_off_time<=0)AND(!ch_flags[prmx_ch].one_time_prmx_flag))
                    {
                       switch(prmx_ch)
                       {
                           case 1:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==1)
                                       PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR1_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx1_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                           case 2:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==2)
                                       PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR2_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx2_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                           case 3:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==3)
                                      PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR3_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx3_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                           case 4:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==4)
                                     PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR4_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx4_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                           case 5:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==5)
                                     PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR5_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx5_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                           case 6:
                               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(ch_process[channel[prmx_ch]].wtr_time==0)?((back_up[channel[prmx_ch]].backup_wtr_on_time>0)AND(ch_process[channel[prmx_ch]].wtr_on_off_cnt>0)):1)
                               {
                                   if(liquid_choco_ch==6)
                                     PERISTALTIC_PUMP_ON;
                                   else
                                       PRIMIX_MOTOR6_ON;
                                   ch_flags[prmx_ch].one_time_prmx_flag=start_prmx6_pwm_flag=SET;
                               }
                               else
                               {
                                   ch_process[prmx_ch].prmx_on_of_cnt=1;
                                   goto PREMIX_OFF;
                               }
                               break;
                       }
                       ch_tmr[prmx_ch].prmx_on_time=back_up[prmx_ch].backup_prmx_on_time;
                    }
                    else if((ch_tmr[prmx_ch].prmx_on_time<=0)AND(ch_flags[prmx_ch].one_time_prmx_flag))
                    {
                        PREMIX_OFF:
                        switch(prmx_ch)
                       {
                           case 1:
                               if(liquid_choco_ch==1)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR1_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx1_pwm_flag=CLEAR_1;
                               break;
                           case 2:
                               if(liquid_choco_ch==2)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR2_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx2_pwm_flag=CLEAR_1;
                               break;
                           case 3:
                               if(liquid_choco_ch==3)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR3_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx3_pwm_flag=CLEAR_1;
                               break;
                           case 4:
                               if(liquid_choco_ch==4)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR4_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx4_pwm_flag=CLEAR_1;
                               break;
                           case 5:
                               if(liquid_choco_ch==5)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR5_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx5_pwm_flag=CLEAR_1;
                               break;
                           case 6:
                               if(liquid_choco_ch==6)
                                   PERISTALTIC_PUMP_OFF;
                               else
                                   PRIMIX_MOTOR6_OFF;
                               ch_flags[prmx_ch].one_time_prmx_flag=start_prmx6_pwm_flag=CLEAR_1;
                               break;
                       }
                       ch_tmr[prmx_ch].prmx_off_time=back_up[prmx_ch].backup_prmx_off_time;
                       ch_process[prmx_ch].prmx_on_of_cnt--;
                       ch_flags[prmx_ch].prmx_prcs_cmplt=(ch_process[prmx_ch].prmx_on_of_cnt==0)?ch_process[prmx_ch].prmx_rpm=back_up[prmx_ch].backup_prmx_on_time=back_up[prmx_ch].backup_prmx_off_time=0,SET:CLEAR_1;
                    }
                }
                else
                {
//                    if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(drk_main_sett[drink_id][main_prdt_ch]==prmx_ch))
//                        ch_process[prmx_ch].prmx_time=back_up_time_for_prmx_time;

                    ch_process[prmx_ch].prmx_on_of_cnt=ch_process[prmx_ch].prmx_puls_no;     //(ch_process[prmx_ch].prmx_puls_no>0)?++ch_process[prmx_ch].prmx_puls_no:1;
                    back_up[prmx_ch].backup_prmx_on_time=ch_process[prmx_ch].prmx_time/ch_process[prmx_ch].prmx_on_of_cnt;
                    back_up[prmx_ch].backup_prmx_off_time=(ch_process[prmx_ch].prmx_puls_no>1)?ch_process[prmx_ch].prmx_puls_time:0;
                    ch_process[prmx_ch].prmx_time=ch_process[prmx_ch].prmx_puls_no=ch_process[prmx_ch].prmx_puls_time=0;
                }

            }
        }
        else
        {
            ch_tmr[prmx_ch].prcs_prmx_dly=ch_process[prmx_ch].prmx_dly;
            ch_process[prmx_ch].prmx_dly=0;
        }
    }
}

void prmx1_rpm()
{
    if((prmx1_pwm_off<=0)AND((liquid_choco_ch==1)?(!prstltc_pmp_flg):(!prmx1_on_flg)))
    {
        if(liquid_choco_ch==1)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR1_ON;
        prmx1_pwm_on=ch_process[1].prmx_rpm;
    }
    else if((prmx1_pwm_on<=0)AND((liquid_choco_ch==1)?(prstltc_pmp_flg):(prmx1_on_flg)))
    {
        if(liquid_choco_ch==1)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR1_OFF;
        prmx1_pwm_off=100-ch_process[1].prmx_rpm;
    }
}
void prmx2_rpm()
{
    if((prmx2_pwm_off<=0)AND((liquid_choco_ch==2)?(!prstltc_pmp_flg):(!prmx2_on_flg)))
    {
        if(liquid_choco_ch==2)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR2_ON;
        prmx2_pwm_on=ch_process[2].prmx_rpm;
    }
    else if((prmx2_pwm_on<=0)AND((liquid_choco_ch==2)?(prstltc_pmp_flg):(prmx2_on_flg)))
    {
        if(liquid_choco_ch==2)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR2_OFF;
        prmx2_pwm_off=100-ch_process[2].prmx_rpm;
    }
}
void prmx3_rpm()
{
    if((prmx3_pwm_off<=0)AND((liquid_choco_ch==3)?(!prstltc_pmp_flg):(!prmx3_on_flg)))
    {
        if(liquid_choco_ch==3)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR3_ON;
        prmx3_pwm_on=ch_process[3].prmx_rpm;
    }
    else if((prmx3_pwm_on<=0)AND((liquid_choco_ch==3)?(prstltc_pmp_flg):(prmx3_on_flg)))
    {
        if(liquid_choco_ch==3)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR3_OFF;
        prmx3_pwm_off=100-ch_process[3].prmx_rpm;
    }
}
void prmx4_rpm()
{
    if((prmx4_pwm_off<=0)AND((liquid_choco_ch==4)?(!prstltc_pmp_flg):(!prmx4_on_flg)))
    {
        if(liquid_choco_ch==4)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR4_ON;
        prmx4_pwm_on=ch_process[4].prmx_rpm;
    }
    else if((prmx4_pwm_on<=0)AND((liquid_choco_ch==4)?(prstltc_pmp_flg):(prmx4_on_flg)))
    {
        if(liquid_choco_ch==4)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR4_OFF;
        prmx4_pwm_off=100-ch_process[4].prmx_rpm;
    }
}
void prmx5_rpm()
{
    if((prmx5_pwm_off<=0)AND((liquid_choco_ch==5)?(!prstltc_pmp_flg):(!prmx5_on_flg)))
    {
        if(liquid_choco_ch==5)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR5_ON;
        prmx5_pwm_on=ch_process[5].prmx_rpm;
    }
    else if((prmx5_pwm_on<=0)AND((liquid_choco_ch==5)?(prstltc_pmp_flg):(prmx5_on_flg)))
    {
        if(liquid_choco_ch==5)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR5_OFF;
        prmx5_pwm_off=100-ch_process[5].prmx_rpm;
    }
}
void prmx6_rpm()
{
    if((prmx6_pwm_off<=0)AND((liquid_choco_ch==6)?(!prstltc_pmp_flg):(!prmx6_on_flg)))
    {
        if(liquid_choco_ch==6)
            PERISTALTIC_PUMP_ON;
        else
            PRIMIX_MOTOR6_ON;
        prmx6_pwm_on=ch_process[6].prmx_rpm;
    }
    else if((prmx6_pwm_on<=0)AND((liquid_choco_ch==6)?(prstltc_pmp_flg):(prmx6_on_flg)))
    {
        if(liquid_choco_ch==6)
            PERISTALTIC_PUMP_OFF;
        else
            PRIMIX_MOTOR6_OFF;
        prmx6_pwm_off=100-ch_process[6].prmx_rpm;
    }
}
