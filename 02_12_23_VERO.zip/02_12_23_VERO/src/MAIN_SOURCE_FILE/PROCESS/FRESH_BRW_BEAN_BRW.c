/*
 * FRESH_BRW_BEAN_BRW.c
 *
 *  Created on: 17-Jan-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"

void fb_pwdr_fun();
void fresh_brewer();

void fb_pwdr_fun()
{
    if(!fb_wtr_complete_flg)
    {
        if((can_wtr_dly<=0)AND(can_wtr_dly_flg))
        {
            if((can_wtr_run_time<=0)AND(can_brwr_wtr_time_flg))
            {
                SOLENOID1_OFF;
                can_wtr_dly_flg=can_brwr_wtr_time_flg=CLEAR_1;
                fb_wtr_complete_flg=SET;
//                fb_diffrent_step_ch1_cmplt_flag=((!same_step_fb_flag)AND(double_cup_flag))?SET:CLEAR_1;
            }
            else if(!can_brwr_wtr_time_flg)
            {
                can_brwr_wtr_time_flg=SET;
                can_wtr_run_time=(other_than_instant[machine][drink_id][wtr_run_time]-wtr_blnc_fun(fresh_brew_canister_flg?8:9))*(mug_flag?mug_fn(drink_id):1);
                SOLENOID1_ON;
            }
        }
        else if(!can_wtr_dly_flg)
        {
            can_wtr_dly_flg=SET;
            can_wtr_dly=other_than_instant[machine][drink_id][wtr_dly_time];
        }
    }
    if(!fb_prmx_or_grndr_complete_flg)
    {
        if((fb_prmx_or_grndr_dly<=0)AND(fb_prmx_or_grndr_dly_flg))
        {
            if(((fb_prmx_or_grndr_run_time<=0)AND(fb_prmx_or_grndr_time_flg))OR(need_stop_drink_due_to_err_flg))
            {
                fb_prmx_or_grndr_run_time=0;
                fb_prmx_or_grndr_dly_flg=fresh_brew_canister_flg?(PRIMIX_MOTOR1_OFF,CLEAR_1):(BEAN_GRINDER_OFF,CLEAR_1);
                fb_prmx_or_grndr_dly_flg=bean_brew_grinder_flag=fresh_brew_canister_flg=fb_prmx_or_grndr_time_flg=CLEAR_1;
                fb_prmx_or_grndr_complete_flg=SET;
            }
            else if(!fb_prmx_or_grndr_time_flg)
            {
                fb_prmx_or_grndr_time_flg=fresh_brew_canister_flg?(PRIMIX_MOTOR1_ON,SET):(BEAN_GRINDER_ON,SET);
                fb_prmx_or_grndr_run_time=other_than_instant[machine][drink_id][premx_grndr_run_time]*(mug_flag?mug_fn(drink_id):1)*(check_strength(fresh_brew_canister_flg?8:9));
                //fb_prmx_or_grndr_run_time=other_than_instant[machine][drink_id][2]*(from_adjust_scrn_flg?(fresh_brew_canister_flg?frsh_brw_can_strength:bean_brw_strength):1);
            }
        }
        else if(!fb_prmx_or_grndr_dly_flg)
        {
            fb_prmx_or_grndr_dly_flg=SET;
            fb_prmx_or_grndr_dly=other_than_instant[machine][drink_id][premx_grndr_dly_time];
        }
    }
}

void fresh_brewer()
{
    if(!fresh_brew_brewer_complete_flg)
    {
       switch(fb_brewer_stops)
       {
           case BREWER_START_DELAY:
               if((fb_brwr_dly_strt_flg)AND(fb_brwr_strtng_dly<=0))
               {
                   fb_brwr_dly_strt_flg=CLEAR_1;
                   fb_brewer_stops++;
               }
               else if(!fb_brwr_dly_strt_flg)
               {
                   fb_brwr_strtng_dly=other_than_instant[machine][drink_id][brwr_dly_time];
                   fb_brwr_dly_strt_flg=SET;
               }
               break;
           case BREWER_STOP_1:
               if((fb_brwr_frst_run_flg)AND(fb_brwr_frst_run<=0))
               {
                   if(fresh_brewer_mtr_flg)
                   FRESH_BREWER_OFF;
                   if((fb_brwr_frst_stp_flg)AND(fb_brwr_frst_stp<=0))
                   {
                       fb_brwr_frst_stp_flg=fb_brwr_frst_run_flg=CLEAR_1;
                       fb_brewer_stops++;
                   }
                   else if(!fb_brwr_frst_stp_flg)
                   {
                       fb_brwr_frst_stp_flg=SET;
                       fb_brwr_frst_stp=other_than_instant[machine][drink_id][brwr_stp1];
                   }
               }
               else if(!fb_brwr_frst_run_flg)
               {
                   fb_brwr_frst_run_flg=SET;
                   FRESH_BREWER_ON;
                   fb_brwr_frst_run=other_than_instant[machine][drink_id][pos_1_stp];
               }
               break;
           case BREWER_STOP_2:
              if((fb_brwr_scnd_run_flg)AND(fb_brwr_scnd_run<=0))
              {
                  if(fresh_brewer_mtr_flg)
                  FRESH_BREWER_OFF;
                  if((fb_brwr_scnd_stp_flg)AND(fb_brwr_scnd_stp<=0))
                  {
                      fb_brwr_scnd_stp_flg=fb_brwr_scnd_run_flg=CLEAR_1;
                      fb_brewer_stops++;
                  }
                  else if(!fb_brwr_scnd_stp_flg)
                  {
                      fb_brwr_scnd_stp_flg=SET;
                      fb_brwr_scnd_stp=other_than_instant[machine][drink_id][brwr_stp2];
                  }
              }
              else if(!fb_brwr_scnd_run_flg)
              {
                  fb_brwr_scnd_run_flg=SET;
                  FRESH_BREWER_ON;
                  fb_brwr_scnd_run=other_than_instant[machine][drink_id][pos_2_stp];
              }
              break;
           case BREWER_STOP_3:
             if((fb_brwr_thrd_run_flg)AND(fb_brwr_thrd_run<=0))
             {
                 if(fresh_brewer_mtr_flg)
                 FRESH_BREWER_OFF;
                 if((fb_brwr_thrd_stp_flg)AND(fb_brwr_thrd_stp<=0))
                 {
                     fb_brwr_thrd_stp_flg=fb_brwr_thrd_run_flg=CLEAR_1;
                     fb_brewer_stops++;
                 }
                 else if(!fb_brwr_thrd_stp_flg)
                 {
                     fb_brwr_thrd_stp_flg=SET;
                     fb_brwr_thrd_stp=other_than_instant[machine][drink_id][brwr_stp3]*(mug_flag?mug_fn(drink_id):1);
                 }
             }
             else if(!fb_brwr_thrd_run_flg)
             {
                 fb_brwr_thrd_run_flg=SET;
                 FRESH_BREWER_ON;
                 fb_brwr_thrd_run=other_than_instant[machine][drink_id][pos_3_stp]*(mug_flag?mug_fn(drink_id):1);
             }
             break;
           case BREWER_STOP_4:
              if((fb_brwr_frth_run_flg)AND(fb_brwr_frth_run<=0))
              {
                  if(fresh_brewer_mtr_flg)
                      FRESH_BREWER_OFF;
                  if((fb_brwr_frth_stp_flg)AND(fb_brwr_frth_stp<=0))
                  {
                      fb_brwr_frth_stp_flg=fb_brwr_frth_run_flg=CLEAR_1;
                      if(!fb_home_pos_flg)
                      {
                          fb_brewer_stops=0;
                          fresh_brew_brewer_flag=CLEAR_1;
                          fresh_brew_brewer_complete_flg=SET;
//                          fb_diffrent_step_ch2_cmplt_flag=((!same_step_fb_flag)AND(double_cup_flag))?SET:CLEAR_1;
                      }
                      else
                      fb_brewer_stops++;
                  }
                  else if(!fb_brwr_frth_stp_flg)
                  {
                      fb_brwr_frth_stp_flg=SET;
                      fb_brwr_frth_stp=other_than_instant[machine][drink_id][brwr_stp4];
                  }
              }
              else if(!fb_brwr_frth_run_flg)
              {
                  fb_brwr_frth_run_flg=SET;
                  FRESH_BREWER_ON;
                  fb_brwr_frth_run=other_than_instant[machine][drink_id][pos_4_stp];
              }
                break;
           case FIND_HOME_POS:
               if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4))
               {
                   FRESH_BREWER_OFF;
                   fresh_brew_brewer_flag=CLEAR_1;
                   confrm_brwr_in_pos_dly=fb_brewer_stops=0;
                   fresh_brew_brewer_complete_flg=SET;
//                   fb_diffrent_step_ch2_cmplt_flag=((!same_step_fb_flag)AND(double_cup_flag))?SET:CLEAR_1;
               }
               else if((fb_home_pos_flg)AND(!fresh_brewer_mtr_flg))
                   FRESH_BREWER_ON;
               break;
       }
    }
}
