/*
 * SECONDARY_DRINK.c
 *
 *  Created on: 16-Feb-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"



void hot_cold_wtr_fun();
void secondary_outlet_drink();

void secondary_outlet_drink()
{
    if((stop_scndry_prdct_prcess)OR(need_stop_drink_due_to_err_flg))
        scnd_outlet_stages=SCNDARY_PR_COMPLETE;
    switch(scnd_outlet_stages)
    {
        case SCNDARY_DISPENSE:
            hot_cold_wtr_fun();
            break;
        case SCNDARY_DRIP_TIME:
            if((scndary_no_of_multicup<=0)OR(from_secondary_drink))
            {
                if((scondary_drip_time_start_flag)AND(scondary_process_drip_time<=0))
                    scondary_drip_time_start_flag=multicup_start_flag=CLEAR_1,scnd_outlet_stages++;

                else if(!scondary_drip_time_start_flag)
                {
                    if(scnd_drnk_last_cup_snd_flg)
                    {
                        scndry_multicup_completed_send_flag=SET;
                        scndry_send_cup++;
                    }
                    scondary_drip_time_start_flag=SET;
                    scondary_process_drip_time=drk_main_sett[scnd_drink_id][drip_time];
                }

            }
            else if((scndary_no_of_multicup>0)AND(!from_secondary_drink))
            {
               if((mltcup_pauz_time<=0)AND(mltcup_pauz_strt_flg))
               {
                   mltcup_pauz_strt_flg=CLEAR_1;
                   scnd_outlet_stages=SCNDARY_DISPENSE;
                   scndry_multicup_completed_send_flag=SET;
                   scndry_send_cup++;
               }
               else if(!mltcup_pauz_strt_flg)
               {
                   if((!stop_at_current_cup_for_ar_brk_flg)AND(!stop_at_current_cup_for_opn_blr_flg))
                   {
                       if((!snd_err_end_of_cup_opn_blr)AND(!snd_err_end_of_cup_es_blr))
                       {
                           if(scndary_no_of_multicup==1)
                               scnd_drnk_last_cup_snd_flg=SET;
                           scndary_no_of_multicup--;
                           if(scndary_no_of_multicup!=0)//because when value reach 0 we don't need to continue the process, we move to drip time
                           {
                               mltcup_pauz_strt_flg=SET;
                               mltcup_pauz_time=drk_main_sett[scnd_drink_id][pauz_time];
                           }
                       }
                       else if((snd_err_end_of_cup_opn_blr)AND(!one_tm_opn_blr_htng_snd_flg))
                       {
                           if(air_boiler_heater_on_flg)
                           {
                               if(ar_ctemp<=drnk_genral_set[min_op_temp])
                                   open_blr_htng_snd_flg=one_tm_opn_blr_htng_snd_flg=SET;
                               else
                                   snd_err_end_of_cup_opn_blr=CLEAR_1;
                           }
                           else
                               snd_err_end_of_cup_opn_blr=CLEAR_1;
                       }
                       else if((snd_err_end_of_cup_es_blr)AND(!one_tm_blr_htng_snd_flg))
                       {
                           if(espresso_heater_on_flg)
                           {
                               if(es_ctemp<=drnk_genral_set[es_min_op_temp])
                                   one_tm_blr_htng_snd_flg=es_blr_htng_snd_flg=SET;
                               else
                                   snd_err_end_of_cup_es_blr=CLEAR_1;
                           }
                           else
                               snd_err_end_of_cup_es_blr=CLEAR_1;
                       }
                   }
                   else if((!proceed_refill_ar_brk_flg)AND(stop_at_current_cup_for_ar_brk_flg))
                       proceed_refill_ar_brk_flg=SET;
                   else if((!proceed_refill_opn_blr_flg)AND(stop_at_current_cup_for_opn_blr_flg))
                       proceed_refill_opn_blr_flg=SET;
               }
            }
            break;
        case SCNDARY_PR_COMPLETE:
            scnd_outlet_stages=scndary_no_of_multicup=scndry_send_cup=scnd_drnk_last_cup_snd_flg=0;
//            snd_err_aftr_dispns_opn_blr=snd_err_aftr_dispns_es_blr=CLEAR_1;
            secondary_outlet_process_init_flag=from_secondary_drink=double_cup_flag=mug_flag=demo_drink_flg=CLEAR_1;
            if(stop_scndry_prdct_prcess)
            {
                if(hot_wtr_on_flg)
                {
                    if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                        PRESSURE_PUMP_OFF;
                    HOT_WATER_OFF;
                }
                else
                    COOLER_OFF;
                stop_scndry_prdct_prcess=hot_or_cold_run_time_flg=hot_or_cold_run_time_flg=mltcup_pauz_strt_flg=scondary_drip_time_start_flag=need_stop_drink_due_to_err_flg=CLEAR_1;
                scndry_stop_done_snd_flg=SET;
                if(!process_initiated_flag)
                secondary_process_complete=SET;
            }
            else
            secondary_process_complete=SET;
            break;
    }
}/*
 1. if select in direct start also we need to dispense
 2. if select in scndry dispense also we need to dispense

 */


void hot_cold_wtr_fun()
{
    if(hot_or_cold_wtr_dly_flg)
    {
        if(hot_or_cold_wtr_dly_tmr<=0)
        {
            if((hot_or_cold_run_time_flg)AND(hot_or_cold_run_time<=0))
            {
                hot_or_cold_run_time_flg=(drnk_ch_hw_cw[scnd_drink_id]==2)?(HOT_WATER_OFF,CLEAR_1):(COOLER_OFF,CLEAR_1);
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                hot_or_cold_wtr_dly_flg=CLEAR_1;
                scnd_outlet_stages++;
            }
            else if(!hot_or_cold_run_time_flg)
            {
                hot_or_cold_run_time_flg=(drnk_ch_hw_cw[scnd_drink_id]==2)?(HOT_WATER_ON,SET):(COOLER_ON,SET);
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en])AND(hot_wtr_on_flg))
                    PRESSURE_PUMP_ON;
                hot_or_cold_run_time=scondary_outlet_wtr_set[scnd_drink_id][drnk_ch_hw_cw[scnd_drink_id]-1][scndary_wtr_time]*(double_cup_flag?2:(mug_flag?mug_fn(scnd_drink_id):1));
            }
        }

    }
    else if(!hot_or_cold_wtr_dly_flg)
    {
        hot_or_cold_wtr_dly_flg=SET;
        hot_or_cold_wtr_dly_tmr=scondary_outlet_wtr_set[scnd_drink_id][drnk_ch_hw_cw[scnd_drink_id]-1][scndary_wtr_dly];      //subtract 1 to get the hot water or cold water delay time
    }
}
