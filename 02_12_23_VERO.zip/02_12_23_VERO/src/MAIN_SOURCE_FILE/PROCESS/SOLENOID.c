/*
 * SOLENOID.c
 *
 *  Created on: 07-Jan-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

void solenoid_fun(unsigned char );

void solenoid_fun(unsigned char sol_ch)
{
    if(!ch_flags[sol_ch].solnd_prcs_cmplt)
    {
        if((ch_process[sol_ch].wtr_time<=0)AND(ch_process[sol_ch].wtr_on_off_cnt>0))
        {
            if((ch_tmr[sol_ch].wtr_off_time<=0)AND(!ch_flags[sol_ch].one_time_sol_flag))
            {
               switch(sol_ch)
               {
                   case 1:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID1_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
                   case 2:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID2_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
                   case 3:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID3_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
                   case 4:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID4_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
                   case 5:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID5_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
                   case 6:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_ON;
                       SOLENOID6_ON;
                       ch_flags[sol_ch].one_time_sol_flag=SET;
                       break;
               }
               if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(main_prdct_wtr_id==sol_ch)AND(ch_process[sol_ch].wtr_on_off_cnt==1))
               {
                   ch_tmr[sol_ch].wtr_on_time=last_sol_on_time;     //if pulse is 1,last on pulse we need to dispense
                   last_sol_on_time=0;
               }
               else
               ch_tmr[sol_ch].wtr_on_time=back_up[sol_ch].backup_wtr_on_time;
            }
            else if((ch_tmr[sol_ch].wtr_on_time<=0)AND(ch_flags[sol_ch].one_time_sol_flag))
            {
                switch(sol_ch)
               {
                   case 1:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID1_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
                   case 2:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID2_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
                   case 3:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID3_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
                   case 4:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID4_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
                   case 5:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID5_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
                   case 6:
                       if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                           PRESSURE_PUMP_OFF;
                       SOLENOID6_OFF;
                       ch_flags[sol_ch].one_time_sol_flag=CLEAR_1;
                       break;
               }
               ch_tmr[sol_ch].wtr_off_time=back_up[sol_ch].backup_wtr_off_time;
               ch_process[sol_ch].wtr_on_off_cnt--;
               ch_flags[sol_ch].solnd_prcs_cmplt=(ch_process[sol_ch].wtr_on_off_cnt==0)?back_up[sol_ch].backup_wtr_on_time=back_up[sol_ch].backup_wtr_off_time=0,SET:CLEAR_1;
            }
        }
        else
        {
            if((need_to_minus_wtr_vl_frm_byprdct_flg)AND(main_prdct_wtr_id==sol_ch))
            {
                back_up[sol_ch].backup_wtr_on_time=(ch_process[sol_ch].wtr_time+main_prdct_temp_wtr)/ch_process[sol_ch].wtr_puls_no;   //eg:3+2= 5sec  5/3=1.66sec
                for(ch_process[sol_ch].wtr_on_off_cnt=0;last_sol_on_time<ch_process[sol_ch].wtr_time;ch_process[sol_ch].wtr_on_off_cnt++)   // 1 pulse , 2 pulse , break
                    last_sol_on_time+=back_up[sol_ch].backup_wtr_on_time;                                                                                     // 1.66 sec, 3.32 sec
//                back_up[sol_ch].backup_wtr_on_time=(ch_process[sol_ch].wtr_time+main_prdct_temp_wtr)/ch_process[sol_ch].wtr_puls_no; //on time = 1.66 sec
                last_sol_on_time=ch_process[sol_ch].wtr_time-(back_up[sol_ch].backup_wtr_on_time*(ch_process[sol_ch].wtr_on_off_cnt-1)); //total time=(3-(on_time*(newpulse-1)) =3-(1.66*(2-1))=1.34 sec
                back_up[sol_ch].backup_wtr_off_time=(ch_process[sol_ch].wtr_on_off_cnt>1)?ch_process[sol_ch].wtr_puls_time:0;
//                back_up_time_for_prmx_time=ch_process[sol_ch].wtr_time;
                ch_process[sol_ch].wtr_time=ch_process[sol_ch].wtr_puls_no=ch_process[sol_ch].wtr_puls_time=0;
            }
            else
            {
                ch_process[sol_ch].wtr_on_off_cnt=ch_process[sol_ch].wtr_puls_no;      //(ch_process[sol_ch].wtr_puls_no>0)?++ch_process[sol_ch].wtr_puls_no:1;
                back_up[sol_ch].backup_wtr_on_time=ch_process[sol_ch].wtr_time/ch_process[sol_ch].wtr_on_off_cnt;
                back_up[sol_ch].backup_wtr_off_time=(ch_process[sol_ch].wtr_puls_no>1)?ch_process[sol_ch].wtr_puls_time:0;
                ch_process[sol_ch].wtr_time=ch_process[sol_ch].wtr_puls_no=ch_process[sol_ch].wtr_puls_time=0;
            }
        }
    }
}


// 1. water pulse 1 - on time
// 2. water pulse 2 - on time-off time-on time
