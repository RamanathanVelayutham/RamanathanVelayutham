/*

 * DRINK_PROCESS.c
 *
 *  Created on: 04-Jan-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"



unsigned int wtr_blnc_fun(unsigned char );
unsigned char check_future_channel();
unsigned char number_len(unsigned long int );
float check_strength(unsigned char );
bool skip_fun(unsigned char );
void steps();
void drink_process();
void ch1_process();
void ch2_process();
void ch3_process();
void ch4_process();
void ch5_process();
void ch6_process();
void clear_ch_prcs_struct();
float mug_fn(unsigned char);

unsigned char number_len(unsigned long int num)
{
    unsigned char count=0;
    do
    {
        num /= 10;
        ++count;
    }
    while (num != 0);
    return count;
}

float check_strength(unsigned char strngth_ch)
{
    if((drk_main_sett[drink_id][main_prdt_ch]==strngth_ch)AND(!drnk_genral_set[direct_start]))
        return strength[strngth_ch];
    else if((milk_canister==strngth_ch)AND(drk_main_sett[drink_id][milk_en_dis])AND(!drnk_genral_set[direct_start]))
        return strength[strngth_ch];
    else if((sugar_canister==strngth_ch)AND(drk_main_sett[drink_id][sugar_en_dis])AND(!drnk_genral_set[direct_start]))
        return strength[strngth_ch];
    else
        return 1;
}
bool skip_fun(unsigned char byprdct_ch)
{
    if(((drk_main_sett[drink_id][milk_en_dis])AND(milk_canister==byprdct_ch))OR((drk_main_sett[drink_id][sugar_en_dis])AND(sugar_canister==byprdct_ch)))          //CHECK THE CH IS MILK OR SUGAR, THEN WE NEED TO CHECK WHICH IS SELECTED OR NOT
    {
        if(by_product_selected[byprdct_ch])
            return 1;
        else
        {
            if(skip_only_prmx==byprdct_ch)
                return 1;
            else
                return 0;
        }
    }
    else
        return 1;
}
float mug_fn(unsigned char temp_drink_id)
{
    mug_float=(float)drk_main_sett[temp_drink_id][mug_adjst_fctr];
    mug_float/=10;
    return mug_float;
}
unsigned int wtr_blnc_fun(unsigned char current_ch)     //if by product select we need to do (main product water run time-by product water run time)
{
    unsigned char checking_byproduct_sequence=0,check_near_ch_in_stp=0,checking_byproducts_parallel=0,sugar_parallel_id=0,milk_parallel_id=0;
    bool need_to_minus_sugar_val_flg=0;
    if(drk_main_sett[drink_id][main_prdt_ch]==current_ch)
    {
        switch(by_prodcut_no)
        {
            case 1:         //both is selected
                for(checking_byproduct_sequence=1;checking_byproduct_sequence<5;checking_byproduct_sequence++)
                {
                    sugar_parallel_id=milk_parallel_id=need_to_minus_sugar_val_flg=0;
                    for(checking_byproducts_parallel=1;checking_byproducts_parallel<5;checking_byproducts_parallel++)
                    {
                        if(sugar_canister==process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]/10)
                        sugar_parallel_id=checking_byproducts_parallel;
                        else if(milk_canister==process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]/10)
                        milk_parallel_id=checking_byproducts_parallel;
                    }
                    if((sugar_parallel_id)OR(milk_parallel_id))
                    {
                        if((sugar_parallel_id)AND(milk_parallel_id))        //checking both are in same steps
                        {
                            if(channel[sugar_canister]==channel[milk_canister]) //checking both have same mixers
                            {
                                if(channel[sugar_canister]==sugar_canister)
                                    need_to_minus_sugar_val_flg=SET;
                                else
                                    need_to_minus_sugar_val_flg=CLEAR_1;
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;            //main product water id
                                    main_prdct_temp_wtr=drk_sett[drink_id][need_to_minus_sugar_val_flg?sugar_canister:milk_canister][((process_step[drink_id][checking_byproduct_sequence][need_to_minus_sugar_val_flg?sugar_parallel_id:milk_parallel_id]%10)==2)?wtr_time2:wtr_time1];        //checking which canister we need minus, checking which value we need to minus wtr 1 or wtr 2
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][need_to_minus_sugar_val_flg?sugar_canister:milk_canister][((process_step[drink_id][checking_byproduct_sequence][need_to_minus_sugar_val_flg?sugar_parallel_id:milk_parallel_id]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else        // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][need_to_minus_sugar_val_flg?sugar_canister:milk_canister][((process_step[drink_id][checking_byproduct_sequence][need_to_minus_sugar_val_flg?sugar_parallel_id:milk_parallel_id]%10)==2)?wtr_time2:wtr_time1];
                            }
                            else
                            {
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;
                                    main_prdct_temp_wtr=(drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1])+(drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1]);
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else    // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1];
                            }
                        }
                        else
                        {
                            if(current_ch<7)            //for main product: instant
                            {
                                main_prdct_wtr_id=wtr_whpr_channels;
                                main_prdct_temp_wtr=(drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1])+(drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1]);
                                return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1]);
                            }
                            else    // for main product fresh brew and bean brew
                                return drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][sugar_parallel_id]%10)==2)?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][milk_parallel_id]%10)==2)?wtr_time2:wtr_time1];
                        }
                    }

                }
                break;
            case 2:         //only sugar selected
                for(checking_byproduct_sequence=1;checking_byproduct_sequence<5;checking_byproduct_sequence++)
                {
                    for(checking_byproducts_parallel=1;checking_byproducts_parallel<5;checking_byproducts_parallel++)
                    {
                        if(sugar_canister==process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]/10)
                        {
                            if(sugar_canister==channel[sugar_canister])             //if both mixer and canister is same channel
                            {
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;
                                    main_prdct_temp_wtr=drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else    // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                            }
                            else
                            {
                                for(check_near_ch_in_stp=1;check_near_ch_in_stp<5;check_near_ch_in_stp++)       //need to check any neighbour is also present in parallel dispense
                                {
                                    if(channel[sugar_canister]==process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]/10)       //if neighbour channel which also present
                                    {
                                        if(current_ch<7)            //for main product: instant
                                        {
                                            main_prdct_wtr_id=wtr_whpr_channels;
                                            main_prdct_temp_wtr=drk_sett[drink_id][channel[sugar_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1];
                                            return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][channel[sugar_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1]);
                                        }
                                        else    // for main product fresh brew and bean brew
                                            return drk_sett[drink_id][channel[sugar_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1];
                                    }
                                }
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;
                                    main_prdct_temp_wtr=drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else    // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][sugar_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                            }
                        }
                    }
                }
                break;
            case 3:         //only milk selected         //only sugar selected
                for(checking_byproduct_sequence=1;checking_byproduct_sequence<5;checking_byproduct_sequence++)
                {
                    for(checking_byproducts_parallel=1;checking_byproducts_parallel<5;checking_byproducts_parallel++)
                    {
                        if(milk_canister==process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]/10)
                        {
                            if(milk_canister==channel[milk_canister])             //if both mixer and canister is same channel
                            {
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;
                                    main_prdct_temp_wtr=drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else     // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                            }
                            else
                            {
                                for(check_near_ch_in_stp=1;check_near_ch_in_stp<5;check_near_ch_in_stp++)       //need to check any neighbour is also present in parallel dispense
                                {
                                    if(channel[milk_canister]==process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]/10)       //if neighbour channel which also present
                                    {
                                        if(current_ch<7)            //for main product: instant
                                        {
                                            main_prdct_wtr_id=wtr_whpr_channels;
                                            main_prdct_temp_wtr=drk_sett[drink_id][channel[milk_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1];
                                            return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][channel[milk_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1]);
                                        }
                                        else     // for main product fresh brew and bean brew
                                            return drk_sett[drink_id][channel[milk_canister]][((process_step[drink_id][checking_byproduct_sequence][check_near_ch_in_stp]%10)==2)?wtr_time2:wtr_time1];
                                    }
                                }
                                if(current_ch<7)            //for main product: instant
                                {
                                    main_prdct_wtr_id=wtr_whpr_channels;
                                    main_prdct_temp_wtr=drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                                    return (drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1]-drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1]);
                                }
                                else     // for main product fresh brew and bean brew
                                    return drk_sett[drink_id][milk_canister][((process_step[drink_id][checking_byproduct_sequence][checking_byproducts_parallel]%10)==2)?wtr_time2:wtr_time1];
                            }
                        }
                    }
                }
                break;
        }
        if(current_ch<7)            //for main product: instant
            return drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1];
        else
            return 0;
    }
    else if(current_ch<7)
        return drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1];
    else
        return 0;
}



/*
 * 1. check, direct start is disabled.
 * 2. check byproduct is enabled for that drink.
 * 3. if enabled, then check the channel which is selected by user or not?
 * 4. if select, then dispense that channel.
 * 5. if not selected, skip the channel(NOTE: confirm the channel is not a owner of water & mixer in the steps, if owner means skip only a primix)
 * 6. byproduct is disabled means we dispense the channel as a standard.
 */
void steps()
{
    unsigned char i=0;
    for(i=1;process_step[drink_id][drnk_steps][i]!=0;i++)
    {
        GET_PRVS_CH_WTR_MIX:
        ch_steps=(process_step[drink_id][drnk_steps][getting_prvs_ch_wtr_mix_flg?(i-1):i]);//10;                          //we got what are the channels done at that steps

        if((ch_steps>10)AND(ch_steps<63))                 //for channels. if the channel is 11 or 12, that if the instant flag set then only it is for channel, else for bean brew
        {
            ch_steps/=10;
            step_ch[ch_steps]=ch_steps;      // we got the channel which is used or not based this we confirm
            if(ch_steps<7)
            {
                cycle_2_flag=(process_step[drink_id][drnk_steps][getting_prvs_ch_wtr_mix_flg?(i-1):i]%2==0)?SET:CLEAR_1;        //done by 1st cycle value or 2nd cycle value
                wtr_whpr_channels=(channel[ch_steps]==ch_steps)?skip_wtr_mixer_flg=CLEAR_1,ch_steps:check_future_channel();
                if(!drnk_genral_set[direct_start]?(skip_fun(ch_steps)):1)
                {
                        ch_process[ch_steps].ch_dly=drk_sett[drink_id][ch_steps][cycle_2_flag?ch_delay2:ch_delay1];
                        ch_process[wtr_whpr_channels].wtr_time=!skip_wtr_mixer_flg?((need_to_minus_wtr_vl_frm_byprdct_flg)AND(!drnk_genral_set[direct_start])?wtr_blnc_fun(ch_steps):drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_time2:wtr_time1])*(double_cup_flag?2:(mug_flag?mug_fn(drink_id):1)):0;
                        ch_process[wtr_whpr_channels].wtr_puls_no=!skip_wtr_mixer_flg?drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_pulz_no2:wtr_pulz_no1]*(double_cup_flag?2:1):0;
                        ch_process[wtr_whpr_channels].wtr_puls_time=!skip_wtr_mixer_flg?drk_sett[drink_id][ch_steps][cycle_2_flag?wtr_pulz_time2:wtr_pulz_time1]:0;
                        if(skip_only_prmx!=ch_steps)        //if, owner ch is skipped in the adjustment screen means we need to skip only prmx
                        {
                            ch_process[ch_steps].prmx_dly=drk_sett[drink_id][ch_steps][cycle_2_flag?prmx_dly2:prmx_dly1];
                            ch_process[ch_steps].prmx_rpm=drk_sett[drink_id][ch_steps][cycle_2_flag?prmx_rpm2:prmx_rpm1];
                            ch_process[ch_steps].prmx_time=drk_sett[drink_id][ch_steps][cycle_2_flag?prmx_time2:prmx_time1]*(double_cup_flag?2:(mug_flag?mug_fn(drink_id):1))*(check_strength(ch_steps));      //if choosen, then run based on strength
                            ch_process[ch_steps].prmx_puls_no=drk_sett[drink_id][ch_steps][cycle_2_flag?prmx_pulz_no2:prmx_pulz_no1]*(double_cup_flag?2:1);
                            ch_process[ch_steps].prmx_puls_time=drk_sett[drink_id][ch_steps][cycle_2_flag?prmx_pulz_time2:prmx_pulz_time1];
                        }
                        ch_process[wtr_whpr_channels].mxr_dly=!skip_wtr_mixer_flg?drk_sett[drink_id][ch_steps][cycle_2_flag?whpr_dly2:whpr_dly1]:0;
                        ch_process[wtr_whpr_channels].mxr_rpm=!skip_wtr_mixer_flg?drk_sett[drink_id][ch_steps][cycle_2_flag?whpr_rpm2:whpr_rpm1]:0;
                        ch_process[wtr_whpr_channels].mxr_time=!skip_wtr_mixer_flg?drk_sett[drink_id][ch_steps][cycle_2_flag?whpr_time2:whpr_time1]*(double_cup_flag?2:(mug_flag?mug_fn(drink_id):1)):0;
                }
                skip_wtr_mixer_flg=cycle_2_flag=getting_prvs_ch_wtr_mix_flg=wtr_whpr_channels=CLEAR_1;
                if(need_to_get_wtr_mxr_vl_flg)
                {
                    need_to_get_wtr_mxr_vl_flg=CLEAR_1;
                    if(ch_process[ch_steps].prmx_time>0)
                    {
                        getting_prvs_ch_wtr_mix_flg=SET;
                        goto GET_PRVS_CH_WTR_MIX;
                    }
                }
            }
        }
        else        // for espresso & fresh brew & bean brew
        {
            step_ch[ch_steps]=ch_steps;
            if(ch_steps==7)
                espresso_sequence=GRINDER,reprsr_intrvl_time_count=0;

            else if((ch_steps==8)OR(ch_steps==9))
            {
                fresh_brew_brewer_flag=SET,fb_brewer_stops=BREWER_START_DELAY;
                fresh_brew_canister_flg=(ch_steps==8)?SET:fresh_brew_canister_flg;
                bean_brew_grinder_flag=(ch_steps==9)?SET:bean_brew_grinder_flag;
            }
        }
    }
}
/*
 * Need to check the channel mapping with current.
 * else, need to check the value of the channel which is coming up in the current steps, if coming up skip the value on that channel
 * Because at same add the same channel which is work on owner channel value.
 */

unsigned char check_future_channel()
{
    unsigned char checking=0,from_currnt_row=0;
    for(from_currnt_row=1;process_step[drink_id][drnk_steps][from_currnt_row]!=0;from_currnt_row++)
    {
        checking=(process_step[drink_id][drnk_steps][from_currnt_row])/10;      //check the owner is present in the column
        if(channel[ch_steps]==checking)
        {
            if(!drnk_genral_set[direct_start])
            {
                if((channel[ch_steps]==milk_canister)AND((!by_product_selected[milk_canister])AND(drk_main_sett[drink_id][milk_en_dis])))        //if owner ch is set as by product but didn't select by a user that case we need to skip primix, not wtr&mxr, because they run for another neighbour channel
                {
                    skip_only_prmx=milk_canister;
                    if(skip_only_prmx<ch_steps)         //if milk is previous of the current channel, we need to get the value of water and mixer.
                        need_to_get_wtr_mxr_vl_flg=SET;
                }
                else if((channel[ch_steps]==sugar_canister)AND((!by_product_selected[sugar_canister])AND(drk_main_sett[drink_id][sugar_en_dis])))
                {
                    if(skip_only_prmx<ch_steps)         //if sugar is previous of the current channel, we need to get the value of water and mixer.
                        skip_only_prmx=sugar_canister;
                }
            }
            skip_wtr_mixer_flg=SET;
            return 0;
        }
    }
    return channel[ch_steps];
}

void clear_ch_prcs_struct()
{
    for(unsigned char i=0;i<7;i++)
    {
        ch_process[i].ch_dly=0;
        ch_process[i].wtr_time=0;
        ch_process[i].wtr_puls_no=0;
        ch_process[i].wtr_puls_time=0;
        ch_process[i].wtr_on_off_cnt=0;
        ch_process[i].prmx_dly=0;
        ch_process[i].prmx_rpm=0;
        ch_process[i].prmx_time=0;
        ch_process[i].prmx_puls_no=0;
        ch_process[i].prmx_puls_time=0;
        ch_process[i].prmx_on_of_cnt=0;
        ch_process[i].mxr_dly=0;
        ch_process[i].mxr_rpm=0;
        ch_process[i].mxr_time=0;
    }
}
void drink_process()
{
    unsigned char i=0;
    switch(stages)
    {
        case GET_STEPS_VALUES:
            steps();
            skip_only_prmx=0;
            stages++;
            break;
        case CHECK_CH_AVAILABLE_IN_STEPS:
            if(step_ch[1]!=1)       // we check channel which is in steps of then drinks
            {
                ch_flags[1].complete_flag=((step_ch[2]==2)AND(channel[2]==1))?CLEAR_1:SET;      // if not available, need to confirm mixer & water is used for neighbour or not
                if(!ch_flags[1].complete_flag)
                    FOR_CH[1]=2;
            }
            else
                FOR_CH[1]=1;
            if(step_ch[2]!=2)
            {
                ch_flags[2].complete_flag=(((step_ch[1]==1)AND(channel[1]==2))OR((step_ch[3]==3)AND(channel[3]==2)))?CLEAR_1:SET;
                if(!ch_flags[2].complete_flag)
                    FOR_CH[2]=((step_ch[1]==1)AND(channel[1]==2))?1:3;
            }
            else
                FOR_CH[2]=2;
            if(step_ch[3]!=3)
            {
                ch_flags[3].complete_flag=(((step_ch[2]==2)AND(channel[2]==3))OR((step_ch[4]==4)AND(channel[4]==3)))?CLEAR_1:SET;
                if(!ch_flags[3].complete_flag)
                    FOR_CH[3]=((step_ch[2]==2)AND(channel[2]==3))?2:4;
            }
            else
                FOR_CH[3]=3;
            if(step_ch[4]!=4)
            {
                ch_flags[4].complete_flag=(((step_ch[3]==3)AND(channel[3]==4))OR((step_ch[5]==5)AND(channel[5]==4)))?CLEAR_1:SET;
                if(!ch_flags[4].complete_flag)
                    FOR_CH[4]=((step_ch[3]==3)AND(channel[3]==4))?3:5;
            }
            else
                FOR_CH[4]=4;
            if(step_ch[5]!=5)
            {
                ch_flags[5].complete_flag=(((step_ch[4]==4)AND(channel[4]==5))OR((step_ch[6]==6)AND(channel[6]==5)))?CLEAR_1:SET;
                if(!ch_flags[5].complete_flag)
                    FOR_CH[5]=((step_ch[4]==4)AND(channel[4]==5))?4:6;
            }
            else
                FOR_CH[5]=5;
            if(step_ch[6]!=6)
                ch_flags[6].complete_flag=SET;
            if(espresso_machine_flag)
            {
                if(step_ch[7]!=7)
                    espresso_procs_cmplete_flag=SET;
            }
            if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
            {
                if((!fresh_brew_canister_flg)AND(!bean_brew_grinder_flag))
                    fb_prmx_or_grndr_complete_flg=fb_wtr_complete_flg=SET;
                if(!fresh_brew_brewer_flag)
                    fresh_brew_brewer_complete_flg=SET;
            }
            stages++;
            break;
        case START_PROCESS:
            if((ch_flags[1].complete_flag)AND(ch_flags[2].complete_flag)AND(ch_flags[3].complete_flag)AND(ch_flags[4].complete_flag)AND(ch_flags[5].complete_flag)AND(ch_flags[6].complete_flag)AND(espresso_machine_flag?espresso_procs_cmplete_flag:1)AND(((freshbrew_machine_flag)OR(beanbrew_machine_flag))?((fb_prmx_or_grndr_complete_flg)AND(fb_wtr_complete_flg)AND(fresh_brew_brewer_complete_flg)):1))
            {
                if((double_cup_flag)AND(!double_cup_2nd_cycle_flag))
                {
                    if((step_ch[7]==7)AND(espresso_machine_flag))
                        espresso_procs_cmplete_flag=CLEAR_1,double_cup_2nd_cycle_flag=SET,espresso_sequence=GRINDER;
                    else if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
                    {
                        double_cup_2nd_cycle_flag=SET;
//                        if(same_step_fb_flag)
//                        {
                            fb_prmx_or_grndr_complete_flg=fb_wtr_complete_flg=fresh_brew_brewer_complete_flg=CLEAR_1,fb_brewer_stops=BREWER_START_DELAY;
                            fresh_brew_canister_flg=freshbrew_machine_flag?SET:(bean_brew_grinder_flag=SET,CLEAR_1);
                            fresh_brew_brewer_flag=SET;
//                        }

//                        else if((fb_diffrent_step_ch1_cmplt_flag)AND(fb_diffrent_step_ch2_cmplt_flag))
//                        {
//                            step_no++;          //for dispense canister in step 1 & then brwr in step 2.
//                            if(step_no==1)
//                            {
//                                fb_wtr_complete_flg=fb_prmx_or_grndr_complete_flg=double_cup_2nd_cycle_flag=CLEAR_1;  //BECAUSE THEN ONLY AFTER COMPLETE IT WILL ENTER AND DO BRWR
//                                fresh_brew_canister_flg=freshbrew_machine_flag?SET:(bean_brew_grinder_flag=SET,CLEAR_1);
//                            }
//                            else if(step_no==2)
//                            {
//                                fresh_brew_brewer_complete_flg=CLEAR_1;
//                                fb_diffrent_step_ch1_cmplt_flag=fb_diffrent_step_ch2_cmplt_flag=CLEAR_1;
//                                fb_brewer_stops=BREWER_START_DELAY;
//                                fresh_brew_brewer_flag=SET;
//                                step_no=0;
//                            }
//                        }

                    }
                    else                                        //FOR INSTANT
                        double_cup_2nd_cycle_flag=SET;
                }
                else
                stages++;
            }
            else
            {
                if(espresso_machine_flag)
                    espresso_dispens_process();
                if((freshbrew_machine_flag)OR(beanbrew_machine_flag))
                {
                    fb_pwdr_fun();
                    fresh_brewer();
                }
                ch1_process();
                ch2_process();
                ch3_process();
                ch4_process();
                ch5_process();
                ch6_process();
            }
            break;
        case DRIP_TIME:
            if((!block_esprs_prdct_flg)AND(!block_esprs_prdct_till_cln_brwr_flg))
            {
                if(process_step[drink_id][++drnk_steps][1]==0)        //check the steps are end
                {
                    drnk_steps--;
                    if((no_of_multicup<=0)OR(stop_prmry_prdct_prcess)OR(need_stop_drink_due_to_err_flg))
                    {
                        if((drip_time_start_flag)AND(process_drip_time<=0))
                        {
                            drip_time_start_flag=CLEAR_1,stages++;
                            for(i=1;i<8;i++)
                                ch_flags[i].complete_flag=step_ch[i]=channel_strength[i]=ch_flags[i].ch_dly_complete=CLEAR_1;
                            espresso_procs_cmplete_flag=fb_prmx_or_grndr_complete_flg=fb_wtr_complete_flg=fresh_brew_brewer_complete_flg=CLEAR_1;          //because these all have only one cycle
                            double_cup_2nd_cycle_flag=double_cup_flag=mug_flag=multicup_start_flag=need_to_minus_wtr_vl_frm_byprdct_flg=CLEAR_1;
                            no_of_multicup=send_cup=0;
                            clear_ch_prcs_struct();
                        }
                        else if(!drip_time_start_flag)
                        {
                            if(last_cup_snd_flg)
                            {
                                multicup_completed_send_flag=SET;
                                send_cup++;
                            }
                            drip_time_start_flag=SET;
                            process_drip_time=drk_main_sett[drink_id][drip_time];
                        }
                    }
                    else            //multicup pauze time
                    {
                        if((mltcup_pauz_time<=0)AND(mltcup_pauz_strt_flg))
                        {
                            for(i=1;i<8;i++)
                                ch_flags[i].complete_flag=step_ch[i]=channel_strength[i]=ch_flags[i].ch_dly_complete=CLEAR_1;
                            espresso_procs_cmplete_flag=fb_prmx_or_grndr_complete_flg=fb_wtr_complete_flg=fresh_brew_brewer_complete_flg=CLEAR_1;          //because these all have only one cycle
                            mltcup_pauz_strt_flg=double_cup_2nd_cycle_flag=CLEAR_1;
                            clear_ch_prcs_struct();
                            drnk_steps=1;
                            multicup_completed_send_flag=SET;
                            send_cup++;
                            stages=GET_STEPS_VALUES;
                        }
                        else if(!mltcup_pauz_strt_flg)
                        {
                            if((!stop_at_current_cup_for_ar_brk_flg)AND(!stop_at_current_cup_for_opn_blr_flg))
                            {
                                if((!snd_err_end_of_cup_opn_blr)AND(!snd_err_end_of_cup_es_blr))
                                {
                                    if(no_of_multicup==1)
                                    last_cup_snd_flg=SET;
                                    no_of_multicup--;
                                    if(no_of_multicup!=0)//becuase when value reach 0 we don't need to continue the process, we move to drip time
                                    {
                                        mltcup_pauz_strt_flg=SET;
                                        mltcup_pauz_time=drk_main_sett[drink_id][pauz_time];
                                    }
                                }
                                else if((snd_err_end_of_cup_opn_blr)AND(!one_tm_opn_blr_htng_snd_flg))
                                {
                                    if(air_boiler_heater_on_flg)
                                    {
                                        if(ar_ctemp<=drnk_genral_set[min_op_temp])
                                            open_blr_htng_snd_flg=one_tm_opn_blr_htng_snd_flg=SET;
                                        else
                                            snd_err_end_of_cup_opn_blr=CLEAR_1;
                                    }
                                    else
                                        snd_err_end_of_cup_opn_blr=CLEAR_1;
                                }
                                else if((snd_err_end_of_cup_es_blr)AND(!one_tm_blr_htng_snd_flg))
                                {
                                    if(espresso_heater_on_flg)
                                    {
                                        if(es_ctemp<=drnk_genral_set[es_min_op_temp])
                                            one_tm_blr_htng_snd_flg=es_blr_htng_snd_flg=SET;
                                        else
                                            snd_err_end_of_cup_es_blr=CLEAR_1;
                                    }
                                    else
                                        snd_err_end_of_cup_es_blr=CLEAR_1;
                                }
                            }
                            else if((!proceed_refill_ar_brk_flg)AND(stop_at_current_cup_for_ar_brk_flg))
                                proceed_refill_ar_brk_flg=SET;
                            else if((!proceed_refill_opn_blr_flg)AND(stop_at_current_cup_for_opn_blr_flg))
                                proceed_refill_opn_blr_flg=SET;
                        }
                    }
                }
                else
                {
                   stages=GET_STEPS_VALUES;
                   for(i=1;i<8;i++)
                       ch_flags[i].complete_flag=step_ch[i]=ch_flags[i].ch_dly_complete=CLEAR_1;
                   espresso_procs_cmplete_flag=fb_prmx_or_grndr_complete_flg=fresh_brew_brewer_complete_flg=fb_wtr_complete_flg=CLEAR_1;
                   double_cup_2nd_cycle_flag=CLEAR_1;
                   clear_ch_prcs_struct();
//                   no_of_multicup=send_cup=double_cup_flag=multicup_start_flag=0;
                }
            }
            else
            {
                stages=PROCESS_END;
                no_of_multicup=0;
                for(i=1;i<8;i++)
                    ch_flags[i].complete_flag=step_ch[i]=ch_flags[i].ch_dly_complete=CLEAR_1;
                espresso_procs_cmplete_flag=fb_prmx_or_grndr_complete_flg=fresh_brew_brewer_complete_flg=fb_wtr_complete_flg=last_cup_snd_flg=CLEAR_1;
                double_cup_2nd_cycle_flag=mug_flag=double_cup_flag=need_to_minus_wtr_vl_frm_byprdct_flg=CLEAR_1;
                clear_ch_prcs_struct();

            }
            break;
        case PROCESS_END:
                stages=0;
                process_initiated_flag=multicup_start_flag=main_prdct_wtr_id=main_prdct_temp_wtr=demo_drink_flg=need_stop_drink_due_to_err_flg=CLEAR_1;
                drink_compelet_flag=stop_prmry_prdct_prcess?stop_done_snd_flg=SET,stop_prmry_prdct_prcess=CLEAR_1,CLEAR_1:SET;
            break;
    }
}

void ch1_process()
{
    if(!ch_flags[1].complete_flag)
    {
        if((ch_flags[1].solnd_prcs_cmplt)AND(ch_flags[1].prmx_prcs_cmplt)AND(ch_flags[1].whpr_prcs_cmplete))        //clear when steps complete
        {
            ch_flags[1].complete_flag=SET;
            ch_flags[1].solnd_prcs_cmplt=ch_flags[1].prmx_prcs_cmplt=ch_flags[1].whpr_prcs_cmplete=0;
        }
        else
        {
            if((ch_process[1].ch_dly<=0))
            {
                if(ch_tmr[1].prcs_ch_dly<=0)
                {
                    if(!ch_flags[1].ch_dly_complete)
                        ch_flags[1].ch_dly_complete=SET;
                    if(ch_flags[FOR_CH[1]].ch_dly_complete)    //but here for what ch this will do the water that ch delay need to be complete, then only we allow to enter
                    {
                        if(!ch_flags[1].solnd_prcs_cmplt)
                        {
                            if((ch_process[1].wtr_time==0)AND(ch_process[1].wtr_puls_no==0)AND(ch_process[1].wtr_puls_time==0)AND(ch_process[1].wtr_on_off_cnt==0))
                                ch_flags[1].solnd_prcs_cmplt=SET;
                            else
                            solenoid_fun(1);
                        }
                    }
                    if(ch_flags[1].ch_dly_complete)     //that ch delay complete then only we need to start primix
                    {
                        if(!ch_flags[1].prmx_prcs_cmplt)
                        {
                            if(ch_process[1].prmx_rpm==0)
                                ch_flags[1].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(1);
                        }
                    }
                    if(ch_flags[FOR_CH[1]].ch_dly_complete)
                    {
                        if(!ch_flags[1].whpr_prcs_cmplete)
                        {
                            if(ch_process[1].mxr_rpm==0)
                                ch_flags[1].whpr_prcs_cmplete=SET;
                            else
                                mixer_motor_fun(1);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[1].prcs_ch_dly=ch_process[1].ch_dly;
                ch_process[1].ch_dly=0;
            }
        }
    }
}

void ch2_process()
{
    if(!ch_flags[2].complete_flag)
    {
        if((ch_flags[2].solnd_prcs_cmplt)AND(ch_flags[2].prmx_prcs_cmplt)AND(ch_flags[2].whpr_prcs_cmplete))        //clear when steps complete
        {
            ch_flags[2].complete_flag=SET;
            ch_flags[2].solnd_prcs_cmplt=ch_flags[2].prmx_prcs_cmplt=ch_flags[2].whpr_prcs_cmplete=0;
        }
        else
        {
            if((ch_process[2].ch_dly<=0))
            {
                if(ch_tmr[2].prcs_ch_dly<=0)
                {
                    if(!ch_flags[2].ch_dly_complete)
                        ch_flags[2].ch_dly_complete=SET;
                    if(ch_flags[FOR_CH[2]].ch_dly_complete)
                    {
                        if(!ch_flags[2].solnd_prcs_cmplt)
                        {
                            if((ch_process[2].wtr_time==0)AND(ch_process[2].wtr_puls_no==0)AND(ch_process[2].wtr_puls_time==0)AND(ch_process[2].wtr_on_off_cnt==0))
                                ch_flags[2].solnd_prcs_cmplt=SET;
                            else
                            solenoid_fun(2);
                        }
                    }
                    if(ch_flags[2].ch_dly_complete)
                    {
                        if(!ch_flags[2].prmx_prcs_cmplt)
                        {
                            if(ch_process[2].prmx_rpm==0)
                                ch_flags[2].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(2);
                        }
                    }
                    if(ch_flags[FOR_CH[2]].ch_dly_complete)
                    {
                        if(!ch_flags[2].whpr_prcs_cmplete)
                        {
                            if(ch_process[2].mxr_rpm==0)
                                ch_flags[2].whpr_prcs_cmplete=SET;
                            else
                                mixer_motor_fun(2);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[2].prcs_ch_dly=ch_process[2].ch_dly;
                ch_process[2].ch_dly=0;
            }
        }
    }
}

void ch3_process()
{
    if(!ch_flags[3].complete_flag)
    {
        if((ch_flags[3].solnd_prcs_cmplt)AND(ch_flags[3].prmx_prcs_cmplt)AND(ch_flags[3].whpr_prcs_cmplete))        //clear when steps complete
        {
            ch_flags[3].complete_flag=SET;
            ch_flags[3].solnd_prcs_cmplt=ch_flags[3].prmx_prcs_cmplt=ch_flags[3].whpr_prcs_cmplete=0;
        }
        else
        {
            if((ch_process[3].ch_dly<=0))
            {
                if(ch_tmr[3].prcs_ch_dly<=0)
                {
                    if(!ch_flags[3].ch_dly_complete)
                        ch_flags[3].ch_dly_complete=SET;
                    if(ch_flags[FOR_CH[3]].ch_dly_complete)
                    {
                        if(!ch_flags[3].solnd_prcs_cmplt)
                        {
                            if((ch_process[3].wtr_time==0)AND(ch_process[3].wtr_puls_no==0)AND(ch_process[3].wtr_puls_time==0)AND(ch_process[3].wtr_on_off_cnt==0))
                                ch_flags[3].solnd_prcs_cmplt=SET;
                            else
                            solenoid_fun(3);
                        }
                    }
                    if(ch_flags[3].ch_dly_complete)
                    {
                        if(!ch_flags[3].prmx_prcs_cmplt)
                        {
                            if(ch_process[3].prmx_rpm==0)
                                ch_flags[3].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(3);
                        }
                    }
                    if(ch_flags[FOR_CH[3]].ch_dly_complete)
                    {
                        if(!ch_flags[3].whpr_prcs_cmplete)
                        {
                            if(ch_process[3].mxr_rpm==0)
                                ch_flags[3].whpr_prcs_cmplete=SET;
                            else
                                mixer_motor_fun(3);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[3].prcs_ch_dly=ch_process[3].ch_dly;
                ch_process[3].ch_dly=0;
            }
        }
    }
}

void ch4_process()
{
    if(!ch_flags[4].complete_flag)
    {
        if((ch_flags[4].solnd_prcs_cmplt)AND(ch_flags[4].prmx_prcs_cmplt)AND(ch_flags[4].whpr_prcs_cmplete))        //clear when steps complete
        {
            ch_flags[4].complete_flag=SET;
            ch_flags[4].solnd_prcs_cmplt=ch_flags[4].prmx_prcs_cmplt=ch_flags[4].whpr_prcs_cmplete=0;
        }
        else
        {
            if((ch_process[4].ch_dly<=0))
            {
                if(ch_tmr[4].prcs_ch_dly<=0)
                {
                    if(!ch_flags[4].ch_dly_complete)
                        ch_flags[4].ch_dly_complete=SET;
                    if(ch_flags[FOR_CH[4]].ch_dly_complete)
                    {
                        if(!ch_flags[4].solnd_prcs_cmplt)
                        {
                            if((ch_process[4].wtr_time==0)AND(ch_process[4].wtr_puls_no==0)AND(ch_process[4].wtr_puls_time==0)AND(ch_process[4].wtr_on_off_cnt==0))
                                ch_flags[4].solnd_prcs_cmplt=SET;
                            else
                            solenoid_fun(4);
                        }
                    }
                    if(ch_flags[4].ch_dly_complete)
                    {
                        if(!ch_flags[4].prmx_prcs_cmplt)
                        {
                            if(ch_process[4].prmx_rpm==0)
                                ch_flags[4].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(4);
                        }
                    }
                    if(ch_flags[FOR_CH[4]].ch_dly_complete)
                    {
                        if(!ch_flags[4].whpr_prcs_cmplete)
                        {
                            if(ch_process[4].mxr_rpm==0)
                                ch_flags[4].whpr_prcs_cmplete=SET;
                            else
                                mixer_motor_fun(4);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[4].prcs_ch_dly=ch_process[4].ch_dly;
                ch_process[4].ch_dly=0;
            }
        }
    }
}

void ch5_process()
{
    if(!ch_flags[5].complete_flag)
    {
        if((ch_flags[5].solnd_prcs_cmplt)AND(ch_flags[5].prmx_prcs_cmplt)AND(ch_flags[5].whpr_prcs_cmplete))        //clear when steps complete
        {
            ch_flags[5].complete_flag=SET;
            ch_flags[5].solnd_prcs_cmplt=ch_flags[5].prmx_prcs_cmplt=ch_flags[5].whpr_prcs_cmplete=0;
        }
        else
        {
            if((ch_process[5].ch_dly<=0))
            {
                if(ch_tmr[5].prcs_ch_dly<=0)
                {
                    if(!ch_flags[5].ch_dly_complete)
                            ch_flags[5].ch_dly_complete=SET;
                    if(ch_flags[FOR_CH[5]].ch_dly_complete)
                    {
                        if(!ch_flags[5].solnd_prcs_cmplt)
                        {
                            if((ch_process[5].wtr_time==0)AND(ch_process[5].wtr_puls_no==0)AND(ch_process[5].wtr_puls_time==0)AND(ch_process[5].wtr_on_off_cnt==0))
                                ch_flags[5].solnd_prcs_cmplt=SET;       //for when we run only prmx motor that case we set, because water & mixer run by a neighbour channel
                            else
                            solenoid_fun(5);
                        }
                    }
                    if(ch_flags[5].ch_dly_complete)
                    {
                        if(!ch_flags[5].prmx_prcs_cmplt)
                        {
                            if(ch_process[5].prmx_rpm==0)
                                ch_flags[5].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(5);
                        }
                    }
                    if(ch_flags[FOR_CH[5]].ch_dly_complete)
                    {
                        if(!ch_flags[5].whpr_prcs_cmplete)
                        {
                            if(ch_process[5].mxr_rpm==0)
                                ch_flags[5].whpr_prcs_cmplete=SET;
                            else
                                mixer_motor_fun(5);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[5].prcs_ch_dly=ch_process[5].ch_dly;
                ch_process[5].ch_dly=0;
            }
        }
    }
}

void ch6_process()
{
    if(!ch_flags[6].complete_flag)
    {
        if((ch_flags[6].solnd_prcs_cmplt)AND(ch_flags[6].prmx_prcs_cmplt))        //clear when steps complete
        {
            ch_flags[6].complete_flag=SET;
            ch_flags[6].solnd_prcs_cmplt=ch_flags[6].prmx_prcs_cmplt=0;
        }
        else
        {
            if((ch_process[6].ch_dly<=0))
            {
                if(ch_tmr[6].prcs_ch_dly<=0)
                {
                    if(!ch_flags[6].ch_dly_complete)
                        ch_flags[6].ch_dly_complete=SET;
                    if(ch_flags[6].ch_dly_complete)
                    {
                        if(!ch_flags[6].solnd_prcs_cmplt)
                        {
                            if((ch_process[6].wtr_time==0)AND(ch_process[6].wtr_puls_no==0)AND(ch_process[6].wtr_puls_time==0)AND(ch_process[6].wtr_on_off_cnt==0))
                                ch_flags[6].solnd_prcs_cmplt=SET;
                            else
                            solenoid_fun(6);
                        }
                    }
                    if(ch_flags[6].ch_dly_complete)
                    {
                        if(!ch_flags[6].prmx_prcs_cmplt)
                        {
                            if(channel[6]==6)       //becase when channel 6 is set for ch6 we need to dispense only ex.hot water
                                ch_flags[6].prmx_prcs_cmplt=SET;
                            else
                                powder_motor_fun(6);
                        }
                    }
                }
            }
            else
            {
                ch_tmr[6].prcs_ch_dly=ch_process[6].ch_dly;
                ch_process[6].ch_dly=0;
            }
        }
    }
}


