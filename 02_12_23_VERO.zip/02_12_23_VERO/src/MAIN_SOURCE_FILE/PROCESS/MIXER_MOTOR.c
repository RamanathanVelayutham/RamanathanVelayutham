/*
 * MIXER_MOTOR.c
 *
 *  Created on: 08-Jan-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"

void mixer_motor_fun(unsigned char );
void mxr1_rpm();
void mxr2_rpm();
void mxr3_rpm();
void mxr4_rpm();
void mxr5_rpm();


void mixer_motor_fun(unsigned char mxr_ch)
{
    if(!ch_flags[mxr_ch].whpr_prcs_cmplete)
    {
        if(ch_process[mxr_ch].mxr_dly<=0)
        {
            if(ch_tmr[mxr_ch].prcs_mxr_dly<=0)
            {
                if(ch_process[mxr_ch].mxr_time<=0)
                {
                    if(!ch_flags[mxr_ch].one_time_mxr_flag)
                    {
                       switch(mxr_ch)
                       {
                           case 1:
                               MIXER_MOTOR1_ON;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr1_pwm_flag=SET;
                               break;
                           case 2:
                               MIXER_MOTOR2_ON;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr2_pwm_flag=SET;
                               break;
                           case 3:
                               MIXER_MOTOR3_ON;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr3_pwm_flag=SET;
                               break;
                           case 4:
                               MIXER_MOTOR4_ON;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr4_pwm_flag=SET;
                               break;
                           case 5:
                               MIXER_MOTOR5_ON;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr5_pwm_flag=SET;
                               break;
                       }
                       ch_tmr[mxr_ch].mxr_on_time=back_up[mxr_ch].backup_mxr_on_time;
                    }
                    else if((ch_tmr[mxr_ch].mxr_on_time<=0)AND(ch_flags[mxr_ch].one_time_mxr_flag))
                    {
                        switch(mxr_ch)
                       {
                           case 1:
                               MIXER_MOTOR1_OFF;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr1_pwm_flag=CLEAR_1;
                               break;
                           case 2:
                               MIXER_MOTOR2_OFF;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr2_pwm_flag=CLEAR_1;
                               break;
                           case 3:
                               MIXER_MOTOR3_OFF;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr3_pwm_flag=CLEAR_1;
                               break;
                           case 4:
                               MIXER_MOTOR4_OFF;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr4_pwm_flag=CLEAR_1;
                               break;
                           case 5:
                               MIXER_MOTOR5_OFF;
                               ch_flags[mxr_ch].one_time_mxr_flag=start_mxr5_pwm_flag=CLEAR_1;
                               break;
                       }
                       ch_flags[mxr_ch].whpr_prcs_cmplete=SET,ch_process[mxr_ch].mxr_rpm=back_up[mxr_ch].backup_mxr_on_time=0;
                    }
                }
                else
                {
                    back_up[mxr_ch].backup_mxr_on_time=ch_process[mxr_ch].mxr_time;
                    ch_process[mxr_ch].mxr_time=0;
                }

            }
        }
        else
        {
            ch_tmr[mxr_ch].prcs_mxr_dly=ch_process[mxr_ch].mxr_dly;
            ch_process[mxr_ch].mxr_dly=0;
        }
    }
}


void mxr1_rpm()
{
    if((mxr1_pwm_off<=0)AND(!mxr1_on_flg))
    {
        MIXER_MOTOR1_ON;
        mxr1_pwm_on=ch_process[1].mxr_rpm;
    }
    else if((mxr1_pwm_on<=0)AND(mxr1_on_flg))
    {
        MIXER_MOTOR1_OFF;
        mxr1_pwm_off=100-ch_process[1].mxr_rpm;
    }
}
void mxr2_rpm()
{
    if((mxr2_pwm_off<=0)AND(!mxr2_on_flg))
    {
        MIXER_MOTOR2_ON;
        mxr2_pwm_on=ch_process[2].mxr_rpm;
    }
    else if((mxr2_pwm_on<=0)AND(mxr2_on_flg))
    {
        MIXER_MOTOR2_OFF;
        mxr2_pwm_off=100-ch_process[2].mxr_rpm;
    }
}
void mxr3_rpm()
{
    if((mxr3_pwm_off<=0)AND(!mxr3_on_flg))
    {
        MIXER_MOTOR3_ON;
        mxr3_pwm_on=ch_process[3].mxr_rpm;
    }
    else if((mxr3_pwm_on<=0)AND(mxr3_on_flg))
    {
        MIXER_MOTOR3_OFF;
        mxr3_pwm_off=100-ch_process[3].mxr_rpm;
    }
}
void mxr4_rpm()
{
    if((mxr4_pwm_off<=0)AND(!mxr4_on_flg))
    {
        MIXER_MOTOR4_ON;
        mxr4_pwm_on=ch_process[4].mxr_rpm;
    }
    else if((prmx4_pwm_on<=0)AND(prmx4_on_flg))
    {
        MIXER_MOTOR4_OFF;
        mxr4_pwm_off=100-ch_process[4].mxr_rpm;
    }
}
void mxr5_rpm()
{
    if((mxr5_pwm_off<=0)AND(!mxr5_on_flg))
    {
        MIXER_MOTOR5_ON;
        mxr5_pwm_on=ch_process[5].mxr_rpm;
    }
    else if((mxr5_pwm_on<=0)AND(mxr5_on_flg))
    {
        MIXER_MOTOR5_OFF;
        mxr5_pwm_off=100-ch_process[5].mxr_rpm;
    }
}
