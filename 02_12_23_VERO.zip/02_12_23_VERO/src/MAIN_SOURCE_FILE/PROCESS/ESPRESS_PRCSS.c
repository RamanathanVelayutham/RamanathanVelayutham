/*
 * ESPRESS_PRCSS.c
 *
 *  Created on: 15-Jan-2023
 *      Author: afila
 */


#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"

void espresso_dispens_process();

void espresso_dispens_process()
{
    if(!espresso_procs_cmplete_flag)
    {
        switch(espresso_sequence)
        {
            case GRINDER:
                if((bean_delay_start_flag)AND(bean_grinder_delay<=0))
                {
                    if(((grinder_run_time_flag)AND(bean_grinder_run_time<=0))OR(need_stop_drink_due_to_err_flg))
                    {
                        bean_grinder_run_time=0;
                        grinder_run_time_flag=bean_delay_start_flag=CLEAR_1;
                        BEAN_GRINDER_OFF;
                        espresso_sequence++;
                    }
                    else if(!grinder_run_time_flag)
                    {
                        grinder_run_time_flag=SET;
                        BEAN_GRINDER_ON;
                        bean_grinder_run_time=get_esprs_drnk_vlu_flg?es_drnk_grndr_run_time:(other_than_instant[machine][drink_id][grndr_run_time]*(check_strength(7)));
                    }
                }
                else if(!bean_delay_start_flag)
                {
                    bean_delay_start_flag=SET;
                    bean_grinder_delay=get_esprs_drnk_vlu_flg?es_drnk_grndr_dly_time:other_than_instant[machine][drink_id][gndr_dly_time];
                }
                break;

            case MOVE_ES_BREWER_TO_BREW:
                if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4)AND(fill_to_brew_err_cnt<70))
                {
                    if(es_brwr_mtr_flg)
                    {
                        ESPRESSO_BREWER_OFF;
                        fil_2_brw_err_cnt_start_flg=fill_to_brew_err_cnt=CLEAR_1;
                    }
                    espresso_sequence++;
                }
                else if((fil_2_brw_err_cnt_start_flg)AND(fill_to_brew_err_cnt>=70))      //when error occur send a blocking error.
                {
                    es_brwr_brew_pos_er_snd_flg=block_esprs_prdct_flg=SET;            //need clear the process flag stop process continue
                    espresso_sequence=END_PROCESS;
                    double_cup_flag=CLEAR_1;
                    ESPRESSO_BREWER_OFF;
                }
                else if((!es_brwr_mtr_flg)AND(es_brw_pos_sw_flg))
                ESPRESSO_BREWER_ON,fil_2_brw_err_cnt_start_flg=SET;
                break;

            case PRE_SHOT:
//                if((pre_shot_dly_time_flg)AND(dly_time_pre_brew<=0))
//                {
                    if((pre_shot_strt_flg)AND(pre_brew_time<=0))
                    {
                        if((three_way_vlv_flg)AND(presure_pump_flg))
                         PRESSURE_PUMP_OFF;
                        pre_shot_dly_time_flg=pre_shot_strt_flg=CLEAR_1;
                        espresso_sequence++;
                    }
                    else if(!pre_shot_strt_flg)
                    {
                        pre_shot_strt_flg=SET;
                        THREE_WAY_VALVE_ON;
                        PRESSURE_PUMP_ON;
                        pre_brew_time=get_esprs_drnk_vlu_flg?es_drnk_pre_brw_wtr_time:other_than_instant[machine][drink_id][pre_brw_wtr_time];
                    }
//                }
//                else if(!pre_shot_dly_time_flg)
//                {
//                    pre_shot_dly_time_flg=SET;
//                    dly_time_pre_brew=other_than_instant[machine][drink_id][3];
//                }
                break;

            case PULSE_WATER:
                if((dly_time_cof_wtr_pulz_flg)AND(delay_time_coffe_watr<=0))
                {
                    if(wtr_flw_cnt_flg)
                    {
                        if(es_brwr_flw_err_cnt<90)
                        {
                            if((es_brwr_flw_err_cnt<60)OR(machine_at_warning))
                            {
                                if(es_flw_cnt<=0)
                                {
                                    if((!presure_pump_flg)AND(dly_pmp_3vlv<=0))
                                    {
                                        THREE_WAY_VALVE_OFF;
                                        wtr_flw_cnt_flg=dly_time_cof_wtr_pulz_flg=CLEAR_1;
                                        espresso_sequence++;
                                    }
                                    else if(presure_pump_flg)
                                    {
                                        PRESSURE_PUMP_OFF;
                                        es_flow_war_clr_snd_flg=(!from_the_warning_stat_flg)AND(machine_at_warning)?machine_at_warning=CLEAR_1,SET:CLEAR_1;
//                                        from_the_warning_stat_flg=CLEAR_1;
                                        es_brwr_flw_err_cnt=0;
                                        dly_pmp_3vlv=get_esprs_drnk_vlu_flg?es_drnk_brwr_pauz_time:other_than_instant[machine][drink_id][brwr_pauz_time];          //pause time between pump & 3 way valve
                                    }
                                }
                            }
                            else
                                es_flow_warning_send_flag=machine_at_warning=from_the_warning_stat_flg=SET;     //if the machine completed successfully the next drink after the warning or clean brewer, then only we clear the warning,else still the error must be present
                        }
                        else
                        {
                            PRESSURE_PUMP_OFF;
                            THREE_WAY_VALVE_OFF;
                            es_flow_war_clr_snd_flg=SET;
                            from_the_warning_stat_flg=machine_at_warning=CLEAR_1;
                            (wtr_flw_cnt_flg=dly_time_cof_wtr_pulz_flg=machine_at_warning=es_brwr_flw_err_cnt=CLEAR_1);
                            espresso_sequence=MOVE_BRWER_TO_FILL_POS;
                            double_cup_flag=CLEAR_1;
                            block_esprs_prdct_till_cln_brwr_flg=es_flow_err_send_flag=SET;                //error should be clear, when the brewer cleaning is happen
                        }

                    }
                    else
                    {
                        wtr_flw_cnt_flg=SET;                //need to start with error & warning count
                        es_flw_cnt=get_esprs_drnk_vlu_flg?es_drnk_cof_wtr_pulz:((other_than_instant[machine][drink_id][cof_wtr_pulz]-(need_to_minus_wtr_vl_frm_byprdct_flg?other_than_instant[machine][drink_id][ex_hot_wtr_no_byproduct]:0))*(mug_flag?mug_fn(drink_id):1));
                        PRESSURE_PUMP_ON;
                    }
                }
                else if(!dly_time_cof_wtr_pulz_flg)
                {
                    dly_time_cof_wtr_pulz_flg=SET;
                    delay_time_coffe_watr=get_esprs_drnk_vlu_flg?es_drnk_pre_brw_wait_time:other_than_instant[machine][drink_id][pre_brw_wait_time];
                }
                break;

            case DELAY_TIME:
                if((delay_time_aftr_brw_flg)AND(es_brewer_delay_time<=0))
                    espresso_sequence++,delay_time_aftr_brw_flg=CLEAR_1;
                else if(!delay_time_aftr_brw_flg)
                {
                    delay_time_aftr_brw_flg=SET;
                    es_brewer_delay_time=get_esprs_drnk_vlu_flg?es_drnk_brwr_dly_time:other_than_instant[machine][drink_id][brwr_delay_time];
                }
                break;

            case MOVE_BRWER_TO_FILL_POS:
                if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                {
                    if(es_brwr_mtr_flg)
                    {
                        ESPRESSO_BREWER_OFF;
                        brw_2_fil_err_cnt_start_flg=CLEAR_1;
                        brw_to_fil_cnt=0;
                    }
                    espresso_sequence++;
                }
                else if((brw_2_fil_err_cnt_start_flg)AND(brw_to_fil_cnt>=90))      //when error occur send a blocking error.
                {
                    es_brwr_fil_pos_er_snd_flg=block_esprs_prdct_flg=SET;            //need clear the process flag stop process continue
                    espresso_sequence=END_PROCESS;
                    double_cup_flag=CLEAR_1;
                    ESPRESSO_BREWER_OFF;
                }
                else if((!es_brwr_mtr_flg)AND(!es_fill_pos_sw_flg))
                ESPRESSO_BREWER_ON,brw_2_fil_err_cnt_start_flg=SET;
                break;

            case END_PROCESS:
                espresso_procs_cmplete_flag=SET;
                break;
        }
    }
}
