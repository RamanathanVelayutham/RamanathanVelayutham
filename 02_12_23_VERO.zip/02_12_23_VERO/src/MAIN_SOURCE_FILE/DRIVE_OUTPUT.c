/*
 * DRIVE_OUTPUT.c
 *
 *  Created on: 27-Mar-2023
 *      Author: afila
 */
#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"


void brewer_drive_ouput();
void drive_outputs();
extern void wtr_op_test();
void water_run_time();

void drive_outputs()
{
    switch(output_id)
    {
        case 1:
            if(output_on_flag)
                FAN_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                FAN_OFF,output_off_flag=CLEAR_1;
            break;
        case 2:
            if(output_on_flag)
            {
                if(!es_htr_err_cnt_flg)
                ESPRESSO_HEATER_ON;
                output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                if(!es_htr_err_cnt_flg)
                ESPRESSO_HEATER_OFF;
                output_off_flag=CLEAR_1;
            }
            break;
        case 3:
            if(output_on_flag)
            {
                if(!open_blr_htr_err_cnt_flg)
                OPEN_AIR_BLR_HTR_ON;
                output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                if(!open_blr_htr_err_cnt_flg)
                OPEN_AIR_BLR_HTR_OFF;
                output_off_flag=CLEAR_1;
            }
            break;
        case 4:
            if(output_on_flag)
                COOLER_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                COOLER_OFF,output_off_flag=CLEAR_1;
            break;
        case 5:
            if(output_on_flag)
                PRESSURE_PUMP_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRESSURE_PUMP_OFF,output_off_flag=CLEAR_1;
            break;
        case 6:
            if(output_on_flag)
                BEAN_GRINDER_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                BEAN_GRINDER_OFF,output_off_flag=CLEAR_1;
            break;
        case 7:
            if(output_on_flag)
                PRIMIX_MOTOR1_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR1_OFF,output_off_flag=CLEAR_1;
            break;
        case 8:
            if(output_on_flag)
                PRIMIX_MOTOR2_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR2_OFF,output_off_flag=CLEAR_1;
            break;
        case 9:
            if(output_on_flag)
                PRIMIX_MOTOR3_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR3_OFF,output_off_flag=CLEAR_1;
            break;
        case 10:
            if(output_on_flag)
                PRIMIX_MOTOR4_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR4_OFF,output_off_flag=CLEAR_1;
            break;
        case 11:
            if(output_on_flag)
                PRIMIX_MOTOR5_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR5_OFF,output_off_flag=CLEAR_1;
            break;
        case 12:
            if(output_on_flag)
                PRIMIX_MOTOR6_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PRIMIX_MOTOR6_OFF,output_off_flag=CLEAR_1;
            break;
        case 13:
            if(output_on_flag)
                MIXER_MOTOR1_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                MIXER_MOTOR1_OFF,output_off_flag=CLEAR_1;
            break;
        case 14:
            if(output_on_flag)
                MIXER_MOTOR2_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                MIXER_MOTOR2_OFF,output_off_flag=CLEAR_1;
            break;
        case 15:
            if(output_on_flag)
                MIXER_MOTOR3_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                MIXER_MOTOR3_OFF,output_off_flag=CLEAR_1;
            break;
        case 16:
            if(output_on_flag)
                MIXER_MOTOR4_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                MIXER_MOTOR4_OFF,output_off_flag=CLEAR_1;
            break;
        case 17:
            if(output_on_flag)
                MIXER_MOTOR5_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                MIXER_MOTOR5_OFF,output_off_flag=CLEAR_1;
            break;
        case 18:
            if(output_on_flag)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID1_ON,output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                SOLENOID1_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 19:
            if(output_on_flag)
            {
                SOLENOID2_ON,output_on_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
            }
            else if(output_off_flag)
            {
                SOLENOID2_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 20:
            if(output_on_flag)
            {
                SOLENOID3_ON,output_on_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
            }
            else if(output_off_flag)
            {
                SOLENOID3_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 21:
            if(output_on_flag)
            {
                SOLENOID4_ON,output_on_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
            }
            else if(output_off_flag)
            {
                SOLENOID4_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 22:
            if(output_on_flag)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID5_ON,output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                SOLENOID5_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 23:
            if(output_on_flag)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID6_ON,output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                SOLENOID6_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 24:
            if(output_on_flag)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                HOT_WATER_ON,output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                HOT_WATER_OFF,output_off_flag=CLEAR_1;
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
            }
            break;
        case 25:
            if(output_on_flag)
                PERISTALTIC_PUMP_ON,output_on_flag=CLEAR_1;
            else if(output_off_flag)
                PERISTALTIC_PUMP_OFF,output_off_flag=CLEAR_1;
            break;
        case 27:
            if(output_on_flag)
            {
                if(!ar_brk_fil_strt_flg)
                    AIR_BREAK_INLET_VALVE_ON;
                output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                if(!ar_brk_fil_strt_flg)
                    AIR_BREAK_INLET_VALVE_OFF;
                output_off_flag=CLEAR_1;
            }
            break;
        case 28:
            if(output_on_flag)
            {
                if(!opn_blr_fil_strt_flg)
                    OPEN_AIR_BOILER_INLET_VALVE_ON;
                output_on_flag=CLEAR_1;
            }
            else if(output_off_flag)
            {
                if(!opn_blr_fil_strt_flg)
                    OPEN_AIR_BOILER_INLET_VALVE_OFF;
                output_off_flag=CLEAR_1;
            }
            break;

            output_id=0;
    }
}
/*
 * brewer on
 * till reach fill position
 * within time
 * else stop and send timeout command
 */
void brewer_drive_ouput()
{
    if((output_id==26)AND(output_on_flag)AND((freshbrew_machine_flag)OR(beanbrew_machine_flag)))
    {
        if(fb_brwr_err_cnt<220)
        {
            if((!fb_home_pos_flg)AND(confrm_brwr_in_pos_dly>=4)AND(fresh_brewer_mtr_flg))
            {
                if(!brewer_already_in_pos)
                {
                    FRESH_BREWER_OFF;
                    output_off_normal_flg=SET;
                    fb_brwr_err_cnt_flg=output_on_flag=CLEAR_1;
                    fb_brwr_err_cnt=0;
                }
            }
            else
            {
                if(!fresh_brewer_mtr_flg)
                {
                    FRESH_BREWER_ON;
                    fb_brwr_err_cnt_flg=SET;
                    brewer_already_in_pos=fb_home_pos_flg?CLEAR_1:SET;
                }
                else if(brewer_already_in_pos)
                    brewer_already_in_pos=CLEAR_1;
            }
        }
        else
        {
            FRESH_BREWER_OFF;
            output_off_timeout_flg=SET;
            fb_brwr_err_cnt_flg=output_on_flag=CLEAR_1;
            fb_brwr_err_cnt=0;
        }
    }
    else if((output_id==29)AND(output_on_flag)AND(espresso_machine_flag))
    {
        if(es_brwr_err_cnt<220)
        {
            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4)AND(es_brwr_mtr_flg))
            {
                if(!brewer_already_in_pos)
                {
                    ESPRESSO_BREWER_OFF;
                    output_off_normal_flg=SET;
                    es_brwr_err_cnt_flg=output_on_flag=CLEAR_1;
                    es_brwr_err_cnt=0;
                }
            }
            else
            {
                if(!es_brwr_mtr_flg)
                {
                    ESPRESSO_BREWER_ON;
                    es_brwr_err_cnt_flg=SET;
                    brewer_already_in_pos=es_fill_pos_sw_flg?SET:CLEAR_1;
                }
                else if(brewer_already_in_pos)
                    brewer_already_in_pos=CLEAR_1;
            }
        }
        else
        {
            ESPRESSO_BREWER_OFF;
            output_off_timeout_flg=SET;
            es_brwr_err_cnt_flg=output_on_flag=CLEAR_1;
            es_brwr_err_cnt=0;
        }
    }
}

void water_run_time()
{
    switch(water_ch_id)
    {
        case 1:             //water valve 1
            if((ch_tmr[1].wtr_on_time<=0)AND(sol_vlv1_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID1_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv1_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID1_ON;
                ch_tmr[1].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 2:             //water valve 2
            if((ch_tmr[2].wtr_on_time<=0)AND(sol_vlv2_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID2_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv2_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID2_ON;
                ch_tmr[2].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 3:             //water valve 3
            if((ch_tmr[3].wtr_on_time<=0)AND(sol_vlv3_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID3_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv3_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID1_ON;
                ch_tmr[1].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 4:             //water valve 4
            if((ch_tmr[4].wtr_on_time<=0)AND(sol_vlv4_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID4_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv4_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID4_ON;
                ch_tmr[4].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 5:             //water valve 5
            if((ch_tmr[5].wtr_on_time<=0)AND(sol_vlv5_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID5_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv5_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID5_ON;
                ch_tmr[5].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 6:             //water valve 6
            if((ch_tmr[6].wtr_on_time<=0)AND(sol_vlv6_on_flg))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                SOLENOID6_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!sol_vlv6_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                SOLENOID6_ON;
                ch_tmr[6].wtr_on_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 7:             //Espresso
            espresso_demo_watr_run();
            break;
        case 8:             //Fresh brew
        case 9:             //Bean brew
            wtr_op_test();
            break;
        case 10:            //Hot Water
            if((hot_wtr_on_flg)AND(hot_or_cold_run_time<=0))
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_OFF;
                HOT_WATER_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!hot_wtr_on_flg)
            {
                if((espresso_machine_flag)AND(!drnk_genral_set[open_blr_en]))
                    PRESSURE_PUMP_ON;
                HOT_WATER_ON;
                hot_or_cold_run_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
        case 11:            //Cold Water
            if((cold_wtr_on_flg)AND(hot_or_cold_run_time<=0))
            {
                COOLER_OFF;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            else if(!cold_wtr_on_flg)
            {
                COOLER_ON;
                hot_or_cold_run_time=demo_wtr_run_time;
                demo_wtr_run_time=0;
            }
            break;
    }
}

void espresso_demo_watr_run()
{
    switch(demo_wtr_brwr_pos)
    {
        case 1:         //check the brewer position
            if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
            {
                demo_wtr_brwr_pos=2;
                ESPRESSO_BREWER_ON;
                fil_2_brw_err_cnt_start_flg=SET;
            }
            else
                demo_wtr_brwr_pos=5;
            break;
        case 2:         //move to the brew position
            if(fill_to_brew_err_cnt<70)
            {
                if((!es_brw_pos_sw_flg)AND(es_brwr_brw_pos_cnfrm>=4))
                {
                    ESPRESSO_BREWER_OFF;
                    fil_2_brw_err_cnt_start_flg=CLEAR_1;
                    demo_wtr_brwr_pos=3;
                }
            }
            else
            {
                ESPRESSO_BREWER_OFF;
                demo_wtr_brwr_pos=demo_wtr_run_time=0;
                fil_2_brw_err_cnt_start_flg=CLEAR_1;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
                wtr_run_time_done_snd_flg=SET;
            }
            break;
        case 3:         //pump on
            if((three_way_vlv_flg)AND(presure_pump_flg))
            {
                if(es_flw_cnt<=0)
                {
                    PRESSURE_PUMP_OFF;
                    THREE_WAY_VALVE_OFF;
                    demo_wtr_brwr_pos=4;
                    ESPRESSO_BREWER_ON;
                    brw_2_fil_err_cnt_start_flg=SET;
                }
            }
            else
            {
                es_flw_cnt=demo_wtr_run_time;
                demo_wtr_run_time=0;
                PRESSURE_PUMP_ON;
                THREE_WAY_VALVE_ON;
            }
            break;
        case 4:         //move back to fill pos
            if(brw_to_fil_cnt<90)
            {
                if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                {
                    ESPRESSO_BREWER_OFF;
                    brw_2_fil_err_cnt_start_flg=CLEAR_1;
                    demo_wtr_brwr_pos=0;
                    water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
                    wtr_run_time_done_snd_flg=SET;
                }
            }
            else
            {
                ESPRESSO_BREWER_OFF;
                demo_wtr_brwr_pos=demo_wtr_run_time=0;
                brw_2_fil_err_cnt_start_flg=CLEAR_1;
                wtr_run_time_done_snd_flg=SET;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
            }
            break;
        case 5:         //move to fill position
            if(es_brwr_err_cnt<220)
            {
                if((es_fill_pos_sw_flg)AND(es_brwr_fl_pos_cnfrm_dly>=4))
                {
//                  ESPRESSO_BREWER_OFF;
                    es_brwr_err_cnt_flg=CLEAR_1,es_brwr_err_cnt=0;
                    demo_wtr_brwr_pos=2;

                }
                else if(!es_brwr_mtr_flg)
                {
                    ESPRESSO_BREWER_ON;
                    es_brwr_err_cnt_flg=SET;
                }
            }
            else
            {
                ESPRESSO_BREWER_OFF;
                es_brwr_err_cnt_flg=CLEAR_1,es_brwr_err_cnt=0;
                demo_wtr_brwr_pos=demo_wtr_run_time=0;
                water_ch_id=0,wtr_run_time_initiate_flg=CLEAR_1;
                wtr_run_time_done_snd_flg=SET;
            }
            break;

    }
}
