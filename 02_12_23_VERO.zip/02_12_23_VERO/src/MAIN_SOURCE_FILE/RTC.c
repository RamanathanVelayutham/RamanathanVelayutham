/*
 * RTC.c
 *
 *  Created on: 31-Mar-2023
 *      Author: afila
 */

#include "MAIN_THREAD.h"
#include "../MAIN_HEADER_FILE/MACROS.h"
#include "../MAIN_HEADER_FILE/X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/EXTERN_FUN.h"
#include "../UART_HEADER_FILE/ANDRD_MACROS.h"
#include "../UART_HEADER_FILE/ANDRD_X_VARIABLES.h"
#include "../MAIN_HEADER_FILE/ARRAY_DEF.h"

unsigned char dec_to_hex(unsigned char);
void time_date_update();
void store_date_time();

void time_date_update()
{
    unsigned char i,ack;
    if(time_update_flag)//set once for half second
    {
        time_update_flag=CLEAR_1;
        disp_addr = RTC_SECONDS;//10
        ram_addr = &temp_rtc_buf[RTC_SECONDS];
        ack=read_iic(RTC_READ,7);
        if(ack)
        {
            for(i=0;i<30;i++)
            {
                if((temp_rtc_buf[i]>=0x00)AND(temp_rtc_buf[i]<=temp_rtc_buf[RTC_YEAR]?0X99:0x59)AND(temp_rtc_buf[RTC_DATE]!=0x00))
                {
                    rtc_buf[i]=temp_rtc_buf[i];
                }
            }
        }

    }
}
void store_date_time()
{
    date_time_changed_flag=CLEAR_1;
    rtc_buf[RTC_YEAR]   = dec_to_hex(date_time_arr[2]);
    rtc_buf[RTC_MONTH]  = dec_to_hex(date_time_arr[1]);
    rtc_buf[RTC_DATE]   = dec_to_hex(date_time_arr[0]);
    rtc_buf[RTC_DAY]    = dec_to_hex(date_time_arr[5]);
    rtc_buf[RTC_SECONDS]    = 0;
    rtc_buf[RTC_MINUTES]    = dec_to_hex(date_time_arr[4]);
    rtc_buf[RTC_HOURS]  = dec_to_hex(date_time_arr[3]);
    disp_addr = RTC_SECONDS;
    ram_addr = &rtc_buf[RTC_SECONDS];
    write_iic(RTC_WRITE,7);
    date_time_send_flg=SET;
}

unsigned char dec_to_hex(unsigned char num)
{
    unsigned char value[10]={0,0,0,0,0,0,0,0,0,0};
    unsigned char xx,i = 0;
    unsigned char disp_area=0,rtc_disp=0;
    while(num > 0)
    {
        value[i] = num % 10;
        num /= 10;
        i = i + 1;
    }
    rtc_disp=disp_area=value[0]|(value[1]<<4);
    return rtc_disp;
}
